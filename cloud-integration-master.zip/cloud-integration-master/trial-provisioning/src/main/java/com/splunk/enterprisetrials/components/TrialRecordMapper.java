package com.splunk.enterprisetrials.components;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class TrialRecordMapper {

	/*
	 * Option 1: Map multiple records into a collection of JSON entries
	 */
	public HashMap<String, Object> map (Collection<Map<String, Object>> items) {
		List<HashMap<String, String>> mappedItems = new LinkedList<HashMap<String, String>>();
		
		for (Map<String, Object> item: items) {
			mappedItems.add(this.mapping(item));
		}
		
		return constructPreferredJson(mappedItems);
	}
		
	
	/**
	 * Option 2: Map a single record
	 */
	public HashMap<String, Object> mapRecord (Map<String, Object> inputRecord) {
		return constructPreferredJson(new Object[] {this.mapping(inputRecord)});
	}
	
	private HashMap<String, String> mapping(Map<String, Object> inputRecord) {
		HashMap<String, String> record = new HashMap<String, String>();
		record.put("stackName", getStr(inputRecord, "Name"));
		record.put("creationTime", getStr(inputRecord, "Start_Date__c"));
		record.put("expirationTime", getStr(inputRecord, "End_Date__c"));
		record.put("stackStatus", getStr(inputRecord, "Status__c"));
		if(getStr(inputRecord, "InstanceType__c").equals("")) {
			record.put("instanceType", "Trial");
		}
		else {
		record.put("instanceType", getStr(inputRecord, "InstanceType__c"));
		}
		record.put("trialProductType", inputRecord.containsKey("Trial_Product__r") && inputRecord.get("Trial_Product__r") != null ? ((Map)inputRecord.get("Trial_Product__r")).get("Product_Name__c").toString() : "");
		record.put("trialStackURL", getStr(inputRecord, "URL__c"));
		record.put("subdomain", getStr(inputRecord, "Subdomain__c"));
		record.put("instanceId", getStr(inputRecord, "Instance_Id__c"));	
		return record;
	}
	
	private HashMap<String, Object> constructPreferredJson(Object o) {
		HashMap<String, Object> preferredJson = new HashMap<String, Object>();
		preferredJson.put("statusCode", "STS-200-SUCCESS");
		preferredJson.put("trials", o);
		return preferredJson;
	}

	private String getStr(Map<String, Object> record, String key) {
		if (!record.containsKey(key)) return "";
		
		Object result = record.get(key);
		if (result == null) return "";
		
		return result.toString();
	}
	
}
