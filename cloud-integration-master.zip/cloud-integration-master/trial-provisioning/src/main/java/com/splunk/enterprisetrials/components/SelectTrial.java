package com.splunk.enterprisetrials.components;

import java.util.List;
import java.util.Map;

import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;

/*
 * If the request includes a stackName, select the requested stack
 */
public class SelectTrial implements Callable {

	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		String stackName = eventContext.getMessage().getInvocationProperty("stackName");
		
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> payload = (List<Map<String, Object>>)eventContext.getMessage().getPayload();

		for (Map<String, Object> record: payload) {
			if (stackName.equals((String)record.get("Name"))) {
				return record;
			}
		}
		
		return null;
	}



}
