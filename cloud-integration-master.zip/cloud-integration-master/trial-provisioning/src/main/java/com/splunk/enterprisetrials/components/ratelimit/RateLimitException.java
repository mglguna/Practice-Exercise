package com.splunk.enterprisetrials.components.ratelimit;

import org.mule.api.MessagingException;
import org.mule.api.MuleEvent;
import org.mule.api.MuleMessage;
import org.mule.api.processor.MessageProcessor;
import org.mule.config.i18n.Message;

/** 
 * Exception thrown when a CRM ID is seen by Create Trial more than once within a time period
 * @author Nahuel Lofeudo
 *
 */
public class RateLimitException extends MessagingException {
	public RateLimitException(Message message, MuleEvent event) {
		super(message, event);
	}

	public RateLimitException(Message message, MuleEvent event,
			MessageProcessor failingMessageProcessor) {
		super(message, event, failingMessageProcessor);
		// TODO Auto-generated constructor stub
	}

	public RateLimitException(Message message, MuleEvent event,
			Throwable cause, MessageProcessor failingMessageProcessor) {
		super(message, event, cause, failingMessageProcessor);
		// TODO Auto-generated constructor stub
	}

	public RateLimitException(Message message, MuleEvent event, Throwable cause) {
		super(message, event, cause);
		// TODO Auto-generated constructor stub
	}

	public RateLimitException(MuleEvent event, Throwable cause,
			MessageProcessor failingMessageProcessor) {
		super(event, cause, failingMessageProcessor);
		// TODO Auto-generated constructor stub
	}

	public RateLimitException(MuleEvent event, Throwable cause) {
		super(event, cause);
		// TODO Auto-generated constructor stub
	}

	
	
	public RateLimitException(Message message, MuleMessage muleMessage,
			Throwable cause) {
		super(message, muleMessage, cause);
		// TODO Auto-generated constructor stub
	}

	public RateLimitException(Message message, MuleMessage muleMessage) {
		super(message, muleMessage);
		// TODO Auto-generated constructor stub
	}



	private static final long serialVersionUID = -7995118018040287502L;

}
