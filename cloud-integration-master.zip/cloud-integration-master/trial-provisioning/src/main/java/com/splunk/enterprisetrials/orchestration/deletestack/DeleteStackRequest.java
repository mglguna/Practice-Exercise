package com.splunk.enterprisetrials.orchestration.deletestack;

import java.util.List;

public class DeleteStackRequest {
	List<DeleteStackRequestItem> trials;
	List<DeleteStackRequestItem> cloudStacks;
	
	public List<DeleteStackRequestItem> getTrials() {
		return trials;
	}
	public void setTrials(List<DeleteStackRequestItem> trials) {
		this.trials = trials;
	}
	public List<DeleteStackRequestItem> getCloudStacks() {
		return cloudStacks;
	}
	public void setCloudStacks(List<DeleteStackRequestItem> cloudStacks) {
		this.cloudStacks = cloudStacks;
	}	
}
