package com.splunk.enterprisetrials.components.ratelimit;

import java.io.Serializable;
import java.util.Map;

import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;
import org.mule.api.store.ObjectStore;

public class RateLimitEnd implements Callable {

	ObjectStore<Serializable> objectStore;
	
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		@SuppressWarnings("unchecked")
		Map<String, Object> createTrial = (Map<String, Object>)eventContext.getMessage().getInvocationProperty("createTrial");
		String crmId = (String)createTrial.get("crmId");
		
		synchronized(objectStore) {
			objectStore.remove(crmId);
		}
		return eventContext.getMessage();
	}


	public ObjectStore<Serializable> getObjectStore() {
		return objectStore;
	}

	public void setObjectStore(ObjectStore<Serializable> objectStore) {
		this.objectStore = objectStore;
	}

}
