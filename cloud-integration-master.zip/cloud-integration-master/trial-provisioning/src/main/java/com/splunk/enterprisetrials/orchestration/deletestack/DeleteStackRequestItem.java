package com.splunk.enterprisetrials.orchestration.deletestack;

public class DeleteStackRequestItem {

	private String crmId;
	private StackType stackType;
	private String stackName;
	private String stackRegion;
	private DeleteStackResult result = DeleteStackResult.MARKED_FOR_DELETION;
	private String cause = "";
	
	// Internal fields
	private String stackRecordCrmId;
	
	public String getCrmId() {
		return crmId;
	}
	public void setCrmId(String crmId) {
		this.crmId = crmId;
	}
	public String getStackName() {
		return stackName;
	}
	public void setStackName(String stackName) {
		this.stackName = stackName;
	}
	public String getStackRegion() {
		return stackRegion;
	}
	public void setStackRegion(String stackRegion) {
		this.stackRegion = stackRegion;
	}
	public DeleteStackResult getResult() {
		return result;
	}
	public void setResult(DeleteStackResult result) {
		this.result = result;
	}
	public String getCause() {
		return cause;
	}
	public void setCause(String cause) {
		this.cause = cause;
	}
	public StackType getStackType() {
		return stackType;
	}
	public void setStackType(StackType stackType) {
		this.stackType = stackType;
	}
	public String getStackRecordCrmId() {
		return stackRecordCrmId;
	}
	public void setStackRecordCrmId(String stackRecordCrmId) {
		this.stackRecordCrmId = stackRecordCrmId;
	}
}
