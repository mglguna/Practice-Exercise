package com.splunk.enterprisetrials.components.ratelimit;

import java.io.Serializable;
import java.util.Map;

import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;
import org.mule.api.store.ObjectStore;
import org.mule.config.i18n.MessageFactory;

public class RateLimitBegin implements Callable {
	
	ObjectStore<Serializable> objectStore;
	int timeBetweenRequestsMillis = 2000;
	
	@SuppressWarnings("unchecked")
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		Map<String, Object> createTrial = (Map<String, Object>)eventContext.getMessage().getInvocationProperty("createTrial");
		String crmId = (String)createTrial.get("crmId");
		
		synchronized (objectStore) {
			if(objectStore.contains(crmId)) {
				// If the entry is less than timeBetweenRequestsMillis milliseconds old, reject the call
				if (((Long)objectStore.retrieve(crmId)) + timeBetweenRequestsMillis > System.currentTimeMillis()) {
					throw new RateLimitException(MessageFactory.createStaticMessage("Rate Limited"), eventContext.getMessage());
				} else { 
					// Otherwise, expire the entry manually
					objectStore.remove(crmId);
				}
			}
			objectStore.store(crmId, new Long(System.currentTimeMillis()));
		}
		return eventContext.getMessage().getPayload();
	}

	public ObjectStore<Serializable> getObjectStore() {
		return objectStore;
	}

	public void setObjectStore(ObjectStore<Serializable> objectStore) {
		this.objectStore = objectStore;
	}



	public int getTimeBetweenRequestsMillis() {
		return timeBetweenRequestsMillis;
	}

	public void setTimeBetweenRequestsMillis(int timeBetweenRequestsMillis) {
		this.timeBetweenRequestsMillis = timeBetweenRequestsMillis;
	}
}

