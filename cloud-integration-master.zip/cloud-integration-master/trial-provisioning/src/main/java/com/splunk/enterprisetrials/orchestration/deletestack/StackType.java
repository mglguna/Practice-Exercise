package com.splunk.enterprisetrials.orchestration.deletestack;

public enum StackType {
	TRIAL,
	CLOUD_STACK

}
