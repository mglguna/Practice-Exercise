package com.splunk.enterprisetrials.components;

import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * 
 * THis class provides synchronization across threads, based on an arbitrary ID.
 * You could say that a thread can "wait" on an ID and another one could trigger it
 * @author nahuellofeudo
 *
 */
public class SynchronizationPoint {
	private ConcurrentHashMap<String, Semaphore> semaphores;
	int timeout;
	
	public SynchronizationPoint() {
		this.semaphores = new ConcurrentHashMap<String, Semaphore>();
	}
	
	/**
	 * Wait for a signal from another thread, for the stack id
	 * @param id the stack to wait on
	 * @throws InterruptedException when the system is shutting down
	 */
	public void waitSignal(String id) throws InterruptedException {
		Semaphore semaphore = this.getSemaphoreFor(id);

		boolean acquired = semaphore.tryAcquire(timeout, TimeUnit.MILLISECONDS);
		semaphores.remove(id);

		if(!acquired) {
			// We timed out
			throw new RuntimeException("Timed out waiting for notification for stack " + id);
		}
	}
	
	/**
	 * Wakes up another thread that may be waiting on this id
	 * @param id the stack id whose notification we just received
	 */
	public void signal(String id) {
		Semaphore sem = semaphores.get(id);
		if(sem != null) sem.release();
	}
	
	/**
	 * Gets a semaphore for a stack id
	 * @param id the stack ID to wait on
	 * @return a Semaphore to wait on, or to signal
	 */
	private synchronized Semaphore getSemaphoreFor(String id) {
		if (!semaphores.containsKey(id)) {
			Semaphore sem = new Semaphore(0);
			semaphores.put(id, sem);
		}	
		return semaphores.get(id);
	}

	
	public int getTimeout() {
		return timeout;
	}

	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}
}
