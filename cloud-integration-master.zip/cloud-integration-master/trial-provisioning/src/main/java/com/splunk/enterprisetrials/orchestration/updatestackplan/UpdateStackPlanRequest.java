package com.splunk.enterprisetrials.orchestration.updatestackplan;

/**
 * Class that models a request to Update Stack Plan
 * @author nahuellofeudo
 *
 */
public class UpdateStackPlanRequest {
	private String opportunityProductId;
    private String subscriptionId;
    private String fulfillmentCaseId;
    private String stackId;
    private String poolName;           
   
    public String getPoolName() {
		return poolName;
	}
	public void setPoolName(String poolName) {
		this.poolName = poolName;
	}
	public String getOpportunityProductId() {
		return opportunityProductId;
	}
	public void setOpportunityProductId(String opportunityProductId) {
		this.opportunityProductId = opportunityProductId;
	}
	public String getSubscriptionId() {
		return subscriptionId;
	}
	public void setSubscriptionId(String subscriptionId) {
		this.subscriptionId = subscriptionId;
	}
	
	public String getFulfillmentCaseId() {
		return fulfillmentCaseId;
	}
	public void setFulfillmentCaseId(String fulfillmentCaseId) {
		this.fulfillmentCaseId = fulfillmentCaseId;
	}
	public String getStackId() {
		return stackId;
	}
	public void setStackId(String stackId) {
		this.stackId = stackId;
	}

}
