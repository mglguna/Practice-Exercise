package com.splunk.enterprisetrials.components;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xbill.DNS.Cache;
import org.xbill.DNS.ExtendedResolver;
import org.xbill.DNS.Lookup;
import org.xbill.DNS.NSRecord;
import org.xbill.DNS.Record;
import org.xbill.DNS.Resolver;
import org.xbill.DNS.Type;

public class WaitForDnsEntry implements Callable {
	private Logger logger = LoggerFactory.getLogger(WaitForDnsEntry.class);
			
	private int maxAttempts = 5;
	private int attemptsDelay = 2000;
	
	@SuppressWarnings("unchecked")
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		try {
			Map<String, Object> stackStatus = eventContext.getMessage().getInvocationProperty("stackStatus");
			Map<String, Object> outputs = ((Map<String, Object>)stackStatus.get("Outputs"));
	
			String url = (String)outputs.get("SplunkServerURL");
			
			String hostName = this.getHostName(url);
			logger.info("Waiting on hostname " + hostName);
			for (int count = 0; count < maxAttempts; count++) {
					Lookup lookup = new Lookup(hostName, Type.A);
					lookup.setCache(new Cache());
					lookup.setResolver(this.getRoute53Resolver());
					Record [] recordList = lookup.run();
					if (recordList != null && recordList.length > 0) {
						logger.info("Host " + hostName + " is ready. Updating and notifying...");
						return eventContext.getMessage().getPayload();
					} else {
						logger.info("Host name " + hostName + " not ready yet. Waiting...");
						Thread.sleep(attemptsDelay);
					}
			}
			logger.info("Max retries exceeded but DNS entry is not ready. Giving up waiting.");
			return eventContext.getMessage().getPayload();
		} catch (Exception e) {
			logger.error("Error in WaitForDnsEntry: " + e.getMessage());
			return eventContext.getMessage().getPayload();
		}
	}

	private Resolver getRoute53Resolver() throws Exception {
		Lookup lookup = new Lookup("splunktrial.com", Type.NS);	
		lookup.setCache(new Cache());
		Record [] recordList = lookup.run();
		if (recordList == null) throw new Exception ("Error resolving nameservers for splunktrial.com");
		
		// Turn Record list into resolvers
		String [] nsServers = new String [recordList.length];
		for (int x = 0; x < recordList.length; x++) {
			NSRecord nsRecord = (NSRecord) recordList[x];
			nsServers[x] = nsRecord.getTarget().toString();
		}
		return new ExtendedResolver(nsServers);
	}
	
	private String getHostName(String url) throws MalformedURLException {
		URL parsedUrl = new URL(url);
		return parsedUrl.getHost();
	}

	public int getMaxAttempts() {
		return maxAttempts;
	}

	public void setMaxAttempts(int maxAttempts) {
		this.maxAttempts = maxAttempts;
	}

	public int getAttemptsDelay() {
		return attemptsDelay;
	}

	public void setAttemptsDelay(int attemptsDelay) {
		this.attemptsDelay = attemptsDelay;
	}

}
