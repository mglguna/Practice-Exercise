package com.splunk.enterprisetrials.components;

import org.mule.api.MuleContext;
import org.mule.api.MuleEventContext;
import org.mule.api.context.MuleContextAware;
import org.mule.api.lifecycle.Callable;
import org.mule.api.registry.MuleRegistry;
import org.mule.modules.salesforce.adapters.SalesforceConnectorConnectionManagementAdapter;
import org.mule.modules.salesforce.connectivity.SalesforceConnectorConfigConnectionManagementConnectionManager;

public class GetSalesforceSessionId implements Callable, MuleContextAware {

	SalesforceConnectorConfigConnectionManagementConnectionManager connectionManager;
	MuleContext context;
	
	@Override
	public synchronized Object onCall(MuleEventContext eventContext) throws Exception {

		if (connectionManager == null) {
			MuleRegistry registry = this.context.getRegistry();
			connectionManager = (SalesforceConnectorConfigConnectionManagementConnectionManager)(registry.lookupObject("salesforce"));
		}
		
		SalesforceConnectorConnectionManagementAdapter connection = connectionManager.acquireConnection(connectionManager.getDefaultConnectionKey());
		String sessionId = connection.getSessionId();
		connectionManager.releaseConnection(connectionManager.getDefaultConnectionKey(), connection);
		return sessionId;
	}

	@Override
	public void setMuleContext(MuleContext context) {
		this.context = context;
	}

	public SalesforceConnectorConfigConnectionManagementConnectionManager getConnectionManager() {
		return connectionManager;
	}

	public void setConnectionManager(
			SalesforceConnectorConfigConnectionManagementConnectionManager connectionManager) {
		this.connectionManager = connectionManager;
	}
}
