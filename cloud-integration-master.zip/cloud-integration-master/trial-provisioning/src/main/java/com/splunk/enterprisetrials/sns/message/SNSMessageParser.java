package com.splunk.enterprisetrials.sns.message;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;

/**
 * Parses the Message field in a SNS notification. Implemented in Java since it
 * needs to be as fast as possible
 * 
 * @author Nahuel Lofeudo
 * 
 */
public class SNSMessageParser implements Callable {

	private ObjectMapper mapper = new ObjectMapper();

	public SNSMessageParser() {
		super();
	}

	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		@SuppressWarnings("unchecked")
		Map<String, Object> payload = (Map<String, Object>) eventContext
				.getMessage().getPayload();

		// Extract Message from payload
		String messageItem = (String) payload.get("Message");

		
		Map<String, Object> messageItems = new HashMap<String, Object>();
		
		try {
			// Try parsing the list as a newline-delimited list of key-value pairs
			messageItems = parseLines(messageItem); 
		} catch (Exception e) {
			// Try parsing it as a JSON string
			messageItems = this.parseJson(messageItem);
		}
		
		eventContext.getMessage().setInvocationProperty("MessageItems", messageItems);
		return eventContext.getMessage().getPayload();
	}

	
	/**
	 * Parse the 
	 * @param messageItem
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private Map<String, Object> parseJson(String messageItem) throws JsonParseException, JsonMappingException, IOException {
		JsonFactory factory = new JsonFactory(); 
	    ObjectMapper mapper = new ObjectMapper(factory); 
	    TypeReference<HashMap<String,Object>> typeRef = new TypeReference<HashMap<String,Object>>() {};
	    HashMap<String,Object> result = mapper.readValue(messageItem, typeRef); 
	    return result;
	}
	
	/**
	 * Try to parse the Message field as a series of newline-seprated key-value pairs
	 * @param messageItem
	 * @return
	 */
	private Map<String, Object> parseLines(String messageItem) {
		// Split into lines
		String[] lines = messageItem.split("\n");
		Map<String, Object> messageItems = new HashMap<String, Object>();

		for (String line : lines) {
			if (line != null && !line.trim().startsWith("'")) {
				// Split into key-value pairs
				int splitpoint = line.indexOf('=');
				String name = line.substring(0, splitpoint).trim();
				String value = line.substring(splitpoint + 1).trim();
				value = value.substring(1, value.length() - 1);
	
				// Parse JSON in the value
				if (name.equals("ResourceProperties")) {
					if ((value != null) && (value.length() > 3)) {
						try {
							Object result = mapper.readValue(value, Map.class);
							messageItems.put(name, result);
						} catch (Exception e) {
							messageItems.put(name, new HashMap<String, Object>());
						}
					} else {
						messageItems.put(name, new HashMap<String, Object>());
					}
				} else {
					messageItems.put(name, value);
				}
			}
		}
		return messageItems;
	}

}
