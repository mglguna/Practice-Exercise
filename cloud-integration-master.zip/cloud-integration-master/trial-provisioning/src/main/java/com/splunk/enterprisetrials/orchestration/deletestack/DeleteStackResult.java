package com.splunk.enterprisetrials.orchestration.deletestack;

public enum DeleteStackResult {
	IN_PROCESS,
	MARKED_FOR_DELETION, 
	DELETION_FAILED,
	VALIDATION_FAILED
}
