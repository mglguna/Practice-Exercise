package com.splunk.enterprisetrials.components;

import java.util.List;

import org.mule.api.MuleContext;
import org.mule.api.MuleEvent;
import org.mule.api.MuleException;
import org.mule.api.context.MuleContextAware;
import org.mule.api.processor.MessageProcessor;

import com.mulesoft.mule.cache.ObjectStoreCachingStrategy;

/**
 * Expires an entry in the referenced cache's object store.
 * Takes a list of expressions from where it will extract the IDs of the entries to expire
 * @author nahuellofeudo
 *
 */
public class ExpireCacheEntry implements MessageProcessor, MuleContextAware {
	private MuleContext context;
	private ObjectStoreCachingStrategy cachingStrategy;
	private List<String> IdExpressions;
	
	@Override
	public MuleEvent process(MuleEvent event) throws MuleException {
		
		for (String idExpression: this.IdExpressions) {
			try {
				String crmId = this.context.getExpressionManager().parse(idExpression, event);
				invalidateCrmId(cachingStrategy, crmId);				
			} catch (Exception e) {}
		}
		return event;
	}


	/**
	 * Invalidates a cache entry whose key is a CRM (SFDC) ID.
	 * If the ID is the 18-letter version, it invalidates the 18-letter version and the 15-letter version
	 * just in case 
	 * @param cacheStore
	 * @param crmId
	 */
	private void invalidateCrmId(ObjectStoreCachingStrategy cacheStore, String crmId) {
		cacheStore.invalidate(crmId);
		
		// If we have the 18-letter ID, invalidate the 15-letter too, just in case
		if (crmId != null && crmId.length() == 18) {
			crmId = crmId.substring(0, 15);
			cacheStore.invalidate(crmId);
		}
	}

	@Override
	public void setMuleContext(MuleContext context) {
		this.context = context;
	}

	public void setCachingStrategy(ObjectStoreCachingStrategy cachingStrategy) {
		this.cachingStrategy = cachingStrategy;
	}

	public void setIdExpressions(List<String> idExpressions) {
		IdExpressions = idExpressions;
	}

}
