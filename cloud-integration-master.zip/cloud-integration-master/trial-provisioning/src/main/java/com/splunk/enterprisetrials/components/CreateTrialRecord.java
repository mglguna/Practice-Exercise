package com.splunk.enterprisetrials.components;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;

/**
 * Assemble a new Trial record
 * This record has become too complex for a single expression
 * @author nahuel
 *
 */
public class CreateTrialRecord implements Callable {

	private static long millisecondsInADay = 1000 * 60 * 60 * 24;
	private int trialDays = 30;
	private String status;
	
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		HashMap<String, Object> record = new HashMap<String, Object>();
		Map<String, Object> createTrial = eventContext.getMessage().getInvocationProperty("createTrial");
		Map<String, Object> trialProduct = eventContext.getMessage().getInvocationProperty("trialProduct");
		Map<String, Object> trialInfo = eventContext.getMessage().getInvocationProperty("trialInfo");
		String trial = eventContext.getMessage().getInvocationProperty("instanceType");
		String stackType = eventContext.getMessage().getInvocationProperty("stackType");
		Date currentPSTDate = getPSTDate();
		
		if (((String)createTrial.get("crmId")).startsWith("003")) {
			record.put("Contact__c", createTrial.get("crmId"));
		} else {
			record.put("Lead__c", createTrial.get("crmId"));
		}
		
		record.put("Trial_Info__c", trialInfo.get("Id"));
		record.put("Product_Name__c", createTrial.get("trialProductType"));
		if (createTrial.get("shoppingCartItemId") != null )
			record.put("Shopping_Cart_Item_ID__c", createTrial.get("shoppingCartItemId"));
		record.put("Trial_Product__c", trialProduct.get("Id"));
		record.put("Status__c", this.status);
		record.put("Start_Date__c", currentPSTDate);
		record.put("End_Date__c", 
				new Date(currentPSTDate.getTime() + 
				(int)(
					Double.parseDouble(trialProduct.get("Duration__c").toString()) * 
					millisecondsInADay
				)));
		
		record.put("InstanceType__c",trial);
		record.put("Stack_Type__c", stackType);
		eventContext.getMessage().setInvocationProperty("createTrialMap", record);
		return eventContext.getMessage().getPayload();
	}

	public int getTrialDays() {
		return trialDays;
	}

	public void setTrialDays(int trialDays) {
		this.trialDays = trialDays;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public Date getPSTDate() {
		Date date = new Date();
		Date pstDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy hh:mm:ss a");
		sdf.setTimeZone(TimeZone.getTimeZone("PST"));
		SimpleDateFormat pst = new SimpleDateFormat("dd MMM yyyy hh:mm:ss a");
		try {
			pstDate = pst.parse(sdf.format(date));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return pstDate;
	}


}
