package com.splunk.enterprisetrials.components;

import java.io.Closeable;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.mule.api.MuleContext;
import org.mule.api.MuleEvent;
import org.mule.api.MuleMessage;
import org.mule.api.context.MuleContextAware;
import org.mule.api.context.notification.EndpointMessageNotificationListener;
import org.mule.api.context.notification.MessageProcessorNotificationListener;
import org.mule.api.context.notification.ServerNotification;
import org.mule.api.object.ObjectFactory;
import org.mule.component.DefaultJavaComponent;
import org.mule.context.notification.EndpointMessageNotification;
import org.mule.context.notification.MessageProcessorNotification;
import org.mule.endpoint.DefaultOutboundEndpoint;
import org.mule.modules.salesforce.processors.CreateMessageProcessor;
import org.mule.modules.salesforce.processors.CreateSingleMessageProcessor;
import org.mule.modules.salesforce.processors.QueryAllMessageProcessor;
import org.mule.modules.salesforce.processors.QueryMessageProcessor;
import org.mule.modules.salesforce.processors.QuerySingleMessageProcessor;
import org.mule.modules.salesforce.processors.RetrieveMessageProcessor;
import org.mule.modules.salesforce.processors.SearchMessageProcessor;
import org.mule.modules.salesforce.processors.UpdateMessageProcessor;

@SuppressWarnings("rawtypes")
public class SplunkLogger implements MessageProcessorNotificationListener, EndpointMessageNotificationListener, MuleContextAware {

	private String environment;
	private MuleContext context;
	private static Log logger = LogFactory.getLog(SplunkLogger.class);
	private static String APICALL = "apiCall";
	private static String ACTION = "action";
	
	private static String [] stackNameExpressions = new String[] {"#[flowVars['actualStackName']]", "#[flowVars['MessageItems']['StackName']]"}; 
	private static String [] userNameExpressions = new String[] {"#[flowVars['createTrial']['userName']]"}; 
	private static String [] crmIdExpressions = new String[] {"#[flowVars['createTrial']['crmId']]", "#[flowVars['crmId']]"}; 
	private static String [] productTypeExpressions = new String[] {"#[flowVars['createTrial']['trialProductType']]"}; 
	
	/**
	 * Main entry point for notifications
	 * @param notification the notification fired by Mule
	 */
	@Override
	public void onNotification(ServerNotification notification) {
		Map<String, String> logEntry = new LinkedHashMap<String, String>();
		if (notification instanceof MessageProcessorNotification) {
			MessageProcessorNotification messageProcessorNotification = (MessageProcessorNotification) notification;
			
			// Do not log SNS endpoint notifications by default
			if (messageProcessorNotification.getSource().getMessageSourceName().endsWith(".sns")) return;
			this.buildMessageProcessorLog(messageProcessorNotification, logEntry);
			logEntry(notification, logEntry);
		} else if (notification instanceof EndpointMessageNotification) {
			
			// Do not log SNS notifications by default. They will be logged after a message has been accepted.
			EndpointMessageNotification endpointNotification = ((EndpointMessageNotification)notification);
			if (endpointNotification.getEndpoint().endsWith("sns")) return;
			if (endpointNotification.getEndpoint().endsWith("SNSMessage"));
			this.buildEndpointMessageCommonEntries((EndpointMessageNotification) notification, logEntry);
			logEntry(notification, logEntry);
		}
	}



	/**
	 * If applicable, adds all common fields and logs the entry
	 * @param notification
	 * @param logEntry
	 */
	private void logEntry(ServerNotification notification, Map<String, String> logEntry) {
		if (!logEntry.isEmpty()) {
			this.buildCommonEntries(notification, logEntry);
			logger.info(this.formatEntry(logEntry));
		}
	}

	
	
	
	/**
	 * Builds an entry for a Message Processor (AKA "service call") event.
	 * The method only reacts to a very specific subset of message processors: Those that call other services.
	 * @param messageProcessorSource
	 * @param logEntry
	 */
	private void buildMessageProcessorLog(MessageProcessorNotification messageProcessorSource, Map<String, String> logEntry) {
		String className = messageProcessorSource.getProcessor().getClass().getName();
		if (className.startsWith("org.mule.modules.salesforce.processors")) {
			this.buildSfdcProcessorLog(messageProcessorSource, logEntry);
		} else if (className.startsWith("org.mule.component.DefaultJavaComponent")) {
			this.buildSplunkProcessorLog(messageProcessorSource, logEntry);
		} else if (className.startsWith("org.mule.endpoint.DefaultOutboundEndpoint")) {
			DefaultOutboundEndpoint endpoint = (DefaultOutboundEndpoint)messageProcessorSource.getProcessor();
			// Do not log VM messages
			if (endpoint.getEndpointURI().toString().contains("vm://")) return;
			logEntry.put(APICALL, endpoint.getName());
		}
		
		if (!logEntry.isEmpty()) {
			this.buildMessageProcessorCommonEntries(messageProcessorSource, logEntry);
		}
	}

	/**
	 * Builds a log entry for a Splunk-specific (i.e. AWS) message processor
	 * 
	 * @param messageProcessorSource
	 * @param logEntry
	 */
	private void buildSplunkProcessorLog(MessageProcessorNotification messageProcessorSource, Map<String, String> logEntry) {

		ObjectFactory objectFactory = ((DefaultJavaComponent) messageProcessorSource.getProcessor()).getObjectFactory();
		if (objectFactory == null) return;
		String className = objectFactory.getObjectClass().getName();

		if (className.endsWith(".CreateStack")) {
			logEntry.put(APICALL, "AWS:createStack");
		} else if (className.endsWith(".DeleteStack")) {
			logEntry.put(APICALL, "AWS:deleteStack");
		} else if (className.endsWith(".DescribeStack")) {
			logEntry.put(APICALL, "AWS:describeStack");
		}
	}

	/**
	 * Builds a log entry for an endpoint message call
	 * 
	 * @param endpointMessageSource
	 * @param logEntry
	 */
	private void buildEndpointMessageCommonEntries(EndpointMessageNotification endpointMessageSource, Map<String, String> logEntry) {
		this.addLogItem(logEntry, "crmId", crmIdExpressions, endpointMessageSource.getSource());
		this.addLogItem(logEntry, "stackName", stackNameExpressions, endpointMessageSource.getSource());
		this.addLogItem(logEntry, "userName", userNameExpressions, endpointMessageSource.getSource());
		this.addLogItem(logEntry, "productType", productTypeExpressions, endpointMessageSource.getSource());
	}

	/**
	 * Builds a log entry for a SFDC connector's message processor.
	 * 
	 * @param messageProcessorSource
	 * @param logEntry
	 */
	private void buildSfdcProcessorLog(MessageProcessorNotification messageProcessorSource, Map<String, String> logEntry) {
		if (messageProcessorSource.getProcessor() instanceof QuerySingleMessageProcessor) {
			logEntry.put(APICALL, "SFDC:QuerySingle");
		} else if (messageProcessorSource.getProcessor() instanceof CreateMessageProcessor) {
			logEntry.put(APICALL, "SFDC:Create");
		} else if (messageProcessorSource.getProcessor() instanceof UpdateMessageProcessor) {
			logEntry.put(APICALL, "SFDC:Update");
		} else if (messageProcessorSource.getProcessor() instanceof SearchMessageProcessor) {
			logEntry.put(APICALL, "SFDC:Search");
		} else if (messageProcessorSource.getProcessor() instanceof RetrieveMessageProcessor) {
			logEntry.put(APICALL, "SFDC:Retrieve");
		} else if (messageProcessorSource.getProcessor() instanceof QueryMessageProcessor) {
			logEntry.put(APICALL, "SFDC:Query");
		} else if (messageProcessorSource.getProcessor() instanceof CreateSingleMessageProcessor) {
			logEntry.put(APICALL, "SFDC:CreateSingle");
		} else if (messageProcessorSource.getProcessor() instanceof QueryAllMessageProcessor) {
			logEntry.put(APICALL, "SFDC:QueryAll");
		}
	}

	/** 
	 * Builds the common key-value pairs for Message Processor log entries
	 * @param notification
	 * @param logEntry
	 */
	private void buildMessageProcessorCommonEntries(MessageProcessorNotification notification, Map<String, String> logEntry) {
		this.addLogItem(logEntry, "crmId", crmIdExpressions, notification.getSource().getMessage());
		this.addLogItem(logEntry, "stackName", stackNameExpressions, notification.getSource().getMessage());
		this.addLogItem(logEntry, "userName", userNameExpressions, notification.getSource().getMessage());
		this.addLogItem(logEntry, "productType", productTypeExpressions, notification.getSource().getMessage());		
	}
	
	/**
	 * Builds the key-value pairs for all log entries
	 * @param notification
	 * @param logEntry
	 */
	private void buildCommonEntries(ServerNotification notification, Map<String, String> logEntry) {
		logEntry.put("environment", environment);
		
		//
		if (notification.getSource() instanceof MuleMessage) {
			MuleMessage sourceMessage = (MuleMessage)notification.getSource();
			logEntry.put("messageId", sourceMessage.getMessageRootId());
		} else if (notification.getSource() instanceof MuleEvent) {
			MuleEvent sourceEvent = (MuleEvent)notification.getSource();
			logEntry.put("messageId", sourceEvent.getMessage().getMessageRootId());			
		}
		
		// Insert the action
		if (notification.getAction() == 1601) {
			logEntry.put(ACTION, "call");
		} else if (notification.getAction() == 1602) {
			logEntry.put(ACTION, "return");
		} else {
			logEntry.put(ACTION, notification.getActionName());
		}
	}

	
	/**
	 * Takes a set of key-value pairs and turns them into a log entry
	 * @param logEntry
	 * @return
	 */
	private Object formatEntry(Map<String, String> logEntry) {
		StringBuilder sb = new StringBuilder();

		for (String key : logEntry.keySet()) {
			if (sb.length() != 0)
				sb.append(",");
			sb.append(key);
			sb.append("=");
			sb.append("\"");
			sb.append(logEntry.get(key));
			sb.append("\"");
		}
		return sb.toString();
	}

	
	/**
	 * Extracts information for a particular value to be logged by trying every candidate expression
	 * if no value is found, it just doesn't set the key-value pair.
	 * @param logItemName
	 * @param candidateExpressions
	 */
	@SuppressWarnings("deprecation")
	private void addLogItem(Map<String, String> logEntry, String logItemName, String[] candidateExpressions, MuleMessage message) {
		for (String candidateExpression: candidateExpressions) {
			// Skip entries that reference payload when the payload is a Stream (it breaks things)
			if (isStream(message.getPayload()) && candidateExpression.contains("payload")) {
				break;
			}
			
			try {
				Object result = context.getExpressionManager().evaluate(candidateExpression, message, true);
				if (result != null) {
					logEntry.put(logItemName, result.toString());
					return;
				}
			} catch (Exception e) {
				logger.debug("Expression " + candidateExpression + " was unsuccessful.");
			}
		}
	}
	
	/**
	 * Determine whether the payload is a Stream (i.e. can be consumed only once) or is a standard object
	 * @param payload
	 * @return
	 */
	private boolean isStream(Object payload) {
		if(payload instanceof Closeable) return true;
		return false;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	@Override
	public void setMuleContext(MuleContext context) {
		this.context = context;
		
	}

}
