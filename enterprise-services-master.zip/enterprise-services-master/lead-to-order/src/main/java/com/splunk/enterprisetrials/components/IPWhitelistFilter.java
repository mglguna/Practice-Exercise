package com.splunk.enterprisetrials.components;

import java.util.LinkedList;
import java.util.List;

import org.mule.api.MuleMessage;
import org.mule.api.routing.filter.Filter;


public class IPWhitelistFilter implements Filter {

	List<CidrNetwork> whitelist = new LinkedList<CidrNetwork>();
	String realIpHeader = "X-Real-IP";
	
	/**
	 * Parses the whitelist
	 * @param whitelist
	 */
	public void setWhitelist(String whitelist) {
		String [] whitelistEntries = whitelist.split(",");
		for (String whitelistEntry: whitelistEntries) {
			CidrNetwork subnet;
			
			if (whitelistEntry.contains("/")) {
				subnet = new CidrNetwork(whitelistEntry.trim());
			} else {
				subnet = new CidrNetwork(whitelistEntry.trim() + "/32");
			}
			this.whitelist.add(subnet);
		}
	}



	@Override
	public boolean accept(MuleMessage message) {
		String originAddressStr = this.getOriginAddress(message);
		
		for(CidrNetwork subnet: this.whitelist) {
			if (subnet.includes(originAddressStr)) return true;
		}
		return false;
	}
	
	private String getOriginAddress(MuleMessage message) {
		// First try the X-Real-IP header, created by CloudHub
		if (message.getInboundProperty(realIpHeader) != null) {
			return message.getInboundProperty(realIpHeader);
		}
		
		// In case we are running locally, try the IP address 
		// Mule thinks the connection is coming from
		String address = message.getInboundProperty("MULE_REMOTE_CLIENT_ADDRESS", "/0.0.0.0:0");
		address = address.substring(1, address.lastIndexOf(':'));
		return address;
	}
	
	
	/**
	 * Models a CIDR sub-network address
	 * @author Nahuel Lofeudo
	 *
	 */
	private static class CidrNetwork {
		private long network;
		private long mask;
		private long lowest;
		private long highest;
		
		public CidrNetwork (String cidr) {
			// Split network from netmask
			String [] parts = cidr.split("/");
			
			// Step 1. Convert IPs into ints (32 bits).
			int addr = parseAddress(parts[0]);
			 
			// Step 2. Get CIDR mask
			long mask = (((long)0xFFFFFFFF) << (32 - Integer.parseInt(parts[1])));
			
			this.network = addr;
			this.mask = mask;
			this.lowest = this.network & mask;
			this.highest = (this.network | ((long)(~mask))) & 0xFFFFFFFF;
		}
		
		public boolean includes (String address) {
			int ipAddress = this.parseAddress(address);
			if (ipAddress < this.lowest) return false;
			if (ipAddress > this.highest) return false;
			return true;
		}
		
		private int parseAddress(String address) {
			String [] ipParts = address.split("\\.");
			
			
			// Step 1. Convert IPs into ints (32 bits).
			int addr =  (( Integer.parseInt(ipParts[0]) << 24 ) & 0xFF000000)
			           | (( Integer.parseInt(ipParts[1]) << 16 ) & 0xFF0000)
			           | (( Integer.parseInt(ipParts[2]) << 8 ) & 0xFF00)
			           |  ( Integer.parseInt(ipParts[3]) & 0xFF);
		
			return addr;
		}
			
		public int getNetwork() {
			return (int)network;
		}
		public void setNetwork(int network) {
			this.network = network;
		}
		public int getMask() {
			return (int)mask;
		}
		public void setMask(int mask) {
			this.mask = mask;
		}	
	}
}
