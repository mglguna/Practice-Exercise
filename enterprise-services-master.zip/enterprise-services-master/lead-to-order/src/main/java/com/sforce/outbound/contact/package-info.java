@javax.xml.bind.annotation.XmlSchema(namespace = "http://soap.sforce.com/2005/09/outbound", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.sforce.outbound.contact;
