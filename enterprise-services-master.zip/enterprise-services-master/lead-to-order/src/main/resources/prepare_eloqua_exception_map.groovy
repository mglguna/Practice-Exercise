
msgVal=flowVars['exMessage']
exResponseMap=flowVars['exResponseMap']

exResponseMap.put('errorMessage',msgVal)

return exResponseMap