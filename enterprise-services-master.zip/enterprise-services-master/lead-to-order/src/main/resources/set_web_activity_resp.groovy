eloquaMap=flowVars['eloquaResponse']
sfdcMap=flowVars['sfdcResponse']

eloquaError = flowVars['eloquaError']
sfdcError = flowVars['sfdcError']

java.util.HashMap<String,String> webActRespMap = new java.util.HashMap<String,String>()
String sysErrorMessage = ""

if(eloquaError!=null){
	sysErrorMessage = "Eloqua web activity process failed."
	webActRespMap.put("eloquaError",eloquaError)
} else {
	sysErrorMessage = "Eloqua web activity process succeeded."
	webActRespMap.put("eloquaId",eloquaMap.get('responseId'))
}

if(sfdcError!=null){
	sysErrorMessage = sysErrorMessage + " SFDC web activity process failed."
	webActRespMap.put("sfdcError",sfdcError)
} else {
	sysErrorMessage = sysErrorMessage + " SFDC web activity process succeeded."
	webActRespMap.put("sfdcId",sfdcMap.get('objectId'))
}

if(eloquaError!=null || sfdcError!=null){
	message.setProperty('http.status',400)
	webActRespMap.put('statusCode','STS-400-Bad Request')
	webActRespMap.put('statusMessage','Operation Failed')
	webActRespMap.put('systemErrorMessage',sysErrorMessage)
} else {
	webActRespMap.put('statusCode','STS-200-SUCCESS')
	webActRespMap.put('statusMessage','Operation Succeeded')
}

webActRespMap.put('objectType','WebActivity')

return webActRespMap
