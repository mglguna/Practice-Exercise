
leadInputData = flowVars['leadAddInputMap']
if (leadInputData !=null && 
	leadInputData.get('addressList') !=null && 
	leadInputData.get('addressList').get('address') != null) {
	
	for (Object addressData in leadInputData.get('addressList').get('address')) {
			payload.put('region', addressData.get('region'));
			payload.put('geo', addressData.get('geo'));
			payload.put('subRegion', addressData.get('subRegion'));
			payload.put('area', addressData.get('area'));
		}
}

return payload
	