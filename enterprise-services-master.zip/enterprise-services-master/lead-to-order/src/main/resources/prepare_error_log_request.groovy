import java.util.HashMap

HashMap<String,String> errorRequestMap = new HashMap<String,String>()
exPayLoad=flowVars['exPayLoad']


errorRequestMap.put('objectId',exPayLoad.get('objectId'))
errorRequestMap.put('objectType',exPayLoad.get('objectType'))
errorRequestMap.put('messageId',message.getId())
message.setProperty('processFlowName',exPayLoad.get('processFlowName'))
message.setProperty('subFlowName',500)
message.setProperty('errorType','CloudHub')
message.setProperty('errorMessage',exception.getCauseException().toString())
message.setProperty('orginalPayload',exPayLoad.get('orginalPayload'))
message.setProperty('payloadAtException',payload)
message.setProperty('severity','High')
message.setProperty('exceptionDate','')
message.setProperty('environment','')
message.setProperty('transactionSource',exPayLoad.get('transactionSource'))
message.setProperty('transactionDestination',exPayLoad.get('transactionDestination'))

return errorRequestMap