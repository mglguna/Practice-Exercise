String where_clause=''
boolean isFirst = true
nameVal=flowVars['campaignName']

if (nameVal != null && nameVal !=''){
	where_clause += " Name = " + "'" + nameVal +"'"
	isFirst = false
}	

return where_clause