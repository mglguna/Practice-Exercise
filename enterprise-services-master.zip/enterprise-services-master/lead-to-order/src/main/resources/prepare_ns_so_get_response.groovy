
java.util.HashMap nsSOGetRespMap = new java.util.HashMap()
java.util.HashMap crossReferencesMap = new java.util.HashMap() 
nsSOGetRespMap.put('crossReferences', crossReferencesMap)

if (payload.getSearchRowList() != null && 
	payload.getSearchRowList().getSearchRow() != null && 
	payload.getSearchRowList().getSearchRow().size() > 0) {
	
	firstSearchRow = payload.getSearchRowList().getSearchRow().get(0)
	
	// Get Internal ID
	if (firstSearchRow.getBasic().getInternalId() != null &&
		firstSearchRow.getBasic().getInternalId().size() > 0 &&
		firstSearchRow.getBasic().getInternalId().get(0) != null) {
		
		internalId = firstSearchRow.getBasic().getInternalId().get(0).getSearchValue().getInternalId()
		println 'SO Internal Id from NS Get SO is: ' + internalId
		crossReferencesMap.put('netSuiteId', internalId)		
	}
}	

return nsSOGetRespMap