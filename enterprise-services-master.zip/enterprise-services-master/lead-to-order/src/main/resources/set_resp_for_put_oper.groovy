import java.util.HashMap

HashMap<String,String> putResponseMap = new HashMap<String,String>()

String objectId = ''
String targetSysError = '';
boolean isSuccess = false;

if(targetSystem.equals('NS')) {
	objectId = payload.getInternalId()
	isSuccess = (payload.getInternalId()!=null && payload.getInternalId()!='')
} else if(targetSystem.equals('SFDC')) {
	objectId = payload.getId()
	isSuccess = payload.getSuccess()
	targetSysError = payload.getErrors()
}

if(isSuccess){
	putResponseMap.put('statusCode','STS-200-SUCCESS')
	putResponseMap.put('objectId',objectId)
	putResponseMap.put('objectType',targetObjectType)
	putResponseMap.put('statusMessage','Object created/updated successfully')
} else {
	putResponseMap.put('statusCode','STS-400-BAD_REQUEST')
	if(targetSysError!=null && targetSysError!=''){
		putResponseMap.put('systemErrorMessage',targetSysError)
	}	
	putResponseMap.put('statusMessage','Object create/update failed')
	message.setProperty('http.status',400)
}

return putResponseMap