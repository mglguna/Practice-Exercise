
import java.util.HashMap

HashMap<String,String> errorLogDetailsMap = new HashMap<String,String>()
sessionVars['errorLogDetMap'] = errorLogDetailsMap

payloadMap = flowVars['payloadAsMap']

errorLogDetailsMap.put('originalPayload', payload)
errorLogDetailsMap.put('messageId',message.id)

errorLogDetailsMap.put('objectType',objectTypeVal)
errorLogDetailsMap.put('targetSystem',targetSystemVal)
errorLogDetailsMap.put('processName',processNameVal)

if(message.getInboundProperty('http.request.path')!=null) {
	errorLogDetailsMap.put('operationType',operationTypeVal + " - " + message.getInboundProperty('http.request.path'))
} else {
	errorLogDetailsMap.put('operationType',operationTypeVal)
}

if(isSourceTargetIdsValid.equals('true')){
	if(payloadMap.get(targetIdFieldVal)!=null && payloadMap.get(targetIdFieldVal)!=''){
		errorLogDetailsMap.put('targetObjectId',payloadMap.get(targetIdFieldVal))
	}

	if(payloadMap.get(sourceIdFieldVal)!=null && payloadMap.get(sourceIdFieldVal)!=''){
		errorLogDetailsMap.put('sourceObjectId',payloadMap.get(sourceIdFieldVal))
	}
}



errorLogDetailsMap.put('errorType',errorTypeVal)
errorLogDetailsMap.put('recordTypeId',recordTypeIdVal)
errorLogDetailsMap.put('functionalModule',functionalModuleVal)


sessionVars['errorLogDetMap'] = errorLogDetailsMap

return payload