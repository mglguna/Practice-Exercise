
import com.netsuite.webservices.lists.relationships_2014_1.ContactSearch
import com.netsuite.webservices.platform.common_2014_1.ContactSearchBasic
import com.netsuite.webservices.lists.relationships_2014_1.ContactSearchRow
import com.netsuite.webservices.platform.common_2014_1.ContactSearchRowBasic

import com.netsuite.webservices.platform.core_2014_1.SearchCustomFieldList
import com.netsuite.webservices.platform.core_2014_1.SearchCustomField
import com.netsuite.webservices.platform.core_2014_1.SearchStringCustomField
import com.netsuite.webservices.platform.core_2014_1.types.SearchStringFieldOperator
import com.netsuite.webservices.platform.core_2014_1.SearchColumnSelectField

import java.util.ArrayList
import java.util.HashMap

HashMap srchFlds = new HashMap()

ContactSearch cntctSrch = new ContactSearch()
ContactSearchBasic cntctSrchBasic = new ContactSearchBasic()

SearchCustomFieldList customFieldsList = new SearchCustomFieldList()
List<SearchCustomField> srchCustomFields = new ArrayList<SearchCustomField>()
SearchCustomField sfdcIdSrchCustomField = new SearchStringCustomField()
sfdcIdSrchCustomField.setScriptId("custentity_celigo_ns_sfdc_sync_id")
sfdcIdSrchCustomField.setOperator(SearchStringFieldOperator.IS)
sfdcIdSrchCustomField.setSearchValue(flowVars['crmId'])
srchCustomFields.add(sfdcIdSrchCustomField)
customFieldsList.setCustomField(srchCustomFields)
cntctSrchBasic.setCustomFieldList(customFieldsList)
cntctSrch.setBasic(cntctSrchBasic)

ContactSearchRow cntctSrchRow = new ContactSearchRow()
ContactSearchRowBasic cntctSrchRowBasic = new ContactSearchRowBasic()

List<SearchColumnSelectField> selReturnCols = new ArrayList<SearchColumnSelectField>(1)
selReturnCols.add(new SearchColumnSelectField())
// Set return columns
cntctSrchRowBasic.setInternalId(selReturnCols)
cntctSrchRow.setBasic(cntctSrchRowBasic)

srchFlds.put('criteria', cntctSrch)
srchFlds.put('columns', cntctSrchRow)

return srchFlds
