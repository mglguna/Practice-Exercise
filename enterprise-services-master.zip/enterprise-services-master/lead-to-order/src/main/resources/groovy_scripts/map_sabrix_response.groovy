import java.util.*

sabrixInputData = payload
HashMap<String, Object> sabrixdata = new HashMap<String, Object>()
List  taxLines = new ArrayList()
HashMap<String, Object> taxMap = new HashMap<String, Object>()
	if(	sabrixInputData.get('taxCalculationResponse') !=null &&
	   	sabrixInputData.get('taxCalculationResponse').get('OUTDATA') != null){
		outData=sabrixInputData.get('taxCalculationResponse').get('OUTDATA');
		reqStatus = outData.get('REQUEST_STATUS');
		sabrixdata.put('ResultCode', reqStatus.get('IS_SUCCESS'));
		if(outData.get('INVOICE') != null){
			invoice = outData.get('INVOICE');
			sabrixdata.put('DocCode', invoice.get('INVOICE_NUMBER'));
			sabrixdata.put('DocDate', invoice.get('INVOICE_DATE'));
			sabrixdata.put('CompanyCode', invoice.get('EXTERNAL_COMPANY_ID'));
			sabrixdata.put('CurrencyCode', invoice.get('CURRENCY_CODE'));
			sabrixdata.put('TotalTax', invoice.get('TOTAL_TAX_AMOUNT'));
			sabrixdata.put('TaxDate', invoice.get('TRANSACTION_DATE'));
			sabrixdata.put('CalculationDirection', invoice.get('CALCULATION_DIRECTION'));
			if(invoice.get('LINE') != null	){
				invoiceLine = invoice.get('LINE');
				ArrayList lineList = new ArrayList();
				if(invoiceLine instanceof java.util.ArrayList){
					lineList=invoiceLine;
				}else{
					lineList.add(invoiceLine);
				}
				for (Object line in lineList) {
					HashMap<String, Object> listOfLines = new HashMap<String, Object>()
					if(line.get("LINE_NUMBER")!=null){
							String lineNumber = (String) line.get("LINE_NUMBER");
							listOfLines.put("LineNo", new Double(lineNumber).intValue());
					}
					listOfLines.put('Description', line.get('DESCRIPTION'));
					listOfLines.put('Tax', line.get('TOTAL_TAX_AMOUNT'));
					if(line.get('TAX_SUMMARY')!=null){
						taxSummary =line.get('TAX_SUMMARY');
						listOfLines.put('Exemption', taxSummary.get('EXEMPT_AMOUNT'));
						listOfLines.put('Taxable', taxSummary.get('TAXABLE_BASIS'));
						listOfLines.put('Rate', taxSummary.get('TAX_RATE'));
						listOfLines.put("nonTaxable", taxSummary.get('NON_TAXABLE_BASIS'));
					}
					def tax
					taxlistorobj = line.get('TAX');
					if(line.get('TAX') instanceof java.util.ArrayList){
						tax = taxlistorobj.get(0)
					}else{
						tax = taxlistorobj
					}
					if(tax !=null){
						listOfLines.put('CertificateNumber', tax.get('EXEMPT_CERTIFICATE'));
						listOfLines.put('sellerRegistrationNumber', tax.get('SELLER_REGISTRATION'));
						listOfLines.put('BuyerRegistration', tax.get('BUYER_REGISTRATION'));
						listOfLines.put('TaxCode', tax.get('ERP_TAX_CODE'));
						listOfLines.put('TaxDirection', tax.get('TAX_DIRECTION'));
						listOfLines.put('TaxTreatment', tax.get('TAX_TREATMENT'));
						listOfLines.put('TaxType', tax.get('TAX_TYPE'));
						listOfLines.put('AuthorityType', tax.get('AUTHORITY_NAME'));
						if(tax.get('TAX_AMOUNT')!=null){
							listOfLines.put('RoundedTax', tax.get('TAX_AMOUNT').get('DOCUMENT_AMOUNT'));
						}
					}
					taxLines.add(listOfLines)
					}	
				}
			}
		}	
	sabrixdata.put('TaxLines',taxLines );
	return sabrixdata    