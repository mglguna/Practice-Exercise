java.util.HashMap sfdcUpdateDataMap = new java.util.HashMap()

java.util.HashMap crossRefsMap = new java.util.HashMap()
crossRefsMap.put('crmId',flowVars['sfdcSubscripId'])

if(isErrorFlow.equals('false') && payload.get('objectId')!=null && payload.get('objectId')!=''){
	crossRefsMap.put('netSuiteId',payload.get('objectId'))
}	

sfdcUpdateDataMap.put('crossReferences', crossRefsMap)

if(exception!=null && exception.getCauseException()!=null){
	sfdcUpdateDataMap.put('netSuiteSyncText', flowVars['subscripErrorMsg'])
}

return sfdcUpdateDataMap