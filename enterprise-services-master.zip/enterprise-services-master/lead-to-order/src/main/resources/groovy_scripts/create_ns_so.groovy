
import com.netsuite.webservices.platform.core_2014_1.*
import com.netsuite.webservices.transactions.sales_2014_1.*
import com.netsuite.webservices.transactions.sales_2014_1.types.*
import com.netsuite.webservices.platform.common_2014_1.BillAddress
import com.netsuite.webservices.platform.common_2014_1.ShipAddress
import 	com.netsuite.webservices.platform.common_2014_1.types.Country

import javax.xml.datatype.XMLGregorianCalendar
import javax.xml.datatype.DatatypeFactory
import java.util.*
import java.text.SimpleDateFormat

import org.mule.construct.Flow
import org.mule.DefaultMuleEvent
import org.mule.DefaultMuleMessage
import org.mule.api.MuleEvent
import org.mule.api.MuleMessage
import org.mule.MessageExchangePattern

import org.mule.module.apikit.exception.BadRequestException

sfdcData = payload

HashMap<String, Object> salesOrderMap = new HashMap<String, Object>()
List<CustomFieldRef> customFieldRefs = new ArrayList<CustomFieldRef>()
SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd")
//SimpleDateFormat expDateFormat= new SimpleDateFormat("MM/yyyy")
SimpleDateFormat licenseDatesFormat= new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ")
//licenseDatesFormat.setTimeZone(TimeZone.getTimeZone("PST"))

//Flow salesRepLookupflow = (Flow)muleContext.getRegistry().lookupFlowConstruct("ns_salesrep_lookup_flow");

List endUserOppTypesList = endUserOppTypesStr.tokenize(',')
List resellerOppTypesList = resellerOppTypesStr.tokenize(',')
List distributorOppTypesList = distributorOppTypesStr.tokenize(',')

//println "endUserOppTypesList is: " + endUserOppTypesList
//println "resellerOppTypesList is: " + resellerOppTypesList
//println "distributorOppTypesList is: " + distributorOppTypesList

boolean isUpdate = false
// NetSuite Id
if(sfdcData.get('salesOrder')!=null && sfdcData.get('salesOrder').get('netSuiteId')!=null) {
	salesOrderMap.put('internalId', sfdcData.get('salesOrder').get('netSuiteId'))
	isUpdate = true
}

// Order Status
/*if(sfdcData.get('orderStatus')!=null && sfdcData.get('orderStatus')!='') {
	salesOrderMap.put('orderStatus',sfdcData.get('orderStatus'))
} else {
	salesOrderMap.put('orderStatus',SalesOrderOrderStatus.PENDING_FULFILLMENT)
}*/

// Stripe Charge Id
if(sfdcData.get('stripeChargeId')!=null && sfdcData.get('stripeChargeId')!='') {
	StringCustomFieldRef stripeChgId = new StringCustomFieldRef()
	stripeChgId.setValue(sfdcData.get('stripeChargeId'))
	stripeChgId.setScriptId('custbody_spk_stripe_chg_id')
	customFieldRefs.add(stripeChgId)
}

// Stripe Customer Id
if(sfdcData.get('stripeCustomerId')!=null && sfdcData.get('stripeCustomerId')!='') {
	StringCustomFieldRef stripeCustId = new StringCustomFieldRef()
	stripeCustId.setValue(sfdcData.get('stripeCustomerId'))
	stripeCustId.setScriptId('custbody_spk_stripe_cust_id')
	customFieldRefs.add(stripeCustId)
}

// Stripe Plan Id
if(sfdcData.get('stripePlanId')!=null && sfdcData.get('stripePlanId')!='') {
	StringCustomFieldRef stripePlnId = new StringCustomFieldRef()
	stripePlnId.setValue(sfdcData.get('stripePlanId'))
	stripePlnId.setScriptId('custbody_spk_stripe_plan_id')
	customFieldRefs.add(stripePlnId)
}

// Stripe Subscription Id
if(sfdcData.get('stripeSubscriptionId')!=null && sfdcData.get('stripeSubscriptionId')!='') {
	StringCustomFieldRef stripeSubscrId = new StringCustomFieldRef()
	stripeSubscrId.setValue(sfdcData.get('stripeSubscriptionId'))
	stripeSubscrId.setScriptId('custbody_spk_stripe_subscription_id')
	customFieldRefs.add(stripeSubscrId)
}

// Web Sales Total Tax
if(sfdcData.get('totalTax')!=null && sfdcData.get('totalTax')!='') {
	DoubleCustomFieldRef webSalesTotalTax = new DoubleCustomFieldRef()
	webSalesTotalTax.setValue(Double.parseDouble(sfdcData.get('totalTax')))
	webSalesTotalTax.setScriptId('custbody_spk_web_sale_total_tax')
	customFieldRefs.add(webSalesTotalTax)
}

boolean isEcommerceReq = false
if(sfdcData.get('isEcommerceReq')!=null && sfdcData.get('isEcommerceReq')){
		isEcommerceReq = true
}

// ******* START: CPQ-239 Changes *********
// Sales Rep Email
if(sfdcData.get('salesRepEmail')!=null && sfdcData.get('salesRepEmail')!='') {

	RecordRef salesRepObj = new RecordRef()
	salesRepObj.setInternalId(sfdcData.get('salesRepEmail'))
	salesOrderMap.put('salesRep',salesRepObj)	

	/*HashMap reqMap = new HashMap()
	reqMap.put("salesRepEmail",sfdcData.get('salesRepEmail'));
	MuleEvent event = new DefaultMuleEvent(new DefaultMuleMessage(reqMap, muleContext),
	        MessageExchangePattern.REQUEST_RESPONSE, salesRepLookupflow);
	MuleEvent resultEvent = salesRepLookupflow.process(event)
	if(resultEvent!=null && resultEvent.getMessage()!=null && 
		!(resultEvent.getMessage().getPayload() instanceof org.mule.transport.NullPayload) &&
			resultEvent.getMessage().getPayload().get('internalId')!=null) {
		
		RecordRef salesRepObj = new RecordRef()
		salesRepObj.setInternalId(resultEvent.getMessage().getPayload().get('internalId'))
		salesOrderMap.put('salesRep',salesRepObj)
		
	} else { // CPQ-80: To throw data validation error 
		sessionVars['dataValidationError'] = true
		throw new BadRequestException('[SFDC Field: Owner.Email]: Could not find instance in netsuite value lookup: '+sfdcData.get('salesRepEmail')+' {Source:Employee {Key Field:email}}');
	}*/
}
// ******* END: CPQ-239 Changes *********


// Sales Rep
/*if(sfdcData.get('salesRep')!=null && sfdcData.get('salesRep')!='') {
	RecordRef salesRepObj = new RecordRef()
	//salesRepObj.setName(sfdcData.get('salesRep').get('name'))
	if(sfdcData.get('salesRep').get('netSuiteId') != null && sfdcData.get('salesRep').get('netSuiteId') != '') {
		salesRepObj.setInternalId(sfdcData.get('salesRep').get('netSuiteId'))
	} else {
		salesRepObj.setName(sfdcData.get('salesRep').get('name'))
	}
	salesOrderMap.put('salesRep',salesRepObj)
}*/

// Opportunity Type
/*if(sfdcData.get('opportunityType')!=null && sfdcData.get('opportunityType')!='') {
	ListOrRecordRef oppTypeObj = new ListOrRecordRef()
	oppTypeObj.setName(sfdcData.get('opportunityType'))
	SelectCustomFieldRef oppTypeSel = new SelectCustomFieldRef()
	oppTypeSel.setValue(oppTypeObj)
	oppTypeSel.setScriptId("custbody_opportunity_type")
	customFieldRefs.add(oppTypeSel)
}*/


//Changes for ENHC0052063 starts

// Sales District
if(sfdcData.get('salesDistrict')!=null && sfdcData.get('salesDistrict')!='') {
	StringCustomFieldRef salesDist = new StringCustomFieldRef()
	salesDist.setValue(sfdcData.get('salesDistrict'))
	salesDist.setScriptId('custbody_spk_sales_district1')
	customFieldRefs.add(salesDist)
}

// Sub District
if(sfdcData.get('subDistrict')!=null && sfdcData.get('subDistrict')!='') {
	StringCustomFieldRef subDist = new StringCustomFieldRef()
	subDist.setValue(sfdcData.get('subDistrict'))
	subDist.setScriptId('custbody_sales_district')
	customFieldRefs.add(subDist)
}

// Sub Theater
if(sfdcData.get('subTheatre')!=null && sfdcData.get('subTheatre')!='') {
	StringCustomFieldRef salesReg = new StringCustomFieldRef()
	salesReg.setValue(sfdcData.get('subTheatre'))
	salesReg.setScriptId('custbody_sales_region')	
	customFieldRefs.add(salesReg)
}

// Sales Theatre
if(sfdcData.get('salesTheatre')!=null && sfdcData.get('salesTheatre')!='') {
	StringCustomFieldRef salesTheatre = new StringCustomFieldRef()
	salesTheatre.setValue(sfdcData.get('salesTheatre'))
	salesTheatre.setScriptId('custbody_sales_theater')
	customFieldRefs.add(salesTheatre)
}

//Changes for ENHC0052063 ends


// Bill To Tier
ListOrRecordRef billToTierObj = new ListOrRecordRef()
if(sfdcData.get('billToTierIntId')!=null && sfdcData.get('billToTierIntId')!='') {
	/*if(endUserOppTypesList.contains(sfdcData.get('opportunityType'))){
		billToTierObj.setInternalId("1") // End User
	} else if(distributorOppTypesList.contains(sfdcData.get('opportunityType'))){
		billToTierObj.setInternalId("3") // Distributor
	} else if(resellerOppTypesList.contains(sfdcData.get('opportunityType'))){
		billToTierObj.setInternalId("2") // Reseller
	}*/
	
	billToTierObj.setInternalId(sfdcData.get('billToTierIntId'))
	
	SelectCustomFieldRef billToTierSel = new SelectCustomFieldRef()
	billToTierSel.setValue(billToTierObj)
	billToTierSel.setScriptId("custbody_bill_to_tier")
	customFieldRefs.add(billToTierSel)
}

// Bill To Customer
/*RecordRef entityObj = new RecordRef()
entityObj.setInternalId(sfdcData.get('account').get('netSuiteId'))
salesOrderMap.put('entity',entityObj)*/

// Start Date - Opportunity start date will be set if present, otherwise current date will be set
if(sfdcData.get('opportunityStartDate')!=null && sfdcData.get('opportunityStartDate')!='') {
	GregorianCalendar gc1 = new GregorianCalendar()
	Date oppStartDate = licenseDatesFormat.parse(sfdcData.get('opportunityStartDate'))
	gc1.setTimeInMillis(oppStartDate.getTime())
	XMLGregorianCalendar xgc1 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc1)
	salesOrderMap.put('startDate',xgc1)	
}
/* else {
	gc1.setTimeInMillis((new Date()).getTime())
}*/

// End Date - Opportunity end date will be set if present
if(sfdcData.get('opportunityEndDate')!=null && sfdcData.get('opportunityEndDate')!='') {
	GregorianCalendar gc5 = new GregorianCalendar()
	Date oppEndDate = licenseDatesFormat.parse(sfdcData.get('opportunityEndDate'))
	gc5.setTimeInMillis(oppEndDate.getTime())
	XMLGregorianCalendar xgc5 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc5)
	salesOrderMap.put('endDate',xgc5)
}

// **************************** START: CPQ-196 ****************************
// Distributor/Reseller/End User

RecordRef entityObj = new RecordRef()

if(sfdcData.get('channelAccounts')!=null) {
	for (Object channelAccount in sfdcData.get('channelAccounts')) {
		if(channelAccount.get('netSuiteId')!=null) {
			ListOrRecordRef channelCustObj = new ListOrRecordRef()
			channelCustObj.setInternalId(channelAccount.get('netSuiteId'))
			SelectCustomFieldRef channelCustSel = new SelectCustomFieldRef()
			channelCustSel.setValue(channelCustObj)
			
			if(("Reseller").equalsIgnoreCase(channelAccount.get('accountType'))) {				
				channelCustSel.setScriptId("custbody_reseller")
				if(billToTierObj.getInternalId().equals('2')){
					entityObj.setInternalId(channelAccount.get('netSuiteId'))
				}	
			}
			
			if(("Distributor").equalsIgnoreCase(channelAccount.get('accountType'))) {				
				channelCustSel.setScriptId("custbody_distributor")
				if(billToTierObj.getInternalId().equals('3')){
					entityObj.setInternalId(channelAccount.get('netSuiteId'))
				}	
			}			
			
			customFieldRefs.add(channelCustSel)
		}
	}
}

// End User
if(sfdcData.get('account')!=null && sfdcData.get('account').get('netSuiteId')!=null){
	ListOrRecordRef endUserCustObj = new ListOrRecordRef()
	endUserCustObj.setInternalId(sfdcData.get('account').get('netSuiteId'))
	SelectCustomFieldRef endUserCustSel = new SelectCustomFieldRef()
	endUserCustSel.setValue(endUserCustObj)
	endUserCustSel.setScriptId("custbody_end_user")
	customFieldRefs.add(endUserCustSel)
	
	if(billToTierObj.getInternalId().equals('1') || entityObj.getInternalId()==null){
		entityObj.setInternalId(sfdcData.get('account').get('netSuiteId'))
	}	
}

if(entityObj.getInternalId()!=null && entityObj.getInternalId()!=''){
	salesOrderMap.put('entity',entityObj)
}

// **************************** END: CPQ-196 ****************************

if(sfdcData.get('opportunityId')!=null && sfdcData.get('opportunityId')!='') {
	StringCustomFieldRef celigoSyncId = new StringCustomFieldRef()
	celigoSyncId.setValue(sfdcData.get('opportunityId'))
	celigoSyncId.setScriptId('custbody_celigo_ns_sfdc_sync_id')
	customFieldRefs.add(celigoSyncId)
}

//  ********************************************** SO Items: START **********************************************
List<SalesOrderItem> saleItems = new ArrayList<SalesOrderItem>()
boolean isLicHdrDetailsSet = false
boolean isLineIndexPresent = false
//long maxTermInMonths = 0
// Iterate over each Opportunity Product and create Item for SO 	
for (Object oppProd in sfdcData.opportunityProducts) {
//	String itemNSId = oppProd.get('pricebookEntry').product.netSuiteId
//	if(itemNSId != null && itemNSId != ''){
		List<CustomFieldRef> itemCustFieldRefs = new ArrayList<CustomFieldRef>()	
		SalesOrderItem  saleItem = new SalesOrderItem()
		
		// Line Index
		if(oppProd.get('lineItemIndex')!=null) {
			isLineIndexPresent=true
			saleItem.setLine(oppProd.get('lineItemIndex'))
		}

				
		// Item NS Id
		if(oppProd.get('pricebookEntry')!=null && 
				oppProd.get('pricebookEntry').product!=null && 
				oppProd.get('pricebookEntry').product.netSuiteId!=null) {
			RecordRef itemObj = new RecordRef()
			itemObj.setInternalId(oppProd.get('pricebookEntry').product.netSuiteId)
			saleItem.setItem(itemObj)
		}
		
		// Opp Line Item Id
		if(oppProd.get('id')!=null && oppProd.get('id')!='') {
			StringCustomFieldRef oppLineItemId = new StringCustomFieldRef()
			oppLineItemId.setValue(oppProd.get('id'))
			oppLineItemId.setScriptId('custcol_sfdcopplineid')
			itemCustFieldRefs.add(oppLineItemId)		
		}
		
		// Web Sales Item Tax Amount
		if(oppProd.get('taxAmount')!=null && oppProd.get('taxAmount')!='') {
			DoubleCustomFieldRef webSalesTotalTax = new DoubleCustomFieldRef()
			webSalesTotalTax.setValue(Double.parseDouble(oppProd.get('taxAmount')))
			webSalesTotalTax.setScriptId('custcol_spk_web_sale_item_tax')
			itemCustFieldRefs.add(webSalesTotalTax)
		}
		
		// Web Sales Item Tax Rate
		if(oppProd.get('taxRate')!=null && oppProd.get('taxRate')!='') {
			StringCustomFieldRef webSalesItemTaxRate = new StringCustomFieldRef()
			webSalesItemTaxRate.setValue(oppProd.get('taxRate'))
			webSalesItemTaxRate.setScriptId('custcol_spk_ws_item_tax_rate')
			itemCustFieldRefs.add(webSalesItemTaxRate)
		}
		
		if(oppProd.get('salesPrice')!=null && oppProd.get('salesPrice')!='') {
			// Price Level 
			RecordRef priceLevelObj = new RecordRef()
			priceLevelObj.setInternalId("-1") // Custom
			saleItem.setPrice(priceLevelObj)
			
			// Rate
			saleItem.setRate(oppProd.get('salesPrice'))
			
			// Amount
			//saleItem.setAmount(new Double(oppProd.get('salesPrice')))
			
			// List Rate
			StringCustomFieldRef listRate = new StringCustomFieldRef()
			listRate.setValue(oppProd.get('salesPrice'))
			listRate.setScriptId('custcol_list_rate')
			itemCustFieldRefs.add(listRate)			
		}
		
		// SFDC Discount %
		if(oppProd.get('discountPercent')!=null && oppProd.get('discountPercent')!='') {
			StringCustomFieldRef sfdcDiscPercent = new StringCustomFieldRef()
			sfdcDiscPercent.setValue(oppProd.get('discountPercent'))
			sfdcDiscPercent.setScriptId('custcol_salesforce_discount')
			itemCustFieldRefs.add(sfdcDiscPercent)
		}
		
		// Base Product Code
		if(oppProd.get('baseProdNetSuiteId')!=null && oppProd.get('baseProdNetSuiteId')!='') {
			ListOrRecordRef baseProductObj = new ListOrRecordRef()
			baseProductObj.setInternalId(oppProd.get('baseProdNetSuiteId'))
			SelectCustomFieldRef baseProductSel = new SelectCustomFieldRef()
			baseProductSel.setValue(baseProductObj)
			baseProductSel.setScriptId("custcol_spk_baseproduct")
			itemCustFieldRefs.add(baseProductSel)
		}
		
		// Quantity
		if(oppProd.get('quantity')!=null && oppProd.get('quantity')!='') {
			saleItem.setQuantity(new Double(oppProd.get('quantity')))		
		}
		
		oppProdLicData = oppProd.get('licenseDetails')		
		// License Start Date
		if (oppProdLicData!=null && oppProdLicData.get('licenseStartDate') != null) {
			Date sfdcLicenseStartDate = licenseDatesFormat.parse(oppProdLicData.get('licenseStartDate'))
			GregorianCalendar gc3 = new GregorianCalendar()
			gc3.setTime(sfdcLicenseStartDate)
			
			// set to Pacific time zone
      		gc3.setTimeZone(TimeZone.getTimeZone("PST"));
      		
			XMLGregorianCalendar xgc3 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc3)
			xgc3.setTime(0,0,0)
	    	DateCustomFieldRef nsLicenseStartDate = new DateCustomFieldRef()
	        nsLicenseStartDate.setValue(xgc3)
	        nsLicenseStartDate.setScriptId('custcol_license_start_date')
	        itemCustFieldRefs.add(nsLicenseStartDate)
	        println 'NS License Start Date: ' + nsLicenseStartDate.getValue()
	     }
	     
	    // License End Date
		if (oppProdLicData!=null && oppProdLicData.get('licenseEndDate') != null) {
			Date sfdcLicenseEndDate = licenseDatesFormat.parse(oppProdLicData.get('licenseEndDate'))
			GregorianCalendar gc4 = new GregorianCalendar()
			gc4.setTime(sfdcLicenseEndDate)
			
			// set to Pacific time zone
      		gc4.setTimeZone(TimeZone.getTimeZone("PST"));
      		
			XMLGregorianCalendar xgc4 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc4)
			xgc4.setTime(0,0,0)	
	    	DateCustomFieldRef nsLicenseEndDate = new DateCustomFieldRef()
	        nsLicenseEndDate.setValue(xgc4)
	        nsLicenseEndDate.setScriptId('custcol_license_end_date')
	        itemCustFieldRefs.add(nsLicenseEndDate)
	        println 'NS License End Date: ' + nsLicenseEndDate.getValue()
	     }
	     
	     // ******* START: CPQ-240 Changes *********
		 // Term In Days	     
	     if (oppProdLicData!=null && oppProdLicData.get('termInDays') != null && 
	     		oppProdLicData.get('termInDays') != '') {
			LongCustomFieldRef oppProdTermInDaysObj = new LongCustomFieldRef()
			oppProdTermInDaysObj.setValue(Long.parseLong(oppProdLicData.get('termInDays')))
			oppProdTermInDaysObj.setScriptId('custcol_spk_licenseterm')
			itemCustFieldRefs.add(oppProdTermInDaysObj)
	     }
	     // ******* END: CPQ-240 Changes *********	     
	     
	     //Max termInMonths for header	     
	     /*if (oppProdLicData!=null && oppProdLicData.get('termInMonths') != null && 
	     		oppProdLicData.get('termInMonths') != '') {
	     	long oppProdTermInMonths = Long.parseLong(oppProdLicData.get('termInMonths'))
	     	if(oppProdTermInMonths > maxTermInMonths) {
	     		maxTermInMonths = oppProdTermInMonths
	     	}	
	     }*/
	     
	     //  ******************************************* License details in header: START *******************************************
	     if (oppProdLicData!=null && !isLicHdrDetailsSet && oppProdLicData.get('id')!=null && oppProdLicData.get('id')!='') {
	     	// License Delivery Status to "Completed"
			ListOrRecordRef licenseDelObj = new ListOrRecordRef()
			licenseDelObj.setInternalId("1") // Completed
			licenseDelObj.setName("Completed")
			SelectCustomFieldRef licenseDelSel = new SelectCustomFieldRef()
			licenseDelSel.setValue(licenseDelObj)
			licenseDelSel.setScriptId("custbody_license_delivery_status")
			customFieldRefs.add(licenseDelSel)
			
			// License Delivery Date
			DateCustomFieldRef licenseDelDate = new DateCustomFieldRef()
			licenseDelDate.setScriptId('custbody_license_delivery_date')
			GregorianCalendar gc2 = new GregorianCalendar()
			// START: Fix for ECOM-79: The License Delivery Date on the SO header should be SO Start Date, for eCommerce Orders
			if(isEcommerceReq && sfdcData.get('opportunityStartDate')!=null && sfdcData.get('opportunityStartDate')!=''){
				Date licDelDate = licenseDatesFormat.parse(sfdcData.get('opportunityStartDate'))
				gc2.setTimeInMillis(licDelDate.getTime())
			} else {
				gc2.setTime(new Date())
			}	
			// END: Fix for ECOM-79	
			XMLGregorianCalendar xgc2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc2)
			licenseDelDate.setValue(xgc2)
			customFieldRefs.add(licenseDelDate)
			
			// License GUID
			if(oppProdLicData.get('guid')!=null && oppProdLicData.get('guid')!=''){
				StringCustomFieldRef licenseGuid = new StringCustomFieldRef()
				licenseGuid.setValue(oppProdLicData.get('guid'))
				licenseGuid.setScriptId('custbody_guid')
				customFieldRefs.add(licenseGuid)
			}
			
			// License CRM Id
			if(oppProdLicData.get('id')!=null && oppProdLicData.get('id')!=''){
				StringCustomFieldRef licenseCRMid = new StringCustomFieldRef()
				licenseCRMid.setValue(oppProdLicData.get('id'))
				licenseCRMid.setScriptId('custbody_crm_license_id')
				customFieldRefs.add(licenseCRMid)
			}
			
			// License Delivery Email
			if(oppProdLicData.get('licenseDeliveryEmail')!=null && oppProdLicData.get('licenseDeliveryEmail')!=''){
				StringCustomFieldRef licenseDelEmail = new StringCustomFieldRef()
				licenseDelEmail.setValue(oppProdLicData.get('licenseDeliveryEmail'))
				licenseDelEmail.setScriptId('custbody_license_delivery_email')
				customFieldRefs.add(licenseDelEmail)
			}
			isLicHdrDetailsSet = true	     
	     }
		//  ******************************************** License details in header: END ********************************************
	     
		// ********************************** Changes for New attributes of CPQ at line item *****************************************
		
		 // Term In Months	     
	     if (oppProdLicData!=null && oppProdLicData.get('termInMonths') != null && 
	     		oppProdLicData.get('termInMonths') != '') {
	     	long oppProdTermInMonths = Long.parseLong(oppProdLicData.get('termInMonths'))
	     	saleItem.setRevRecTermInMonths(oppProdTermInMonths)
	     }
	     
	     // Memo
		if(oppProd.get('memoText')!=null && oppProd.get('memoText')!='') {
			StringCustomFieldRef prodMemoTextObj = new StringCustomFieldRef()
			prodMemoTextObj.setValue(oppProd.get('memoText'))
			prodMemoTextObj.setScriptId('custcol_memo')
			itemCustFieldRefs.add(prodMemoTextObj)
		}
		
		// Bundle
		if(oppProd.get('isBundle')!=null && oppProd.get('isBundle')!='') {
			BooleanCustomFieldRef isBundleObj = new BooleanCustomFieldRef()
			isBundleObj.setValue(oppProd.get('isBundle'))
			isBundleObj.setScriptId('custcol_bundle')
			itemCustFieldRefs.add(isBundleObj)
		}
		
		// ******* START: CPQ-1120 Changes *********//
		
		// hideInProposal 
		if(oppProd.get('hideInProposal')!=null && oppProd.get('hideInProposal')!='') {
			BooleanCustomFieldRef hideInProposalObj = new BooleanCustomFieldRef()
			hideInProposalObj.setValue(oppProd.get('hideInProposal'))
			hideInProposalObj.setScriptId('custcol_spk_hide_on_proposal')
			itemCustFieldRefs.add(hideInProposalObj)
		}
		
		// ******* END: CPQ-1120 Changes *********//
		
		// Celigo Item Group Internal Id
		if(oppProd.get('celigoGrpIntId')!=null && oppProd.get('celigoGrpIntId')!='') {
			DoubleCustomFieldRef celigoGrpIntIdObj = new DoubleCustomFieldRef()
			celigoGrpIntIdObj.setValue(oppProd.get('celigoGrpIntId'))
			celigoGrpIntIdObj.setScriptId('custcol_celigo_group_item_internal_id')
			itemCustFieldRefs.add(celigoGrpIntIdObj)
		}
		
		// Celigo Item Group Quantity
		if(oppProd.get('celigoGrpQuantity')!=null && oppProd.get('celigoGrpQuantity')!='') {
			DoubleCustomFieldRef celigoGrpQuantityObj = new DoubleCustomFieldRef()
			celigoGrpQuantityObj.setValue(oppProd.get('celigoGrpQuantity'))
			celigoGrpQuantityObj.setScriptId('custcol_celigo_group_item_quantity')
			itemCustFieldRefs.add(celigoGrpQuantityObj)
		}
		
		// Peak Daily Volume (GBs)
		if(oppProd.get('peakDailyVol')!=null && oppProd.get('peakDailyVol')!='') {
			DoubleCustomFieldRef peakDailyVolObj = new DoubleCustomFieldRef()
			peakDailyVolObj.setValue(oppProd.get('peakDailyVol'))
			peakDailyVolObj.setScriptId('custcol_peak_daily_vol_gb')
			itemCustFieldRefs.add(peakDailyVolObj)
		}
		
		// Number of Nodes
		if(oppProd.get('noOfNodes')!=null && oppProd.get('noOfNodes')!='') {
			LongCustomFieldRef noOfNodesObj = new LongCustomFieldRef()
			noOfNodesObj.setValue(oppProd.get('noOfNodes'))
			noOfNodesObj.setScriptId('custcol_number_of_nodes')
			itemCustFieldRefs.add(noOfNodesObj)
		}

		
		//Changes for BIZ-1091 start
		// Proposal Sequence
		if(oppProd.get('sortSeqNum')!=null && oppProd.get('sortSeqNum')!='') {
			LongCustomFieldRef proposalSeqObj = new LongCustomFieldRef()
			proposalSeqObj.setValue(oppProd.get('sortSeqNum'))
			proposalSeqObj.setScriptId('custcol_proposal_sequence')
			itemCustFieldRefs.add(proposalSeqObj)
		}
		
		//Changes for BIZ-1091 ends


		
		// Retention Days
		if(oppProd.get('retentionDays')!=null && oppProd.get('retentionDays')!='') {
			LongCustomFieldRef retentionDaysObj = new LongCustomFieldRef()
			retentionDaysObj.setValue(oppProd.get('retentionDays'))
			retentionDaysObj.setScriptId('custcol_retention_days')
			itemCustFieldRefs.add(retentionDaysObj)
		}								
		
		// ******* START: CPQ-98 Changes *********
		// Allocation %
		if(oppProd.get('allocationPercent')!=null && oppProd.get('allocationPercent')!='') {
			StringCustomFieldRef allocationPercentObj = new StringCustomFieldRef()
			allocationPercentObj.setValue(oppProd.get('allocationPercent'))
			allocationPercentObj.setScriptId('custcol_spk_allocationpercent')
			itemCustFieldRefs.add(allocationPercentObj)
		}
		
		// Base Bundle Code
		if(oppProd.get('baseBundleCode')!=null && oppProd.get('baseBundleCode')!='') {
			StringCustomFieldRef baseBundleCodeObj = new StringCustomFieldRef()
			baseBundleCodeObj.setValue(oppProd.get('baseBundleCode'))
			baseBundleCodeObj.setScriptId('custcol_spk_basebundlecode')
			itemCustFieldRefs.add(baseBundleCodeObj)
		}
		
		// Asset Group
		if(oppProd.get('assetGroup')!=null && oppProd.get('assetGroup')!='') {
			StringCustomFieldRef assetGroupObj = new StringCustomFieldRef()
			assetGroupObj.setValue(oppProd.get('assetGroup'))
			assetGroupObj.setScriptId('custcol_spk_assetgroup')
			itemCustFieldRefs.add(assetGroupObj)
		}	
		// ******* END: CPQ-98 Changes *********	
		
		// ******* START: CPQ-133 Changes *********
		// One Time Discount
		if(oppProd.get('oneTimeDiscount')!=null && oppProd.get('oneTimeDiscount')!='') {
			DoubleCustomFieldRef oneTimeDiscountObj = new DoubleCustomFieldRef()
			oneTimeDiscountObj.setValue(Double.parseDouble(oppProd.get('oneTimeDiscount')))
			oneTimeDiscountObj.setScriptId('custcol_spk_onetimediscount')
			itemCustFieldRefs.add(oneTimeDiscountObj)
		}
		
		// Extended Sales Price
		if(oppProd.get('extendedSalesPrice')!=null && oppProd.get('extendedSalesPrice')!='') {
			DoubleCustomFieldRef extendedSalesPriceObj = new DoubleCustomFieldRef()
			extendedSalesPriceObj.setValue(Double.parseDouble(oppProd.get('extendedSalesPrice')))
			extendedSalesPriceObj.setScriptId('custcol_spk_extendedsalesprice')
			itemCustFieldRefs.add(extendedSalesPriceObj)
		}
		// ******* END: CPQ-133 Changes *********			
		
		// ******* START: CPQ-115 Changes *********
		// Proposal Name
		if(oppProd.get('proposalName')!=null && oppProd.get('proposalName')!='') {
			StringCustomFieldRef proposalNameObj = new StringCustomFieldRef()
			proposalNameObj.setValue(oppProd.get('proposalName'))
			proposalNameObj.setScriptId('custcol_spk_proposalname')
			itemCustFieldRefs.add(proposalNameObj)
		}		
		// ******* END: CPQ-115 Changes *********		
		
		// ******* START: CPQ-129 Changes *********
		// Revenue Unit Price
		if(oppProd.get('revenueUnitPrice')!=null && oppProd.get('revenueUnitPrice')!='') {
			DoubleCustomFieldRef revenueUnitPriceObj = new DoubleCustomFieldRef()
			revenueUnitPriceObj.setValue(Double.parseDouble(oppProd.get('revenueUnitPrice')))
			revenueUnitPriceObj.setScriptId('custcol_spk_revenue_unitprice')
			itemCustFieldRefs.add(revenueUnitPriceObj)
		}
		
		// Revenue Sales Price
		if(oppProd.get('revenueSalesPrice')!=null && oppProd.get('revenueSalesPrice')!='') {
			DoubleCustomFieldRef revenueSalesPriceObj = new DoubleCustomFieldRef()
			revenueSalesPriceObj.setValue(Double.parseDouble(oppProd.get('revenueSalesPrice')))
			revenueSalesPriceObj.setScriptId('custcol_spk_revenue_salesprice')
			itemCustFieldRefs.add(revenueSalesPriceObj)
		}				
		// ******* END: CPQ-129 Changes *********			
	    
	    // ******* START: CPQ-193 Changes *********
		// Previous Inv No
		if(oppProd.get('previousInvNo')!=null && oppProd.get('previousInvNo')!='') {
			StringCustomFieldRef previousInvNoObj = new StringCustomFieldRef()
			previousInvNoObj.setValue(oppProd.get('previousInvNo'))
			previousInvNoObj.setScriptId('custcol_spk_previousinvnumber')
			itemCustFieldRefs.add(previousInvNoObj)
		}
		
		// Previous PO No
		if(oppProd.get('previousPoNo')!=null && oppProd.get('previousPoNo')!='') {
			StringCustomFieldRef previousPoNoObj = new StringCustomFieldRef()
			previousPoNoObj.setValue(oppProd.get('previousPoNo'))
			previousPoNoObj.setScriptId('custcol_spk_previousponumber')
			itemCustFieldRefs.add(previousPoNoObj)
		}
					    
		// Support Rate Percent
		if(oppProd.get('supportRatePercent')!=null && oppProd.get('supportRatePercent')!='') {
			DoubleCustomFieldRef supportRatePercentObj = new DoubleCustomFieldRef()
			supportRatePercentObj.setValue(Double.parseDouble(oppProd.get('supportRatePercent')))
			supportRatePercentObj.setScriptId('custcol_spk_supportrate')
			itemCustFieldRefs.add(supportRatePercentObj)
		}		    
	    // ******* END: CPQ-193 Changes ***********
	    
	    // ******* START: CPQ-343 Changes *********
		// Is Start On Delivery
		if(oppProd.get('isStartOnDelivery')!=null && oppProd.get('isStartOnDelivery')!='') {
			BooleanCustomFieldRef isStartOnDeliveryObj = new BooleanCustomFieldRef()
			isStartOnDeliveryObj.setValue(oppProd.get('isStartOnDelivery'))
			isStartOnDeliveryObj.setScriptId('custcol_spk_startondelivery')
			itemCustFieldRefs.add(isStartOnDeliveryObj)
		}
					    
		// Unit List Price
		if(oppProd.get('unitListPrice')!=null && oppProd.get('unitListPrice')!='') {
			DoubleCustomFieldRef unitListPriceObj = new DoubleCustomFieldRef()
			unitListPriceObj.setValue(Double.parseDouble(oppProd.get('unitListPrice')))
			unitListPriceObj.setScriptId('custcol_spk_sfdcunitlistprice')
			itemCustFieldRefs.add(unitListPriceObj)
		}		    
	    // ******* END: CPQ-343 Changes ***********	    
	    
	    // ******* START: ENHC0051470 Changes *********
	    // Bundle
		if(oppProd.get('isBundledBuyingVehicle')!=null && oppProd.get('isBundledBuyingVehicle')!='') {
			BooleanCustomFieldRef isBundledBuyingVehicleObj = new BooleanCustomFieldRef()
			isBundledBuyingVehicleObj.setValue(oppProd.get('isBundledBuyingVehicle'))
			isBundledBuyingVehicleObj.setScriptId('custcol_spk_bundled_buying_vehicle')
			itemCustFieldRefs.add(isBundledBuyingVehicleObj)
		}
		// ******* END: ENHC0051470 Changes ***********
		
		// ******* START: DFCT0050632 Changes *********
		// Total Annual Renewal Amount
		if(oppProd.get('totalAnnualRenewalAmount')!=null && oppProd.get('totalAnnualRenewalAmount')!='') {
			DoubleCustomFieldRef totalAnnualRenewalAmountObj = new DoubleCustomFieldRef()
			totalAnnualRenewalAmountObj.setValue(Double.parseDouble(oppProd.get('totalAnnualRenewalAmount')))
			totalAnnualRenewalAmountObj.setScriptId('custcol_spk_totannual_renewalamt')
			itemCustFieldRefs.add(totalAnnualRenewalAmountObj)
		}		    
	    // ******* END: DFCT0050632 Changes ***********			
	    
	    // ******* START: CPQ-721 Changes *********
		// sellPriceInProposal
		if(oppProd.get('sellPriceInProposal')!=null && oppProd.get('sellPriceInProposal')!='') {
			DoubleCustomFieldRef sellPriceInProposalObj = new DoubleCustomFieldRef()
			sellPriceInProposalObj.setValue(Double.parseDouble(oppProd.get('sellPriceInProposal')))
			sellPriceInProposalObj.setScriptId('custcol_spk_sell_price_in_proposal')
			itemCustFieldRefs.add(sellPriceInProposalObj)
		}
		// ******* END: CPQ-721 Changes *********
		
	    // ******* START: CPQ-715 Changes *********
		// Base Price
		if(oppProd.get('basePrice')!=null && oppProd.get('basePrice')!='') {
			DoubleCustomFieldRef basePriceObj = new DoubleCustomFieldRef()
			basePriceObj.setValue(Double.parseDouble(oppProd.get('basePrice')))
			basePriceObj.setScriptId('custcol_spk_baseprice')
			itemCustFieldRefs.add(basePriceObj)
		}
		// ******* END: CPQ-715 Changes *********
	     
	    // ******* START: CPQ-750 Changes *********
		// Term Start In Proposal
		if(oppProd.get('termStartInProposal')!=null && oppProd.get('termStartInProposal')!='') {
			StringCustomFieldRef termStartInProposalObj = new StringCustomFieldRef()
			termStartInProposalObj.setValue(oppProd.get('termStartInProposal'))
			termStartInProposalObj.setScriptId('custcol_spk_term_start_in_proposal')
			itemCustFieldRefs.add(termStartInProposalObj)
		}
		
		// Term End In Proposal
		if(oppProd.get('termEndInProposal')!=null && oppProd.get('termEndInProposal')!='') {
			StringCustomFieldRef termEndInProposalObj = new StringCustomFieldRef()
			termEndInProposalObj.setValue(oppProd.get('termEndInProposal'))
			termEndInProposalObj.setScriptId('custcol_spk_term_end_in_proposal')
			itemCustFieldRefs.add(termEndInProposalObj)
		}	
		// ******* END: CPQ-750 Changes *********		     	
		
	    // ******* START: CPQ-751 Changes *********
		// Term Months		
		if(oppProd.get('termMonths')!=null && oppProd.get('termMonths')!='') {
			StringCustomFieldRef termMonthsObj = new StringCustomFieldRef()
			termMonthsObj.setValue(oppProd.get('termMonths'))
			termMonthsObj.setScriptId('custcol_spk_licensetermmonths')
			itemCustFieldRefs.add(termMonthsObj)
		}
		// ******* END: CPQ-751 Changes *********		
		
	    // ******* START: CPQ-364 Changes *********
		// Contingent Size	
		if(oppProd.get('contingentSize')!=null && oppProd.get('contingentSize')!='') {
			LongCustomFieldRef contingentSizeObj = new LongCustomFieldRef()
			contingentSizeObj.setValue(oppProd.get('contingentSize'))
			contingentSizeObj.setScriptId('custcol_spk_contingent_size')
			itemCustFieldRefs.add(contingentSizeObj)
		}
		// ******* END: CPQ-364 Changes *********		
	    
	    // Setting custom fields
	     if (!itemCustFieldRefs.isEmpty()) {
			CustomFieldList itemCFields = new CustomFieldList()
			itemCFields.setCustomField(itemCustFieldRefs)
			saleItem.setCustomFieldList(itemCFields)
		}
		
		saleItems.add(saleItem)
//	}	
}
SalesOrderItemList lineItems = new SalesOrderItemList()
lineItems.setItem(saleItems)

if(isUpdate && !isLineIndexPresent) {
	salesOrderMap.put('itemList',null)
} else {
	salesOrderMap.put('itemList',lineItems)
}

//  ********************************************** SO Items: END **********************************************

// Term in Months at header
//println 'Max Term in Months for header: ' + maxTermInMonths
/*if(maxTermInMonths > 0){
	LongCustomFieldRef termInMonthsHdr = new LongCustomFieldRef()
	termInMonthsHdr.setValue(maxTermInMonths)
	termInMonthsHdr.setScriptId('custbody_tran_term_in_months')
	customFieldRefs.add(termInMonthsHdr)
}*/

// SO Term in Months
if(sfdcData.get('orderTermInMonths')!=null && sfdcData.get('orderTermInMonths')!='') {
	LongCustomFieldRef termInMonthsHdr = new LongCustomFieldRef()
	termInMonthsHdr.setValue(Long.parseLong(sfdcData.get('orderTermInMonths')))
	termInMonthsHdr.setScriptId('custbody_tran_term_in_months')
	customFieldRefs.add(termInMonthsHdr)
}

// Payment Card Details
if(sfdcData.get('paymentCardDetails')!=null) {
	def paymentCardDet = sfdcData.get('paymentCardDetails')
	if(paymentCardDet.get('ccNumber4digit')!=null && paymentCardDet.get('ccNumber4digit')!='') {
		StringCustomFieldRef ccNumber4digitRef = new StringCustomFieldRef()
		ccNumber4digitRef.setValue(paymentCardDet.get('ccNumber4digit'))
		ccNumber4digitRef.setScriptId('custbody_spk_cc_last_four_digit')
		customFieldRefs.add(ccNumber4digitRef)
	}
	
	if(paymentCardDet.get('cardHolderName')!=null && paymentCardDet.get('cardHolderName')!='') {
		StringCustomFieldRef cardHolderNameRef = new StringCustomFieldRef()
		cardHolderNameRef.setValue(paymentCardDet.get('cardHolderName'))
		cardHolderNameRef.setScriptId('custbody_spk_cc_name')
		customFieldRefs.add(cardHolderNameRef)
	}
	
	if(paymentCardDet.get('cardBillingAddrStreet')!=null && paymentCardDet.get('cardBillingAddrStreet')!='') {
		StringCustomFieldRef cardBillingAddrStreetRef = new StringCustomFieldRef()
		cardBillingAddrStreetRef.setValue(paymentCardDet.get('cardBillingAddrStreet'))
		cardBillingAddrStreetRef.setScriptId('custbodyspk_cc_address')
		customFieldRefs.add(cardBillingAddrStreetRef)
	}
	
	if(paymentCardDet.get('cardBillingAddrZip')!=null && paymentCardDet.get('cardBillingAddrZip')!='') {
		StringCustomFieldRef cardBillingAddrZipRef = new StringCustomFieldRef()
		cardBillingAddrZipRef.setValue(paymentCardDet.get('cardBillingAddrZip'))
		cardBillingAddrZipRef.setScriptId('custbody_spk_cc_zip_code')
		customFieldRefs.add(cardBillingAddrZipRef)
	}	
	
	if(paymentCardDet.get('cardExpiryDate')!=null && paymentCardDet.get('cardExpiryDate')!='') {
		StringCustomFieldRef cardExpiryDateRef = new StringCustomFieldRef()
		cardExpiryDateRef.setValue(paymentCardDet.get('cardExpiryDate'))
		cardExpiryDateRef.setScriptId('custbody_spk_cc_expire_date')
		customFieldRefs.add(cardExpiryDateRef)
	}
}


//  ***************************** Fields not clear so far and hardcoded *****************************

if(!isUpdate) {
	// SO Form to "1Splunk Sales Order"
	RecordRef customFormObj = new RecordRef()
	customFormObj.setName("1Splunk Sales Order")
	salesOrderMap.put('customForm',customFormObj)
	
	// Order Status - Pending Fulfillment for eCommerce, otherwise Pending Approval
	if(isEcommerceReq){
		salesOrderMap.put('orderStatus',SalesOrderOrderStatus.PENDING_FULFILLMENT)	
	} else {
		salesOrderMap.put('orderStatus',SalesOrderOrderStatus.PENDING_APPROVAL)
	}
	
	// Order Type 
	ListOrRecordRef orderTypeObj = new ListOrRecordRef()
	String sfdcSalesType = sfdcData.get('orderType')
	if(sfdcSalesType!=null && sfdcSalesType!='') {
		//orderTypeObj.setInternalId("15")
		/*if(sfdcSalesType.equals("Web Sales - New")){
			orderTypeObj.setInternalId("18")
		} else if(sfdcSalesType.equals("Web Sales - Expansion")){
			orderTypeObj.setInternalId("19")
		} else if(sfdcSalesType.equals("Web Sales - Upgrade")){
			orderTypeObj.setInternalId("16")
		} else if(sfdcSalesType.equals("Web Sales - Renewal")){
			orderTypeObj.setInternalId("17")
		} else if(sfdcSalesType.equals("Web Sales - Services")){
			orderTypeObj.setInternalId("15")
		} else if(sfdcSalesType.equals("New")){
			orderTypeObj.setInternalId("1")
		} else if(sfdcSalesType.equals("Expansion")){
			orderTypeObj.setInternalId("3")
		} else if(sfdcSalesType.equals("Upgrade")){
			orderTypeObj.setInternalId("4")
		} else if(sfdcSalesType.equals("Renewal")){
			orderTypeObj.setInternalId("2")
		} else if(sfdcSalesType.equals("Services")){
			orderTypeObj.setInternalId("12")
		}*/
		
		orderTypeObj.setInternalId(sfdcSalesType)
		
		/*if(sfdcSalesType.contains("Web Sales")){
			isEcommerceReq = true
		}*/
	} else {
		orderTypeObj.setInternalId("1")
	}
	SelectCustomFieldRef orderTypeSel = new SelectCustomFieldRef()
	orderTypeSel.setValue(orderTypeObj)
	orderTypeSel.setScriptId("custbody_order_type")
	customFieldRefs.add(orderTypeSel)	
}


// Department to "1100 BD : 1110 BD : AppDev"
/*RecordRef departmentObj = new RecordRef()
departmentObj.setInternalId("142") // "1100 BD : 1110 BD : AppDev"
salesOrderMap.put('department',departmentObj)*/

// Payment Method: Harcoded to Stripe Payment
/*RecordRef paymentMethodObj = new RecordRef()
paymentMethodObj.setInternalId("9")
salesOrderMap.put('paymentMethod',paymentMethodObj)*/

// Payment type to "Credit Card"
/*ListOrRecordRef paymentTypeObj = new ListOrRecordRef()
paymentTypeObj.setInternalId("6") // Credit Card
SelectCustomFieldRef paymentTypeSel = new SelectCustomFieldRef()
paymentTypeSel.setValue(paymentTypeObj)
paymentTypeSel.setScriptId("custbodymab_payment_type")
customFieldRefs.add(paymentTypeSel)*/

// Fulfillment Case Synch to "true"
/*BooleanCustomFieldRef fulfillCaseSynchObj = new BooleanCustomFieldRef()
fulfillCaseSynchObj.setValue(true)
fulfillCaseSynchObj.setScriptId("custbody_fulfillment_case_synch")
customFieldRefs.add(fulfillCaseSynchObj)*/

//Addresses
if(sfdcData.get('addressList')!=null &&
	sfdcData.get('addressList').get('address') !=null) {
	
	//Flow countryLookupflow = (Flow)muleContext.getRegistry().lookupFlowConstruct("ns_country_lookup_flow");
	//Flow stateLookupflow = (Flow)muleContext.getRegistry().lookupFlowConstruct("ns_state_lookup_flow");
		
	// Iterate over each address 	
	for (Object addressRec in sfdcData.get('addressList').get('address')) {
		
		// Bill Address
		if(addressRec.get('type')!=null && addressRec.get('type').equalsIgnoreCase('BillTo')){
			BillAddress billAddr = new BillAddress()
			billAddr.setBillAddr1(addressRec.get('address1'))
			billAddr.setBillAddressee(addressRec.get('addressee'))
			billAddr.setBillAttention(addressRec.get('attention'))
			billAddr.setBillCity(addressRec.get('city'))
			billAddr.setBillZip(addressRec.get('zip'))
			
			billAddr.setBillCountry(Country.valueOf(addressRec.get('country')))
			billAddr.setBillState(addressRec.get('state'))
				
			// Country Lookup
			/*def nsBillCntryVal = ''
			if(addressRec.get('country')!=null && addressRec.get('country')!=''){				 
				HashMap reqMap = new HashMap()
				reqMap.put("inputCountryVal",addressRec.get('country'));
				MuleEvent event = new DefaultMuleEvent(new DefaultMuleMessage(reqMap, muleContext),
			            MessageExchangePattern.REQUEST_RESPONSE, countryLookupflow);
			    MuleEvent resultEvent = countryLookupflow.process(event)
			    if(resultEvent!=null && resultEvent.getMessage()!=null && 
			    	 !(resultEvent.getMessage().getPayload() instanceof org.mule.transport.NullPayload) && 
			    	resultEvent.getMessage().getPayload().get('nsCountryVal')!=null) {
			    	//nsBillCntryVal = resultEvent.getMessage().getPayload().get('nsCountryVal')
			    	billAddr.setBillCountry(Country.valueOf(resultEvent.getMessage().getPayload().get('nsCountryVal')))
			    } else { // CPQ-80: To throw data validation error 
			    	sessionVars['dataValidationError'] = true
					throw new BadRequestException('[SFDC Field:Order/BillAddress/BillCountry]: Could not find an internal NS value corresponding to SFDC value:'+addressRec.get('country'));
			    }        
			}*/

			// State Lookup
			/*if(addressRec.get('state')!=null && addressRec.get('state')!=''){
				if(nsBillCntryVal!='' && nsStateDropDownCountries.contains(nsBillCntryVal)) {
					HashMap reqMap = new HashMap()
					reqMap.put("inputStateVal",addressRec.get('state'));
					MuleEvent event = new DefaultMuleEvent(new DefaultMuleMessage(reqMap, muleContext),
				            MessageExchangePattern.REQUEST_RESPONSE, stateLookupflow);
				    MuleEvent resultEvent = stateLookupflow.process(event)
				    if(resultEvent!=null && resultEvent.getMessage()!=null && 
				    	!(resultEvent.getMessage().getPayload() instanceof org.mule.transport.NullPayload) &&
				    	resultEvent.getMessage().getPayload().get('nsStateVal')!=null) {
				    	billAddr.setBillState(resultEvent.getMessage().getPayload().get('nsStateVal'))
				    } else { // CPQ-80: To throw data validation error 
				    	sessionVars['dataValidationError'] = true
						throw new BadRequestException('[SFDC Field:Order/BillAddress/BillState]: Could not find an internal NS value corresponding to SFDC value:'+addressRec.get('state'));
				    }	
				} else {
					billAddr.setBillState(addressRec.get('state'))
				}		 
			}*/
			
			salesOrderMap.put('transactionBillAddress', billAddr)
			//salesOrderMap.put('billAddress', billAddr.getBillAttention() + '\n' + billAddr.getBillAddressee() + '\n' + billAddr.getBillAddr1() + '\n' + billAddr.getBillCity() + ' ' + billAddr.getBillState() + ' ' + billAddr.getBillZip())
		}
		
		// Ship Address
		if(addressRec.get('type')!=null && addressRec.get('type').equalsIgnoreCase('ShipTo')){
			ShipAddress shipAddr = new ShipAddress()
			
			shipAddr.setShipAddr1(addressRec.get('address1'))
			shipAddr.setShipAddressee(addressRec.get('addressee'))
			shipAddr.setShipAttention(addressRec.get('attention'))
			shipAddr.setShipCity(addressRec.get('city'))
			shipAddr.setShipZip(addressRec.get('zip'))
			
			shipAddr.setShipCountry(Country.valueOf(addressRec.get('country')))
			shipAddr.setShipState(addressRec.get('state'))
			
			// Country Lookup
			//def nsShipCntryVal = ''
			/*if(addressRec.get('country')!=null && addressRec.get('country')!=''){				 
				HashMap reqMap = new HashMap()
				reqMap.put("inputCountryVal",addressRec.get('country'));
				MuleEvent event = new DefaultMuleEvent(new DefaultMuleMessage(reqMap, muleContext),
			            MessageExchangePattern.REQUEST_RESPONSE, countryLookupflow);
			    MuleEvent resultEvent = countryLookupflow.process(event)
			    if(resultEvent!=null && resultEvent.getMessage()!=null && 
			    	 !(resultEvent.getMessage().getPayload() instanceof org.mule.transport.NullPayload) &&
			    	resultEvent.getMessage().getPayload().get('nsCountryVal')!=null) {
			    	nsShipCntryVal = resultEvent.getMessage().getPayload().get('nsCountryVal')
			    	shipAddr.setShipCountry(Country.valueOf(nsShipCntryVal))
			    } else { // CPQ-80: To throw data validation error 
			    	sessionVars['dataValidationError'] = true
					throw new BadRequestException('[SFDC Field:Order/ShipAddress/ShipCountry]: Could not find an internal NS value corresponding to SFDC value:'+addressRec.get('country'));
			    }           
			}*/
			
			// State Lookup
			/*if(addressRec.get('state')!=null && addressRec.get('state')!=''){
				if(nsShipCntryVal!='' && nsStateDropDownCountries.contains(nsShipCntryVal)) {				 
					HashMap reqMap = new HashMap()
					reqMap.put("inputStateVal",addressRec.get('state'));
					MuleEvent event = new DefaultMuleEvent(new DefaultMuleMessage(reqMap, muleContext),
				            MessageExchangePattern.REQUEST_RESPONSE, stateLookupflow);
				    MuleEvent resultEvent = stateLookupflow.process(event)
				    if(resultEvent!=null && resultEvent.getMessage()!=null && 
				    	!(resultEvent.getMessage().getPayload() instanceof org.mule.transport.NullPayload) &&
				    	resultEvent.getMessage().getPayload().get('nsStateVal')!=null) {
				    	shipAddr.setShipState(resultEvent.getMessage().getPayload().get('nsStateVal'))
				    } else { // CPQ-80: To throw data validation error 
				    	sessionVars['dataValidationError'] = true
						throw new BadRequestException('[SFDC Field:Order/ShipAddress/ShipState]: Could not find an internal NS value corresponding to SFDC value:'+addressRec.get('state'));
				    }
				} else {
					shipAddr.setShipState(addressRec.get('state'))
				}       
			}*/

			salesOrderMap.put('transactionShipAddress', shipAddr)
			//salesOrderMap.put('shipAddress', shipAddr.getShipAttention() + '\n' + shipAddr.getShipAddressee() + '\n' + shipAddr.getShipAddr1() + '\n' + shipAddr.getShipCity() + ' ' + shipAddr.getShipState() + ' ' + shipAddr.getShipZip())
		}
		
		// Sold To Address
		if(addressRec.get('type')!=null && addressRec.get('type').equalsIgnoreCase('SoldTo')){
			// Attention
			if(addressRec.get('attention')!=null && addressRec.get('attention')!='') {
				StringCustomFieldRef soldAddrAttentionObj = new StringCustomFieldRef()
				soldAddrAttentionObj.setValue(addressRec.get('attention'))
				soldAddrAttentionObj.setScriptId('custbody_spk_soldtoattention')
				customFieldRefs.add(soldAddrAttentionObj)
			}
		
			// Addressee
			if(addressRec.get('addressee')!=null && addressRec.get('addressee')!='') {
				StringCustomFieldRef soldAddrAddresseeObj = new StringCustomFieldRef()
				soldAddrAddresseeObj.setValue(addressRec.get('addressee'))
				soldAddrAddresseeObj.setScriptId('custbody_spk_soldtoaddressee')
				customFieldRefs.add(soldAddrAddresseeObj)
			}
			
			// Address 1
			if(addressRec.get('address1')!=null && addressRec.get('address1')!='') {
				StringCustomFieldRef soldAddrAddress1Obj = new StringCustomFieldRef()
				soldAddrAddress1Obj.setValue(addressRec.get('address1'))
				soldAddrAddress1Obj.setScriptId('custbody_spk_soldtoaddress1')
				customFieldRefs.add(soldAddrAddress1Obj)
			}			
			
			// City
			if(addressRec.get('city')!=null && addressRec.get('city')!='') {
				StringCustomFieldRef soldAddrCityObj = new StringCustomFieldRef()
				soldAddrCityObj.setValue(addressRec.get('city'))
				soldAddrCityObj.setScriptId('custbody_spk_soldtocity')
				customFieldRefs.add(soldAddrCityObj)
			}
			
			// State
			if(addressRec.get('state')!=null && addressRec.get('state')!='') {
				StringCustomFieldRef soldAddrStateObj = new StringCustomFieldRef()
				soldAddrStateObj.setValue(addressRec.get('state'))
				soldAddrStateObj.setScriptId('custbody_spk_soldtostate')
				customFieldRefs.add(soldAddrStateObj)
			}
			
			// Zip
			if(addressRec.get('zip')!=null && addressRec.get('zip')!='') {
				StringCustomFieldRef soldAddrZipObj = new StringCustomFieldRef()
				soldAddrZipObj.setValue(addressRec.get('zip'))
				soldAddrZipObj.setScriptId('custbody_spk_soldtozip')
				customFieldRefs.add(soldAddrZipObj)
			}			
			
			// Country
			if(addressRec.get('country')!=null && addressRec.get('country')!='') {
				StringCustomFieldRef soldAddrCountryObj = new StringCustomFieldRef()
				soldAddrCountryObj.setValue(addressRec.get('country'))
				soldAddrCountryObj.setScriptId('custbody_spk_soldtocountry')
				customFieldRefs.add(soldAddrCountryObj)
			}		
		}		
	}
}

// ********************************** Changes for New attributes of CPQ *****************************************

// Opportunity Type
if(sfdcData.get('opportunityType')!=null && sfdcData.get('opportunityType')!='') {
	ListOrRecordRef oppTypeObj = new ListOrRecordRef()
	String sfdcOpportunityType = sfdcData.get('opportunityType')
	
	/*if(sfdcOpportunityType.equals("Associate")){
		oppTypeObj.setInternalId("1")
	} else if(sfdcOpportunityType.equals("Channel Fulfillment")){
		oppTypeObj.setInternalId("2")
	} else if(sfdcOpportunityType.equals("Channel Led")){
		oppTypeObj.setInternalId("3")
	} else if(sfdcOpportunityType.equals("Channel Own")){
		oppTypeObj.setInternalId("4")
	} else if(sfdcOpportunityType.equals("Channel Referral")){
		oppTypeObj.setInternalId("5")
	} else if(sfdcOpportunityType.equals("Channel Referral Promo")){
		oppTypeObj.setInternalId("15")
	} else if(sfdcOpportunityType.equals("Channel Resale")){
		oppTypeObj.setInternalId("6")
	} else if(sfdcOpportunityType.equals("Customer")){
		oppTypeObj.setInternalId("7")
	} else if(sfdcOpportunityType.equals("Distributor")){
		oppTypeObj.setInternalId("16")
	} else if(sfdcOpportunityType.equals("Internet2")){
		oppTypeObj.setInternalId("12")
	} else if(sfdcOpportunityType.equals("MSP")){
		oppTypeObj.setInternalId("8")
	} else if(sfdcOpportunityType.equals("Non Profit")){
		oppTypeObj.setInternalId("14")
	} else if(sfdcOpportunityType.equals("OEM")){
		oppTypeObj.setInternalId("9")
	} else if(sfdcOpportunityType.equals("On-boarding")){
		oppTypeObj.setInternalId("10")
	} else if(sfdcOpportunityType.equals("Public Sector")){
		oppTypeObj.setInternalId("13")
	} else if(sfdcOpportunityType.equals("Splunk Led")){
		oppTypeObj.setInternalId("11")
	} else if(sfdcOpportunityType.equals("NFR")){
		oppTypeObj.setInternalId("17")
	}*/
	
	oppTypeObj.setInternalId(sfdcOpportunityType)
	
	SelectCustomFieldRef oppTypeSel = new SelectCustomFieldRef()
	oppTypeSel.setValue(oppTypeObj)
	oppTypeSel.setScriptId("custbody_opportunity_type")
	customFieldRefs.add(oppTypeSel)
}

// Ship To Tier
/*ListOrRecordRef shipToTierObj = new ListOrRecordRef()
if(sfdcData.get('shipToTier')=='Channel Resale'){
	shipToTierObj.setInternalId("2") // Reseller
} else if(sfdcData.get('shipToTier')=='Distributor'){
	shipToTierObj.setInternalId("3") // Distributor
} else {
	shipToTierObj.setInternalId("1") // End User
}
SelectCustomFieldRef shipToTierSel = new SelectCustomFieldRef()
shipToTierSel.setValue(shipToTierObj)
shipToTierSel.setScriptId("custbody_ship_to_tier")
customFieldRefs.add(shipToTierSel)*/

// SO Transaction Date
GregorianCalendar gcTranDate = new GregorianCalendar()
if(sfdcData.get('soTranDate')!=null && sfdcData.get('soTranDate')!='') {
	Date tranDateVal = licenseDatesFormat.parse(sfdcData.get('soTranDate'))
	gcTranDate.setTimeInMillis(tranDateVal.getTime())
	XMLGregorianCalendar xgcTranDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcTranDate)
	salesOrderMap.put('tranDate',xgcTranDate)
}

// Terms - Replace with lookup table later, once this field is confirmed to be required
if(sfdcData.get('termsToApply')!=null && sfdcData.get('termsToApply')!='') {
	String sfdcTermsToApply = sfdcData.get('termsToApply')
	RecordRef termsObj = new RecordRef()
	/*if(sfdcTermsToApply.equals("1% 10 Net 30")){
		termsObj.setInternalId("5")
	} else if(sfdcTermsToApply.equals("2% 10 Net 30")){
		termsObj.setInternalId("6")
	} else if(sfdcTermsToApply.equals("Due on receipt")){
		termsObj.setInternalId("4")
	} else if(sfdcTermsToApply.equals("Net 10")){
		termsObj.setInternalId("13")
	} else if(sfdcTermsToApply.equals("Net 15")){
		termsObj.setInternalId("1")
	} else if(sfdcTermsToApply.equals("Net 165")){
		termsObj.setInternalId("15")
	} else if(sfdcTermsToApply.equals("Net 180")){
		termsObj.setInternalId("14")
	} else if(sfdcTermsToApply.equals("Net 20")){
		termsObj.setInternalId("7")
	} else if(sfdcTermsToApply.equals("Net 204")){
		termsObj.setInternalId("16")
	} else if(sfdcTermsToApply.equals("Net 25")){
		termsObj.setInternalId("8")
	} else if(sfdcTermsToApply.equals("Net 30")){
		termsObj.setInternalId("2")
	} else if(sfdcTermsToApply.equals("Net 45")){
		termsObj.setInternalId("9")
	} else if(sfdcTermsToApply.equals("Net 50")){
		termsObj.setInternalId("11")
	} else if(sfdcTermsToApply.equals("Net 568")){
		termsObj.setInternalId("17")
	} else if(sfdcTermsToApply.equals("Net 60")){
		termsObj.setInternalId("3")
	} else if(sfdcTermsToApply.equals("Net 680")){
		termsObj.setInternalId("18")
	} else if(sfdcTermsToApply.equals("Net 75")){
		termsObj.setInternalId("12")
	} else if(sfdcTermsToApply.equals("Net 90")){
		termsObj.setInternalId("10")
	}*/
	
	termsObj.setInternalId(sfdcTermsToApply)
	
	salesOrderMap.put('terms',termsObj)
	println "Terms id is: " + termsObj.getInternalId()
}

// Department
/*RecordRef departmentObj = new RecordRef()
if(sfdcData.get('department')!=null && sfdcData.get('department')!='') {
	//departmentObj.setName(sfdcData.get('department'))
	//departmentObj.setInternalId("142")
} else if (isEcommerceReq) { // For eCommerce
	departmentObj.setInternalId("142") // "1100 BD : 1110 BD : AppDev"
}
salesOrderMap.put('department',departmentObj)*/

// PO Number
if(sfdcData.get('poNumber')!=null && sfdcData.get('poNumber')!='') {
	salesOrderMap.put('otherRefNum',sfdcData.get('poNumber'))
}

// Memo
if(sfdcData.get('memoText')!=null && sfdcData.get('memoText')!='') {
	salesOrderMap.put('memo',sfdcData.get('memoText'))
}

// Payment type to "Credit Card"
ListOrRecordRef paymentTypeObj = new ListOrRecordRef()
if(sfdcData.get('paymentType')!=null && sfdcData.get('paymentType')!='') {
	String sfdcPaymentType = sfdcData.get('paymentType')
	/*if(sfdcPaymentType.equals("Credit Card")){
		paymentTypeObj.setInternalId("6")
	} else if(sfdcPaymentType.equals("COD Invoice")){
		paymentTypeObj.setInternalId("8")
	} else if(sfdcPaymentType.equals("Purchase Order")){
		paymentTypeObj.setInternalId("7")
	} else if(sfdcPaymentType.equals("Other")){
		paymentTypeObj.setInternalId("9")
	}*/
	
	paymentTypeObj.setInternalId(sfdcPaymentType)
	
} else if(isEcommerceReq) { // For eCommerce
	paymentTypeObj.setInternalId("6") // Credit Card
}
if(paymentTypeObj.getInternalId()!=null){
	SelectCustomFieldRef paymentTypeSel = new SelectCustomFieldRef()
	paymentTypeSel.setValue(paymentTypeObj)
	paymentTypeSel.setScriptId("custbodymab_payment_type")
	customFieldRefs.add(paymentTypeSel)
}


// T&C Type
if(sfdcData.get('termsConditionsType')!=null && sfdcData.get('termsConditionsType')!='') {
	ListOrRecordRef tAndCTypeObj = new ListOrRecordRef()
	String tAndCTypeStr = sfdcData.get('termsConditionsType')
	/*if(tAndCTypeStr.equals("Blank T&C")){
		tAndCTypeObj.setInternalId("2")
	} else if(tAndCTypeStr.equals("Extended T&C")){
		tAndCTypeObj.setInternalId("5")
	} else if(tAndCTypeStr.equals("Standard T&C")){
		tAndCTypeObj.setInternalId("1")
	} else if(tAndCTypeStr.equals("Thomson Reuters Quote for 25 GB")){
		tAndCTypeObj.setInternalId("4")
	} else if(tAndCTypeStr.equals("Thomson Reuters Quote for 307 GB")){
		tAndCTypeObj.setInternalId("3")
	}*/
	
	tAndCTypeObj.setInternalId(tAndCTypeStr)
		
	SelectCustomFieldRef tAndCTypeSel = new SelectCustomFieldRef()
	tAndCTypeSel.setValue(tAndCTypeObj)
	tAndCTypeSel.setScriptId("custbody_celigo_tc_type")
	customFieldRefs.add(tAndCTypeSel)
}

// Is Buying Vehicle
if(sfdcData.get('isBuyingVehicle')!=null && sfdcData.get('isBuyingVehicle')!='') {
	BooleanCustomFieldRef isBuyingVehicleObj = new BooleanCustomFieldRef()
	isBuyingVehicleObj.setValue(sfdcData.get('isBuyingVehicle'))
	isBuyingVehicleObj.setScriptId("custbody_is_buying_vehicle")
	customFieldRefs.add(isBuyingVehicleObj)
}

// Use Case
if(sfdcData.get('useCaseText')!=null && sfdcData.get('useCaseText')!='') {
	StringCustomFieldRef useCaseObj = new StringCustomFieldRef()
	useCaseObj.setValue(sfdcData.get('useCaseText'))
	useCaseObj.setScriptId('custbody_use_case')
	customFieldRefs.add(useCaseObj)
}

// SFDC Sync
if(sfdcData.get('sfdcSyncText')!=null && sfdcData.get('sfdcSyncText')!='') {
	StringCustomFieldRef sfdcSyncTextObj = new StringCustomFieldRef()
	sfdcSyncTextObj.setValue(sfdcData.get('sfdcSyncText'))
	sfdcSyncTextObj.setScriptId('custbody_celigo_ns_sfdc_sync')
	customFieldRefs.add(sfdcSyncTextObj)
}

// Sales Notes
if(sfdcData.get('salesNotes')!=null && sfdcData.get('salesNotes')!='') {
	StringCustomFieldRef salesNotesObj = new StringCustomFieldRef()
	salesNotesObj.setValue(sfdcData.get('salesNotes'))
	salesNotesObj.setScriptId('custbody_sales_notes')
	customFieldRefs.add(salesNotesObj)
}

// Case Sync
/*if(sfdcData.get('isCaseSync')!=null && sfdcData.get('isCaseSync')!='') {
	BooleanCustomFieldRef isCaseSyncObj = new BooleanCustomFieldRef()
	isCaseSyncObj.setValue(sfdcData.get('isCaseSync'))
	isCaseSyncObj.setScriptId("custbody_celigo_sfdc_case_sync")
	customFieldRefs.add(isCaseSyncObj)
}*/

// Hide Item Prices
/*if(sfdcData.get('isItemPricesHide')!=null && sfdcData.get('isItemPricesHide')!='') {
	BooleanCustomFieldRef isItemPricesHideObj = new BooleanCustomFieldRef()
	isItemPricesHideObj.setValue(sfdcData.get('isItemPricesHide'))
	isItemPricesHideObj.setScriptId("custbody_celigo_hide_item_prices")
	customFieldRefs.add(isItemPricesHideObj)
}*/

// Celigo Run Item Group
if(sfdcData.get('isCeligoRunItemGroup')!=null && sfdcData.get('isCeligoRunItemGroup')!='') {
	BooleanCustomFieldRef isCeligoRunItemGroupObj = new BooleanCustomFieldRef()
	isCeligoRunItemGroupObj.setValue(sfdcData.get('isCeligoRunItemGroup'))
	isCeligoRunItemGroupObj.setScriptId("custbody_celigo_run_item_group")
	customFieldRefs.add(isCeligoRunItemGroupObj)
}

// NS SFDC Celigo Update
if(sfdcData.get('isNsSfdcCeligoUpd')!=null && sfdcData.get('isNsSfdcCeligoUpd')!='') {
	BooleanCustomFieldRef isNsSfdcCeligoUpdObj = new BooleanCustomFieldRef()
	isNsSfdcCeligoUpdObj.setValue(sfdcData.get('isNsSfdcCeligoUpd'))
	isNsSfdcCeligoUpdObj.setScriptId("custbody_celigo_ns_sfdc_sync_celigo_up")
	customFieldRefs.add(isNsSfdcCeligoUpdObj)
}

// Payment Method: Harcoded to Stripe Payment for eCommerce
if(isEcommerceReq){
	RecordRef paymentMethodObj = new RecordRef()
	paymentMethodObj.setInternalId("9")
	salesOrderMap.put('paymentMethod',paymentMethodObj)
}

// Fulfillment Case Synch to "true" for eCommerce
if(isEcommerceReq){
	BooleanCustomFieldRef fulfillCaseSynchObj = new BooleanCustomFieldRef()
	fulfillCaseSynchObj.setValue(true)
	fulfillCaseSynchObj.setScriptId("custbody_fulfillment_case_synch")
	customFieldRefs.add(fulfillCaseSynchObj)
}

// Shipping Contact
if(sfdcData.get('shipContactId')!=null && sfdcData.get('shipContactId')!='') {
	StringCustomFieldRef shipContactIdObj = new StringCustomFieldRef()
	shipContactIdObj.setValue(sfdcData.get('shipContactId'))
	shipContactIdObj.setScriptId('custbody_celigo_ship_contact')
	customFieldRefs.add(shipContactIdObj)
}


// Support % Override
if(sfdcData.get('supportPercentOverride')!=null && sfdcData.get('supportPercentOverride')!='') {
	DoubleCustomFieldRef supportPercentOverrideVal = new DoubleCustomFieldRef()
	supportPercentOverrideVal.setValue(sfdcData.get('supportPercentOverride'))
	supportPercentOverrideVal.setScriptId('custbody_spk_support_percent_override')
	customFieldRefs.add(supportPercentOverrideVal)
}

// Pricelist Override
if(sfdcData.get('isPriceListOverride')!=null && sfdcData.get('isPriceListOverride')!='') {
	BooleanCustomFieldRef isPriceListOverrideVal = new BooleanCustomFieldRef()
	isPriceListOverrideVal.setValue(sfdcData.get('isPriceListOverride'))
	isPriceListOverrideVal.setScriptId("custbody_ispricelistoverride")
	customFieldRefs.add(isPriceListOverrideVal)
}

// Billing Type
if(sfdcData.get('billingType')!=null && sfdcData.get('billingType')!='') {
	ListOrRecordRef billingTypeVal = new ListOrRecordRef()
	String billingTypeStr = sfdcData.get('billingType')
	
	/*if(billingTypeStr.equals("Standard")){
		billingTypeVal.setInternalId("1")
	} else if(billingTypeStr.equals("Installment")){
		billingTypeVal.setInternalId("2")
	} else if(billingTypeStr.equals("Custom")){
		billingTypeVal.setInternalId("3")
	}*/	
	
	billingTypeVal.setInternalId(billingTypeStr)
	
	SelectCustomFieldRef billingTypeSel = new SelectCustomFieldRef()
	billingTypeSel.setValue(billingTypeVal)
	billingTypeSel.setScriptId("custbody_spk_billingtype")
	customFieldRefs.add(billingTypeSel)
}

// Quote ID
if(sfdcData.get('quoteId')!=null && sfdcData.get('quoteId')!='') {
	StringCustomFieldRef quoteIdVal = new StringCustomFieldRef()
	quoteIdVal.setValue(sfdcData.get('quoteId'))
	quoteIdVal.setScriptId('custbody_spk_fpx_id')
	customFieldRefs.add(quoteIdVal)
}

// ******* START: CPQ-115 Changes *********
// FPX Price List
if(sfdcData.get('fpxPriceList')!=null && sfdcData.get('fpxPriceList')!='') {
	StringCustomFieldRef fpxPriceListObj = new StringCustomFieldRef()
	fpxPriceListObj.setValue(sfdcData.get('fpxPriceList'))
	fpxPriceListObj.setScriptId('custbody_spk_fpxpricelist')
	customFieldRefs.add(fpxPriceListObj)
}	

// FPX Total Extended Sales Price
if(sfdcData.get('fpxTotalExtndSalesPrice')!=null && sfdcData.get('fpxTotalExtndSalesPrice')!='') {
	DoubleCustomFieldRef fpxTotalExtndSalesPriceObj = new DoubleCustomFieldRef()
	fpxTotalExtndSalesPriceObj.setValue(Double.parseDouble(sfdcData.get('fpxTotalExtndSalesPrice')))
	fpxTotalExtndSalesPriceObj.setScriptId('custbody_spk_fpxtotalextsalesprice')
	customFieldRefs.add(fpxTotalExtndSalesPriceObj)
}
// ******* END: CPQ-115 Changes *********

// ******* START: CPQ-193 Changes *********
// Is Tax Exempt
if(sfdcData.get('isTaxExempt')!=null && sfdcData.get('isTaxExempt')!='') {
	BooleanCustomFieldRef isTaxExemptObj = new BooleanCustomFieldRef()
	isTaxExemptObj.setValue(sfdcData.get('isTaxExempt'))
	isTaxExemptObj.setScriptId("custbody_spk_istaxexempt")
	customFieldRefs.add(isTaxExemptObj)
}	

// Is Adhoc Bundle Summary
if(sfdcData.get('isAdhocBundleSummary')!=null && sfdcData.get('isAdhocBundleSummary')!='') {
	BooleanCustomFieldRef isAdhocBundleSummaryObj = new BooleanCustomFieldRef()
	isAdhocBundleSummaryObj.setValue(sfdcData.get('isAdhocBundleSummary'))
	isAdhocBundleSummaryObj.setScriptId("custbody_spk_adhocbundlesummary")
	customFieldRefs.add(isAdhocBundleSummaryObj)
}

// Opportunity Link
if(sfdcData.get('opportunityLink')!=null && sfdcData.get('opportunityLink')!='') {
	StringCustomFieldRef opportunityLinkObj = new StringCustomFieldRef()
	opportunityLinkObj.setValue(sfdcData.get('opportunityLink'))
	opportunityLinkObj.setScriptId('custbody_spk_opportunitylink')
	customFieldRefs.add(opportunityLinkObj)
}
// ******* END: CPQ-193 Changes *********

// ******* START: CPQ-241 Changes *********
// FPX Quote Number
if(sfdcData.get('quoteNumber')!=null && sfdcData.get('quoteNumber')!='') {
	StringCustomFieldRef quoteNumberObj = new StringCustomFieldRef()
	quoteNumberObj.setValue(sfdcData.get('quoteNumber'))
	quoteNumberObj.setScriptId('custbody_spk_fpxquotenumber')
	customFieldRefs.add(quoteNumberObj)
}

// FPX Quote Name
if(sfdcData.get('quoteName')!=null && sfdcData.get('quoteName')!='') {
	StringCustomFieldRef quoteNameObj = new StringCustomFieldRef()
	quoteNameObj.setValue(sfdcData.get('quoteName'))
	quoteNameObj.setScriptId('custbody_spk_fpxquotename')
	customFieldRefs.add(quoteNameObj)
}
// ******* END: CPQ-241 Changes ***********

// ******* START: CPQ-343 Changes *********
// Is CoTerm Assets
if(sfdcData.get('isCoTermAssets')!=null && sfdcData.get('isCoTermAssets')!='') {
	BooleanCustomFieldRef isCoTermAssetsObj = new BooleanCustomFieldRef()
	isCoTermAssetsObj.setValue(sfdcData.get('isCoTermAssets'))
	isCoTermAssetsObj.setScriptId("custbody_spk_cotermassets")
	customFieldRefs.add(isCoTermAssetsObj)
}

// CoTerm Date
if(sfdcData.get('coTermDate')!=null && sfdcData.get('coTermDate')!='') {
	DateCustomFieldRef coTermDateObj = new DateCustomFieldRef()
	coTermDateObj.setScriptId('custbody_spk_cotermdate')
	
	GregorianCalendar coTermGc = new GregorianCalendar()
	Date coTermDateVal = licenseDatesFormat.parse(sfdcData.get('coTermDate'))
	coTermGc.setTimeInMillis(coTermDateVal.getTime())
	XMLGregorianCalendar coTermXGc = DatatypeFactory.newInstance().newXMLGregorianCalendar(coTermGc)
	coTermDateObj.setValue(coTermXGc)
	
	customFieldRefs.add(coTermDateObj)
}			
			
// Buying Vehicle Type
if(sfdcData.get('buyingVehicleType')!=null && sfdcData.get('buyingVehicleType')!='') {
	ListOrRecordRef buyingVehicleTypeObj = new ListOrRecordRef()
	String buyingVehicleTypeStr = sfdcData.get('buyingVehicleType')
	
	/*if(buyingVehicleTypeStr.equals("Bundled")){
		buyingVehicleTypeObj.setInternalId("1")
	} else if(buyingVehicleTypeStr.equals("Perpetual Upfront-Secondary")){
		buyingVehicleTypeObj.setInternalId("2")
	} else if(buyingVehicleTypeStr.equals("Unbundled")){
		buyingVehicleTypeObj.setInternalId("3")
	}*/
	
	buyingVehicleTypeObj.setInternalId(buyingVehicleTypeStr)
	
	SelectCustomFieldRef buyingVehicleTypeSel = new SelectCustomFieldRef()
	buyingVehicleTypeSel.setValue(buyingVehicleTypeObj)
	buyingVehicleTypeSel.setScriptId("custbody_spk_buyingvehicletype")
	customFieldRefs.add(buyingVehicleTypeSel)
}			
// ******* END: CPQ-343 Changes ***********

// ******* START: ENHC0051544 Changes *********
// Proposal Adhoc Bundle
if(sfdcData.get('proposalAdhocBundle')!=null && sfdcData.get('proposalAdhocBundle')!='') {
	ListOrRecordRef proposalAdhocBundleObj = new ListOrRecordRef()
	String proposalAdhocBundleStr = sfdcData.get('proposalAdhocBundle')
	
	/*if(proposalAdhocBundleStr.equals("Summary only")){
		proposalAdhocBundleObj.setInternalId("1")
	} else if(proposalAdhocBundleStr.equals("Detail without Prices")){
		proposalAdhocBundleObj.setInternalId("2")
	} else if(proposalAdhocBundleStr.equals("Detail with Prices")){
		proposalAdhocBundleObj.setInternalId("3")
	}*/
	
	proposalAdhocBundleObj.setInternalId(proposalAdhocBundleStr)
	
	SelectCustomFieldRef proposalAdhocBundleSel = new SelectCustomFieldRef()
	proposalAdhocBundleSel.setValue(proposalAdhocBundleObj)
	proposalAdhocBundleSel.setScriptId("custbody_spk_proposaladhocbundle")
	customFieldRefs.add(proposalAdhocBundleSel)
}			
// ******* END: ENHC0051544 Changes ***********

// ******* START: DFCT0050518 Changes *********
// Bill To Contact Email
if(sfdcData.get('billToContactEmail')!=null && sfdcData.get('billToContactEmail')!='') {
	salesOrderMap.put('email',sfdcData.get('billToContactEmail'))
}
// ******* END: DFCT0050518 Changes *********

// ******* START: CPQ-738 ENHC0051782 Changes *********
// Sold To Email
if(sfdcData.get('soldToEmail')!=null && sfdcData.get('soldToEmail')!='') {
	StringCustomFieldRef soldToEmailObj = new StringCustomFieldRef()
	soldToEmailObj.setValue(sfdcData.get('soldToEmail'))
	soldToEmailObj.setScriptId('custbody_spk_soldtoemail')
	customFieldRefs.add(soldToEmailObj)
}

// Sold To Contact Phone
if(sfdcData.get('soldToContactPhone')!=null && sfdcData.get('soldToContactPhone')!='') {
	StringCustomFieldRef soldToContactPhoneObj = new StringCustomFieldRef()
	soldToContactPhoneObj.setValue(sfdcData.get('soldToContactPhone'))
	soldToContactPhoneObj.setScriptId('custbody_spk_soldtocontactphone')
	customFieldRefs.add(soldToContactPhoneObj)
}

// Sold To Contact DPL Search Date
if(sfdcData.get('soldToContactDPLSearchDate')!=null && sfdcData.get('soldToContactDPLSearchDate')!='') {
	DateCustomFieldRef soldToContactDPLSearchDateObj = new DateCustomFieldRef()
	soldToContactDPLSearchDateObj.setScriptId('custbody_spk_soldtocontactdpl')
	
	GregorianCalendar soldToContactDPLSearchDateGc = new GregorianCalendar()
	Date soldToContactDPLSearchDateVal = licenseDatesFormat.parse(sfdcData.get('soldToContactDPLSearchDate'))
	soldToContactDPLSearchDateGc.setTimeInMillis(soldToContactDPLSearchDateVal.getTime())
	XMLGregorianCalendar soldToContactDPLSearchDateXGc = DatatypeFactory.newInstance().newXMLGregorianCalendar(soldToContactDPLSearchDateGc)
	soldToContactDPLSearchDateObj.setValue(soldToContactDPLSearchDateXGc)
	
	customFieldRefs.add(soldToContactDPLSearchDateObj)
}

// Oppor Record Type
if(sfdcData.get('opporRecordType')!=null && sfdcData.get('opporRecordType')!='') {
	StringCustomFieldRef opporRecordTypeObj = new StringCustomFieldRef()
	opporRecordTypeObj.setValue(sfdcData.get('opporRecordType'))
	opporRecordTypeObj.setScriptId('custbody_spk_opprecordtype')
	customFieldRefs.add(opporRecordTypeObj)
}

// Tier
if(sfdcData.get('tier')!=null && sfdcData.get('tier')!='') {
	StringCustomFieldRef tierObj = new StringCustomFieldRef()
	tierObj.setValue(sfdcData.get('tier'))
	tierObj.setScriptId('custbody_spk_tier')
	customFieldRefs.add(tierObj)
}

// Distributor Name
if(sfdcData.get('distributorName')!=null && sfdcData.get('distributorName')!='') {
	StringCustomFieldRef distributorNameObj = new StringCustomFieldRef()
	distributorNameObj.setValue(sfdcData.get('distributorName'))
	distributorNameObj.setScriptId('custbody_spk_distributorname')
	customFieldRefs.add(distributorNameObj)
}
// ******* END: CPQ-738 ENHC0051782 Changes ***********

// ******* START: CPQ-726 Changes *********
// Proposal Name
if(sfdcData.get('proposalName')!=null && sfdcData.get('proposalName')!='') {
	StringCustomFieldRef proposalNameObj = new StringCustomFieldRef()
	proposalNameObj.setValue(sfdcData.get('proposalName'))
	proposalNameObj.setScriptId('custbody_spk_proposalname')
	customFieldRefs.add(proposalNameObj)
}
// ******* END: CPQ-726 Changes *********

// ******* START: CPQ-895 Changes *********
// Is A1 Upgrade
if(sfdcData.get('isA1Upgrade')!=null && sfdcData.get('isA1Upgrade')!='') {
	BooleanCustomFieldRef isA1UpgradeObj = new BooleanCustomFieldRef()
	isA1UpgradeObj.setValue(sfdcData.get('isA1Upgrade'))
	isA1UpgradeObj.setScriptId("custbody_a1_upgrade")
	customFieldRefs.add(isA1UpgradeObj)
}
// ******* END: CPQ-895 Changes *********

// Setting custom fields
CustomFieldList cFields = new CustomFieldList()
cFields.setCustomField(customFieldRefs)
salesOrderMap.put('customFieldList',cFields)

// Send this map as payload for creation of NS SO
return salesOrderMap
