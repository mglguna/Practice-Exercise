flowVars['sfdcContactId'] = payload.get('cntctId')
flowVars['sfdcContactTimestamp'] = payload.get('cntctTimeStamp')

println "Contact Id from OBM is: " + flowVars['sfdcContactId']
println "Contact Timestamp from OBM is: " + flowVars['sfdcContactTimestamp']

return flowVars['sfdcContactId']