
flowVars['sfdcSubscripId'] = payload.get('subscrPayId')
println "Subscription Payment Id from OBM is: " + flowVars['sfdcSubscripId']
return flowVars['sfdcSubscripId']