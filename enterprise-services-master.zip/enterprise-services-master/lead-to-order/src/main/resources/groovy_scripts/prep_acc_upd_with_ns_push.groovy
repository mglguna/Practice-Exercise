java.util.HashMap sfdcUpdateDataMap = new java.util.HashMap()

println "flowVars['ACCOUNT_ID'] is " + flowVars['ACCOUNT_ID']
 
java.util.HashMap crossRefsMap = new java.util.HashMap()
crossRefsMap.put('crmId',flowVars['ACCOUNT_ID'])

if(exception!=null && exception.getCauseException()!=null){
	sfdcUpdateDataMap.put('netSuiteSyncText', exception.getCauseException().getMessage())
} else {
	println "flowVars['nsAccountId'] is " + flowVars['nsAccountId']
	crossRefsMap.put('netSuiteId', flowVars['nsAccountId'])
}

sfdcUpdateDataMap.put('crossReferences', crossRefsMap)

return sfdcUpdateDataMap