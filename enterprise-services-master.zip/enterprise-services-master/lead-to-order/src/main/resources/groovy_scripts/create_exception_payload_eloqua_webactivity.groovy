import java.util.HashMap

HashMap<String,String> exResponseMap = new HashMap<String,String>()
exResponseMap.put('objectId','')
exResponseMap.put('objectType','Web Activity')
exResponseMap.put('messageId',message.id)
exResponseMap.put('processFlowName','eloqua_web_activity')
exResponseMap.put('subFlowName','eloqua_web_activity')
exResponseMap.put('errorType','CloudHub')

exResponseMap.put('payloadAtException',payload)
exResponseMap.put('severity','High')

exResponseMap.put('transactionSource','AEM')
exResponseMap.put('transactionDestination','Eloqua')

return exResponseMap

