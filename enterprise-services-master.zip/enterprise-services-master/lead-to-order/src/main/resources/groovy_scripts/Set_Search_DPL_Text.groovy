resultList=sessionVars['resultMap']
dplCheck=flowVars['DPLCheck']
maxCount=sessionVars['maxCount']
maxCountInt=maxCount.toInteger()
responseTxt = ''
requestTxt = ''
lastUpdateStr=''
count=0
DPLName = sessionVars['DPLName']
countryCode = sessionVars['countryCode'] 
lastUpdateDatenow=''

for (result in resultList){
	responseTxt = responseTxt + 'IDnum : ' + result.get('iDnum') + '\n'
	responseTxt = responseTxt + 'Source : '+ result.get('source') + '\n'
	responseTxt = responseTxt + 'Name : ' + result.get('name') + '\n'
	responseTxt = responseTxt + 'Street : ' + result.get('street') + '\n'
	responseTxt = responseTxt + 'City : ' + result.get('city') + '\n'
	responseTxt = responseTxt + 'State : ' + result.get('state') + '\n'
	responseTxt = responseTxt + 'Country : ' + result.get('country') + '\n'
	responseTxt = responseTxt + 'StartDate : ' + result.get('startDate') + '\n'
	responseTxt = responseTxt + 'EndDate : ' + result.get('endDate') + '\n'
	responseTxt = responseTxt + 'Notes : ' + result.get('Notes') + '\n'
	responseTxt = responseTxt + 'Code : ' + result.get('code') + '\n'
	responseTxt = responseTxt + 'WeekAlias : ' + result.get('weekAlias') + '\n'
	responseTxt = responseTxt + 'LastUpdate : ' + result.get('lastUpdate') + '\n'
	responseTxt = responseTxt + 'DelistDate : ' + result.get('delistDate') + '\n'
	responseTxt = responseTxt + 'Url : ' + result.get('url') + '\n' + '\n'
	count=count+1
	if(count > maxCountInt){
	break
	}
	
	if (dplCheck == true){
		if (result.get('lastUpdate') > lastUpdateStr){
			lastUpdateStr=result.get('lastUpdate')
			lastUpdateStr+=' 00:00:00'
			lastUpdateDatenow = Date.parse("yyyy/MM/dd HH:mm:ss", lastUpdateStr)
		}
	 }
	

}




requestTxt = requestTxt + 'Name : ' + DPLName + '\n'
requestTxt = requestTxt + 'Country : ' + countryCode
payload.put('Match_Count__c',count)
payload.put('MKData_Query__c',requestTxt)
payload.put('MKData_Response__c',responseTxt)
if (lastUpdateDatenow !=null && lastUpdateDatenow != '' ){
	payload.put('Match_Last_Updated__c',lastUpdateDatenow)
}

return payload