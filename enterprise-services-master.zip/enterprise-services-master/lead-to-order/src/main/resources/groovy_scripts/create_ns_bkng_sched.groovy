
import com.netsuite.webservices.platform.core_2014_1.*
import com.netsuite.webservices.setup.customization_2014_1.CustomRecord

import javax.xml.datatype.XMLGregorianCalendar
import javax.xml.datatype.DatatypeFactory
import java.util.*
import java.text.SimpleDateFormat

sfdcBkngSchedules = flowVars['sfdcBkngSchedules']

//HashMap<String, Object> bookingScheduleMap = new HashMap<String, Object>()
SimpleDateFormat licenseDatesFormat= new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ")

//List<CustomRecord> custRecords = new ArrayList<CustomRecord>()
List<Map<String, Object>> custRecords = new ArrayList<HashMap<String, Object>>()

if(sfdcBkngSchedules!=null){
	for (Object bkngSched in sfdcBkngSchedules) {	
		//CustomRecord custRecord = new CustomRecord()
		Map<String, Object> custRecordMap = new HashMap<String, Object>()
		
		List<CustomFieldRef> customFieldRefs = new ArrayList<CustomFieldRef>()
		
		// Booking Schedule - Amount
		if(bkngSched.get('amount')!=null && bkngSched.get('amount')!='') {
			DoubleCustomFieldRef bookingScheduleAmountVal = new DoubleCustomFieldRef()
			bookingScheduleAmountVal.setValue(bkngSched.get('amount'))
			bookingScheduleAmountVal.setScriptId('custrecord_spk_bs_amount')
			customFieldRefs.add(bookingScheduleAmountVal)
		}
		
/*		// Booking Schedule - Apps Amount
		if(bkngSched.get('appsAmount')!=null && bkngSched.get('appsAmount')!='') {
			DoubleCustomFieldRef bookingScheduleAppsAmountVal = new DoubleCustomFieldRef()
			bookingScheduleAppsAmountVal.setValue(bkngSched.get('appsAmount'))
			bookingScheduleAppsAmountVal.setScriptId('custrecord_spk_appsamount')
			customFieldRefs.add(bookingScheduleAppsAmountVal)
		}
		
		// Booking Schedule - Cloud Amount
		if(bkngSched.get('cloudAmount')!=null && bkngSched.get('cloudAmount')!='') {
			DoubleCustomFieldRef bookingScheduleCloudAmountVal = new DoubleCustomFieldRef()
			bookingScheduleCloudAmountVal.setValue(bkngSched.get('cloudAmount'))
			bookingScheduleCloudAmountVal.setScriptId('custrecord_spk_bs_cloudamount')
			customFieldRefs.add(bookingScheduleCloudAmountVal)
		}
		
		// Booking Schedule - Core Amount
		if(bkngSched.get('coreAmount')!=null && bkngSched.get('coreAmount')!='') {
			DoubleCustomFieldRef bookingScheduleCoreAmountVal = new DoubleCustomFieldRef()
			bookingScheduleCoreAmountVal.setValue(bkngSched.get('coreAmount'))
			bookingScheduleCoreAmountVal.setScriptId('custrecord_spk_bs_coreamount')
			customFieldRefs.add(bookingScheduleCoreAmountVal)
		}
		
		// Booking Schedule - Edu Amount
		if(bkngSched.get('eduAmount')!=null && bkngSched.get('eduAmount')!='') {
			DoubleCustomFieldRef bookingEduAmountVal = new DoubleCustomFieldRef()
			bookingEduAmountVal.setValue(bkngSched.get('eduAmount'))
			bookingEduAmountVal.setScriptId('custrecord_spk_bs_eduamount')
			customFieldRefs.add(bookingEduAmountVal)
		}
		
		// Booking Schedule - Forecast Amount
		if(bkngSched.get('forecastAmount')!=null && bkngSched.get('forecastAmount')!='') {
			DoubleCustomFieldRef bookingScheduleForecastAmountVal = new DoubleCustomFieldRef()
			bookingScheduleForecastAmountVal.setValue(bkngSched.get('forecastAmount'))
			bookingScheduleForecastAmountVal.setScriptId('custrecord_spk_bs_forecastamount')
			customFieldRefs.add(bookingScheduleForecastAmountVal)
		}
		
		// Booking Schedule - Hunk Amount
		if(bkngSched.get('hunkAmount')!=null && bkngSched.get('hunkAmount')!='') {
			DoubleCustomFieldRef bookingScheduleHunkAmountVal = new DoubleCustomFieldRef()
			bookingScheduleHunkAmountVal.setValue(bkngSched.get('hunkAmount'))
			bookingScheduleHunkAmountVal.setScriptId('custrecord_spk_bs_hunkamount')
			customFieldRefs.add(bookingScheduleHunkAmountVal)
		}
		*/
		
		// Booking Schedule - Installment Cycle
		if(bkngSched.get('installmentCycle')!=null && bkngSched.get('installmentCycle')!='') {
			StringCustomFieldRef bookingScheduleInstallmentCycleVal = new StringCustomFieldRef()
			bookingScheduleInstallmentCycleVal.setValue(bkngSched.get('installmentCycle'))
			bookingScheduleInstallmentCycleVal.setScriptId('custrecord_spk_bs_installmentcycle')
			customFieldRefs.add(bookingScheduleInstallmentCycleVal)
		}
		
/*		
		// Booking Schedule - Other Amount
		if(bkngSched.get('otherAmount')!=null && bkngSched.get('otherAmount')!='') {
			DoubleCustomFieldRef bookingScheduleOtherAmountVal = new DoubleCustomFieldRef()
			bookingScheduleOtherAmountVal.setValue(bkngSched.get('otherAmount'))
			bookingScheduleOtherAmountVal.setScriptId('custrecord_spk_bs_otheramount')
			customFieldRefs.add(bookingScheduleOtherAmountVal)
		}
		
		// Booking Schedule - Percent Amount
		if(bkngSched.get('percentAmount')!=null && bkngSched.get('percentAmount')!='') {
			DoubleCustomFieldRef bookingSchedulePercentAmountVal = new DoubleCustomFieldRef()
			bookingSchedulePercentAmountVal.setValue(bkngSched.get('percentAmount'))
			bookingSchedulePercentAmountVal.setScriptId('custrecord_spk_bs_percentamount')
			customFieldRefs.add(bookingSchedulePercentAmountVal)
		}
		
		// Booking Schedule - PS Amount
		if(bkngSched.get('psAmount')!=null && bkngSched.get('psAmount')!='') {
			DoubleCustomFieldRef bookingSchedulePsAmountVal = new DoubleCustomFieldRef()
			bookingSchedulePsAmountVal.setValue(bkngSched.get('psAmount'))
			bookingSchedulePsAmountVal.setScriptId('custrecord_spk_bs_psamount')
			customFieldRefs.add(bookingSchedulePsAmountVal)
		}
		*/
		
		// Booking Schedule - Date
		if(bkngSched.get('bookingScheduledate')!=null && bkngSched.get('bookingScheduledate')!='') {
			DateCustomFieldRef bookingScheduleDate = new DateCustomFieldRef()
			bookingScheduleDate.setScriptId('custrecord_spk_bs_date')
			GregorianCalendar bkngSchedDategc = new GregorianCalendar()
			Date bookingScheduleDateVal = licenseDatesFormat.parse(bkngSched.get('bookingScheduledate'))
			bkngSchedDategc.setTimeInMillis(bookingScheduleDateVal.getTime())
			
			XMLGregorianCalendar bkngSchedDatexgc = DatatypeFactory.newInstance().newXMLGregorianCalendar(bkngSchedDategc)
			bookingScheduleDate.setValue(bkngSchedDatexgc)
			customFieldRefs.add(bookingScheduleDate)
		}
		
		// Booking Schedule - SO Id
		if(payload.getInternalId() !=null && payload.getInternalId()!='') {
			ListOrRecordRef nsSOVal = new ListOrRecordRef()
			nsSOVal.setInternalId(payload.getInternalId())	
			SelectCustomFieldRef nsSOIdVal = new SelectCustomFieldRef()
			nsSOIdVal.setValue(nsSOVal)
			nsSOIdVal.setScriptId("custrecord_spk_bs_sobookingschedule")
			customFieldRefs.add(nsSOIdVal)
		}
		
		// Record Type- Billing Schedule
		/*RecordRef recTypeObj = new RecordRef()
		recTypeObj.setInternalId('256')
		recTypeObj.setName('Booking Schedule')
		custRecord.setRecType(recTypeObj)*/
		
		// Setting custom fields
		CustomFieldList cFields = new CustomFieldList()
		cFields.setCustomField(customFieldRefs)
		//custRecord.setCustomFieldList(cFields)
		custRecordMap.put('customFieldList',cFields)
		
		custRecords.add(custRecordMap)
	}
}



return custRecords
