import java.util.*

List<Map<String,String>> fileAttachmentsMapList = new ArrayList<HashMap<String,String>>()
Map<String,Object> payloadMap = new HashMap<String,Object>()

if(payload!=null && payload.get('objectId')!=null){
	List<String> fileIntIds = Arrays.asList(payload.get('objectId').split(","))
	for(Object fileIntId in fileIntIds){
		if(fileIntId!=null && fileIntId!='') {
			Map<String,String> fileAttachmentsMap = new HashMap<String,String>()
			fileAttachmentsMap.put('sourceObjectType',srcObjVal)
			fileAttachmentsMap.put('sourceInternalId',fileIntId)
			fileAttachmentsMap.put('destObjectType',destObjVal)
			fileAttachmentsMap.put('destInternalId',flowVars['nsSoAttachIntId'])
			
			fileAttachmentsMapList.add(fileAttachmentsMap)
		}
	}
	payloadMap.put('attachmentsList',fileAttachmentsMapList)
}

return payloadMap