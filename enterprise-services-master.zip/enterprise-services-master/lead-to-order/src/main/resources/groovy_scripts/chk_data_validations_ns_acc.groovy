
// This file is created as part of fix for CPQ-80

import org.mule.module.apikit.exception.BadRequestException

if(payload.get('salesRep')==null || payload.get('salesRep').get('internalId')==null || payload.get('salesRep').get('internalId')==''){
	sessionVars['dataValidationError'] = true
	throw new BadRequestException('[SFDC Field: Owner.Email]: Could not find instance in netsuite value lookup: '+flowVars['salesRepEmail']+' {Source:Employee {Key Field:email}}');
}

if(payload.get('addressbookList') !=null && 
	payload.get('addressbookList').get('addressbook') != null) {	
	for (Object addressData in payload.get('addressbookList').get('addressbook')) {
		if(addressData.get('country')==null || addressData.get('country')==''){
			def errorMsg = ''
			if(addressData.get('defaultBilling')){
				errorMsg = '[SFDC Field:BillAddress/BillCountry]: Could not find an internal NS value corresponding to SFDC value:'+flowVars['billAddrCountry']
			} else if(addressData.get('defaultShipping')){
				errorMsg =  '[SFDC Field:ShipAddress/ShipCountry]: Could not find an internal NS value corresponding to SFDC value:'+flowVars['shipAddrCountry']
			} 
			sessionVars['dataValidationError'] = true
			throw new BadRequestException(errorMsg);
		}
		if(nsStateDropDownCountries.contains(addressData.get('country')) && (addressData.get('state')==null || addressData.get('state')=='') ){
			def stateErrorMsg = ''
			if(addressData.get('defaultBilling') && (flowVars['billAddrState']!=null && flowVars['billAddrState']!='')){
				stateErrorMsg = '[SFDC Field:BillAddress/BillState]: Could not find an internal NS value corresponding to SFDC value:'+flowVars['billAddrState']
			} else if(addressData.get('defaultShipping') && (flowVars['shipAddrState']!=null && flowVars['shipAddrState']!='')){
				stateErrorMsg =  '[SFDC Field:ShipAddress/ShipState]: Could not find an internal NS value corresponding to SFDC value:'+flowVars['shipAddrState']
			} 
			
			if(stateErrorMsg!=''){
				sessionVars['dataValidationError'] = true
				throw new BadRequestException(stateErrorMsg);
			}
		}					
	}
}

return payload
