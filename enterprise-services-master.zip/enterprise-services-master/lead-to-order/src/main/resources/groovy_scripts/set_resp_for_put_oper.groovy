
import java.util.HashMap
import org.mule.module.apikit.exception.BadRequestException

HashMap<String,String> putResponseMap = new HashMap<String,String>()

String objectId = ''
def targetSysError = '';
boolean isSuccess = false;

if(targetSystem.equals('NS')) {
	objectId = payload.getInternalId()
	isSuccess = (payload.getInternalId()!=null && payload.getInternalId()!='')
} else if(targetSystem.equals('SFDC')) {
	objectId = payload.getId()
	isSuccess = payload.isSuccess()
	targetSysError = payload.getErrors()
}

if(isSuccess){
	putResponseMap.put('statusCode','STS-200-SUCCESS')
	putResponseMap.put('objectId',objectId)
	putResponseMap.put('objectType',targetObjectType)
	putResponseMap.put('statusMessage','Object created/updated successfully')
} else {
	if(payload.getErrors()!=null){
		throw new BadRequestException(payload.getErrors().toString());
	} else {
		throw new BadRequestException('Operation error');
	}
}

return putResponseMap