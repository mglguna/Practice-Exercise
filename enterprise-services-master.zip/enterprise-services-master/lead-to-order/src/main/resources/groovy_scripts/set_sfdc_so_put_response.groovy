
import java.util.HashMap
import org.mule.module.apikit.exception.BadRequestException

HashMap<String,String> sfdcSoPutResponseMap = new HashMap<String,String>()
if(payload.getSuccess()){
	sfdcSoPutResponseMap.put('statusCode','STS-200-SUCCESS')
	sfdcSoPutResponseMap.put('salesOrderId',payload.getId())
	sfdcSoPutResponseMap.put('statusMessage','Sales Order created/updated successfully')
	flowVars['resStatus'] = '200'
} else {
	flowVars['resStatus'] = '400'
	if(payload.getErrors()!=null){
		throw new BadRequestException(payload.getErrors().toString());
	} else {
		throw new BadRequestException('SFDC operation error');
	}
}

return sfdcSoPutResponseMap