import java.util.*

List<Map<String,String>> attachmentsMapList = new ArrayList<HashMap<String,String>>()
Map<String,Object> payloadMap = new HashMap<String,Object>()

for(Object attachmentData in payload){
	if(attachmentData.get('Id')!=null && attachmentData.get('Id')!='') {
		Map<String,String> attachmentMap = new HashMap<String,String>()
		attachmentMap.put('attachmentId',attachmentData.get('Id'))
		
		attachmentsMapList.add(attachmentMap)
	}
}
payloadMap.put('attachmentsList',attachmentsMapList)
return payloadMap