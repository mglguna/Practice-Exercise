
accounttInputData = flowVars['accounttInputMap']

List<String> fieldsToNullList = new ArrayList<String>()

if (accounttInputData !=null) {
	if(accounttInputData.get('collectionNotes')=='') {
		fieldsToNullList.add('Collection_Notes__c')	
	}
	  
	if(accounttInputData.get('addressList') !=null && 
		accounttInputData.get('addressList').get('address') != null) {
	
		for (Object addressData in accounttInputData.get('addressList').get('address')) {
			if(addressData.get('type')!=null && addressData.get('type').equalsIgnoreCase('billing')){
				payload.put('BillingStreet', addressData.get('street'));
				payload.put('BillingCity', addressData.get('city'));
				payload.put('BillingState', addressData.get('state'));
				payload.put('BillingPostalCode', addressData.get('zip'));
				payload.put('BillingCountry', addressData.get('country'));
				
			} else if(addressData.get('type')!=null && addressData.get('type').equalsIgnoreCase('shipping')){
				payload.put('ShippingStreet', addressData.get('street'));
				payload.put('ShippingCity', addressData.get('city'));
				payload.put('ShippingState', addressData.get('state'));
				payload.put('ShippingPostalCode', addressData.get('zip'));
				payload.put('ShippingCountry', addressData.get('country'));
			}
		}
	}
		
	if(fieldsToNullList.size() > 0){	
		payload.put('fieldsToNull', fieldsToNullList.toArray(new String[fieldsToNullList.size()]))
	}

}

return payload
	