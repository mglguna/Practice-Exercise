flowVars['sfdcAccId'] = payload.get('accId')
flowVars['sfdcAccTimestamp'] = payload.get('accTimeStamp')

println "Account Id from OBM is: " + flowVars['sfdcAccId']
println "Account Timestamp from OBM is: " + flowVars['sfdcAccTimestamp']

return flowVars['sfdcAccId']