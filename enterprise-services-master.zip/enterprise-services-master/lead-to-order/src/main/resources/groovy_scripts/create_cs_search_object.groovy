
import com.netsuite.webservices.platform.common_2014_1.TransactionSearchBasic
import com.netsuite.webservices.platform.core_2014_1.SearchEnumMultiSelectField
import com.netsuite.webservices.platform.core_2014_1.types.SearchEnumMultiSelectFieldOperator
import com.netsuite.webservices.platform.core_2014_1.SearchCustomFieldList
import com.netsuite.webservices.platform.core_2014_1.SearchCustomField
import com.netsuite.webservices.platform.core_2014_1.SearchStringCustomField
import com.netsuite.webservices.platform.core_2014_1.types.SearchStringFieldOperator
import com.netsuite.webservices.platform.common_2014_1.TransactionSearchRowBasic
import com.netsuite.webservices.platform.core_2014_1.SearchColumnSelectField
import com.netsuite.webservices.transactions.sales_2014_1.TransactionSearch
import com.netsuite.webservices.transactions.sales_2014_1.TransactionSearchRow

import java.util.Arrays
import java.util.ArrayList
import java.util.HashMap

TransactionSearch ts = new TransactionSearch();
TransactionSearchBasic transSrchBasic = new TransactionSearchBasic()

HashMap srchFlds = new HashMap()

SearchEnumMultiSelectField transTypeCriteria =  new SearchEnumMultiSelectField()
SearchEnumMultiSelectFieldOperator fieldOperator = 
transTypeCriteria.setOperator(SearchEnumMultiSelectFieldOperator.ANY_OF)
transTypeCriteria.setSearchValue(Arrays.asList("_cashSale"))
transSrchBasic.setType(transTypeCriteria)
/*
SearchEnumMultiSelectField orderStatusCriteria =  new SearchEnumMultiSelectField()
orderStatusCriteria.setOperator(SearchEnumMultiSelectFieldOperator.NONE_OF)
orderStatusCriteria.setSearchValue(Arrays.asList(flowVars['soStatusesToExclude'].split(',')))
transSrchBasic.setStatus(orderStatusCriteria) */

SearchCustomFieldList customFieldsList = new SearchCustomFieldList()
List<SearchCustomField> srchCustomFields = new ArrayList<SearchCustomField>()
SearchCustomField subIdSrchCustomField = new SearchStringCustomField()
subIdSrchCustomField.setScriptId("custbody_spk_sfdc_subscription_id")
subIdSrchCustomField.setOperator(SearchStringFieldOperator.IS)
subIdSrchCustomField.setSearchValue(flowVars['sfdcSubscripId'])
srchCustomFields.add(subIdSrchCustomField)
customFieldsList.setCustomField(srchCustomFields)
transSrchBasic.setCustomFieldList(customFieldsList)

TransactionSearchRow tsr = new TransactionSearchRow();
TransactionSearchRowBasic tsrb = new TransactionSearchRowBasic();

List<SearchColumnSelectField> selcols = new ArrayList<SearchColumnSelectField>(1);
selcols.add(new SearchColumnSelectField());

// Set return columns 
tsrb.setInternalId(selcols);

ts.setBasic(transSrchBasic)
tsr.setBasic(tsrb)

srchFlds.put('criteria', ts)
srchFlds.put('columns', tsr)

return srchFlds
