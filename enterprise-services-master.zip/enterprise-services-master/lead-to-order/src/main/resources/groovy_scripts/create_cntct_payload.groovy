import java.util.Map
import java.util.HashMap
import java.util.List
import java.util.ArrayList

Map<String,Object> cntctsPayload =  new HashMap<String,Object>()
List<Map<String,Object>> oppContactRoles = new ArrayList<HashMap<String,Object>>()

while (payload.hasNext()) {
	Map<String,Object> contactDetail = payload.next()	
	println "Contact id From Opportunity is: " + contactDetail.get('ContactId')
	Map<String,Object> oppContactRole = new HashMap<String,Object>()
	oppContactRole.put('id',contactDetail.get('ContactId'))
	oppContactRoles.add(oppContactRole)
}

cntctsPayload.put('opportunityContactRoles',oppContactRoles)

return cntctsPayload