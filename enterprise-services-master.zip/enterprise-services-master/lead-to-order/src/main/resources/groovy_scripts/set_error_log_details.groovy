
errorLogDetailsMap = sessionVars['errorLogDetMap']

if(errorLogDetailsMap==null){
	errorLogDetailsMap = new HashMap<String,String>()
}

errorLogDetailsMap.put('logType','Error')
errorLogDetailsMap.put('errorMessage',exception.getCauseException().toString())
errorLogDetailsMap.put('errorDescription',exception.getCauseException().getMessage())
errorLogDetailsMap.put('payloadBeforeException',message.getExceptionPayload().getInfo().get('Payload'))

return errorLogDetailsMap
