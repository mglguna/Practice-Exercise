import java.util.List
import java.util.ArrayList

List<String> fieldsToNullList = new ArrayList<String>()

if(payload.get('NS_Sync__c')=='success'){
	fieldsToNullList.add('NS_Sync__c')
	payload.remove('NS_Sync__c')
}

if(fieldsToNullList.size() > 0){	
	payload.put('fieldsToNull', fieldsToNullList.toArray(new String[fieldsToNullList.size()]))
}

return payload