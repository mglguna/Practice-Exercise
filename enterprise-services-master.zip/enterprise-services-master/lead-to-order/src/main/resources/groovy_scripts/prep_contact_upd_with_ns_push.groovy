java.util.HashMap sfdcUpdateDataMap = new java.util.HashMap()

println "flowVars['sfdcContactId'] is " + flowVars['sfdcContactId']
println "flowVars['crmId'] is " + flowVars['crmId']

java.util.HashMap crossRefsMap = new java.util.HashMap()
if(flowVars['crmId']!=null){
	crossRefsMap.put('crmId',flowVars['crmId'])
} else {
	crossRefsMap.put('crmId',flowVars['sfdcContactId'])
}

sfdcUpdateDataMap.put('crossReferences', crossRefsMap)

if(exception!=null && exception.getCauseException()!=null){
	sfdcUpdateDataMap.put('netSuiteSyncText', exception.getCauseException().getMessage())
}

return sfdcUpdateDataMap