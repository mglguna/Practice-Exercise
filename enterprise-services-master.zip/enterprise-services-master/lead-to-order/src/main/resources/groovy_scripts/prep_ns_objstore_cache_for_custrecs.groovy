import java.util.*

if (payload!=null && payload.getTotalRecords() > 0 && payload.getRecordList()!=null) {
	Map<String,String> tandcTypeDataMap = new HashMap<String,String>()	
	for (tandcTypeData in payload.getRecordList().getRecord()) {	
		tandcTypeDataMap.put(tandcTypeData.getName(),tandcTypeData.getInternalId())
	}
	return tandcTypeDataMap
} else {
	return null
}