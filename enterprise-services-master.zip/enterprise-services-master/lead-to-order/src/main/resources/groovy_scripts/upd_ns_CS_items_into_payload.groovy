
import com.netsuite.webservices.transactions.sales_2014_1.CashSaleItemList
import com.netsuite.webservices.transactions.sales_2014_1.CashSaleItem
import java.util.*

origPayload = flowVars['cashSalePayload']
if(payload!=null && payload.itemList!=null && payload.itemList.item!=null){
	CashSaleItemList csItemList = new CashSaleItemList()
	List<CashSaleItem> csItems = new ArrayList<CashSaleItem>()
	
	for (def origcsitem : payload.itemList.item) {
		CashSaleItem csitem = new CashSaleItem()
		csitem.setLine(origcsitem.line)
		csItems.add(csitem)
	}
	
	csItemList.setItem(csItems)
	origPayload.put('itemList', csItemList)
}

return origPayload