import java.util.Map
import java.util.HashMap
import com.netsuite.webservices.platform.core_2014_1.RecordRef

Map<String,Object> recTypeMap = new HashMap<String,Object>()
RecordRef recordRef = new RecordRef();
recordRef.setInternalId(nscustrectctypeid);
recTypeMap.put('recType',recordRef)

return recTypeMap
