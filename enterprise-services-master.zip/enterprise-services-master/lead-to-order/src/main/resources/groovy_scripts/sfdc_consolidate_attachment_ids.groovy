import java.util.*

List<String> attachmentIds = new ArrayList<String>()

for(Object attachmentInfo in payload.get('attachmentsList')){
	if(attachmentInfo.get('attachmentId')!=null && attachmentInfo.get('attachmentId')!='') {
		attachmentIds.add(attachmentInfo.get('attachmentId'))
	}
}

return attachmentIds