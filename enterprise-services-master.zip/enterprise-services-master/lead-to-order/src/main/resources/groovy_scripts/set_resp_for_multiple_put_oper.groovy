import java.util.HashMap
import org.mule.module.apikit.exception.BadRequestException

HashMap<String,String> putResponseMap = new HashMap<String,String>()

boolean isSuccess=true
String objectIds=''
for (Object nsresp in payload){
	if(nsresp.getBaseRef()!=null && nsresp.getBaseRef().getInternalId()!=null && nsresp.getBaseRef().getInternalId()!=''){
		objectIds = objectIds + ',' + nsresp.getBaseRef().getInternalId()		
	} else {
		isSuccess=false
	}
}

if(objectIds!=''){
	putResponseMap.put('statusCode','STS-200-SUCCESS')
	putResponseMap.put('objectId',objectIds.substring(1))
	putResponseMap.put('objectType',targetObjectType)
	putResponseMap.put('statusMessage','Objects created/updated successfully')
}

return putResponseMap