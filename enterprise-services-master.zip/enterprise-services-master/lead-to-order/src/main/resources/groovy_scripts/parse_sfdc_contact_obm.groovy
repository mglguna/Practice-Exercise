import java.util.*

envelope = new XmlSlurper().parseText(payload);

flowVars['sfdcSessId'] = envelope.Body.notifications.SessionId.text()

List<Map<String,String>> contactsInOBMList = new ArrayList<HashMap<String,String>>()
println "Contact Notifications from OBM size is: " + envelope.Body.notifications.Notification.size()

if(envelope.Body.notifications!=null && 
	envelope.Body.notifications.Notification!=null) {
	for (Object notif in envelope.Body.notifications.Notification) {
		Map<String,String> notifDetailsMap = new HashMap<String,String>()
		notifDetailsMap.put('cntctId', notif.sObject.Id.text())
		notifDetailsMap.put('cntctTimeStamp', notif.sObject.LastModifiedDate.text())
		
		contactsInOBMList.add(notifDetailsMap)
	}
}
println "contactsInOBMList is: " + contactsInOBMList
return contactsInOBMList