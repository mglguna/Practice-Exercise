
import com.netsuite.webservices.platform.core_2014_1.CustomFieldList
import com.netsuite.webservices.platform.core_2014_1.CustomFieldRef
import com.netsuite.webservices.platform.core_2014_1.BooleanCustomFieldRef
import com.netsuite.webservices.platform.core_2014_1.StringCustomFieldRef

import java.util.List
import java.util.ArrayList

List<CustomFieldRef> customFieldRefs = new ArrayList<CustomFieldRef>()

payloadMap = flowVars['jsonPayloadMap']

// SFDC Id
if(payloadMap.get('crossReferences')!=null && payloadMap.get('crossReferences').get('crmId')!=null && payloadMap.get('crossReferences').get('crmId')!='') {
	StringCustomFieldRef sfdcIdObj = new StringCustomFieldRef()
	sfdcIdObj.setValue(payloadMap.get('crossReferences').get('crmId'))
	sfdcIdObj.setScriptId('custentity_celigo_ns_sfdc_sync_id')
	customFieldRefs.add(sfdcIdObj)
}

// Is No Longer There
if(payloadMap.get('isNolongerThere')!=null && payloadMap.get('isNolongerThere')!='') {
	BooleanCustomFieldRef isNoLongerThereObj = new BooleanCustomFieldRef()
	isNoLongerThereObj.setValue(payloadMap.get('isNolongerThere'))
	isNoLongerThereObj.setScriptId("custentity_sfdc_isnolongerthere")
	customFieldRefs.add(isNoLongerThereObj)
}

// Comments
if(payloadMap.get('comments')!=null && payloadMap.get('comments')!='') {
	StringCustomFieldRef commentsObj = new StringCustomFieldRef()
	commentsObj.setValue(payloadMap.get('comments'))
	commentsObj.setScriptId('custentity_spk_contactcomments')
	customFieldRefs.add(commentsObj)
} else {
	List<String> nullFieldNameList = new ArrayList<String>()
	nullFieldNameList.add('custentity_spk_contactcomments')
	payload.put('nullFieldList',nullFieldNameList)
}

// Setting custom fields
CustomFieldList cFields = new CustomFieldList()
cFields.setCustomField(customFieldRefs)
payload.put('customFieldList',cFields)

return payload

