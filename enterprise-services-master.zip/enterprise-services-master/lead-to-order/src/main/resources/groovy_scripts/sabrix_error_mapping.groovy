HashMap<String, Object> errorMap = new HashMap<String, Object>()

if(payload.get('taxCalculationResponse')!=null &&
	payload.get('taxCalculationResponse').get('OUTDATA')!=null &&
	payload.get('taxCalculationResponse').get('OUTDATA').get('REQUEST_STATUS')!=null &&
	payload.get('taxCalculationResponse').get('OUTDATA').get('REQUEST_STATUS').get('ERROR')!=null){
	
	errorObject = payload.get('taxCalculationResponse').get('OUTDATA').get('REQUEST_STATUS').get('ERROR')

		def firstError
		if(errorObject instanceof java.util.ArrayList){
			firstError = errorObject.get(0)
		} else {
			firstError = errorObject
		}
		
		if(firstError !=null ) {
			 if(errorCodes.contains(firstError.get('CODE'))){
				 errorMap.put('statusCode', 'STS-400-BADREQUEST');
			 	 errorMap.put('systemErrorMessage', firstError.get('DESCRIPTION'));
			 	 errorMap.put('statusMessage', 'Invalid Request. Please correct and retry');
			} else{
				 errorMap.put('statusCode', 'STS-410-001');
			 	 errorMap.put('systemErrorMessage', firstError.get('DESCRIPTION'));
			 	errorMap.put('statusMessage', 'Internal error occurred. Please retry later');
			}	
	 }		
}

return errorMap	