HashMap<String,String> putResponseMap = new HashMap<String,String>()

putResponseMap.put('statusCode','STS-400-Bad Request')
putResponseMap.put('systemErrorMessage','CRM Id is not valid Lead/Contact. Invalid CRM Id')
putResponseMap.put('statusMessage','Object create/update failed')
message.setProperty('http.status',400)
return putResponseMap