
import com.netsuite.webservices.lists.relationships_2014_1.CustomerSearch
import com.netsuite.webservices.platform.common_2014_1.CustomerSearchBasic
import com.netsuite.webservices.lists.relationships_2014_1.CustomerSearchRow
import com.netsuite.webservices.platform.common_2014_1.CustomerSearchRowBasic

import com.netsuite.webservices.platform.core_2014_1.SearchCustomFieldList
import com.netsuite.webservices.platform.core_2014_1.SearchCustomField
import com.netsuite.webservices.platform.core_2014_1.SearchStringCustomField
import com.netsuite.webservices.platform.core_2014_1.types.SearchStringFieldOperator
import com.netsuite.webservices.platform.core_2014_1.SearchColumnSelectField

import java.util.ArrayList
import java.util.HashMap

HashMap srchFlds = new HashMap()

CustomerSearch custSrch = new CustomerSearch()
CustomerSearchBasic custSrchBasic = new CustomerSearchBasic()

SearchCustomFieldList customFieldsList = new SearchCustomFieldList()
List<SearchCustomField> srchCustomFields = new ArrayList<SearchCustomField>()
SearchCustomField sfdcIdSrchCustomField = new SearchStringCustomField()
sfdcIdSrchCustomField.setScriptId("custentity_celigo_ns_sfdc_sync_id")
sfdcIdSrchCustomField.setOperator(SearchStringFieldOperator.IS)
sfdcIdSrchCustomField.setSearchValue(flowVars['ACCOUNT_ID'])
srchCustomFields.add(sfdcIdSrchCustomField)
customFieldsList.setCustomField(srchCustomFields)
custSrchBasic.setCustomFieldList(customFieldsList)
custSrch.setBasic(custSrchBasic)

CustomerSearchRow custSrchRow = new CustomerSearchRow();
CustomerSearchRowBasic custSrchRowBasic = new CustomerSearchRowBasic();

List<SearchColumnSelectField> selReturnCols = new ArrayList<SearchColumnSelectField>(1);
selReturnCols.add(new SearchColumnSelectField());
// Set return columns 
custSrchRowBasic.setInternalId(selReturnCols);
custSrchRow.setBasic(custSrchRowBasic)

srchFlds.put('criteria', custSrch)
srchFlds.put('columns', custSrchRow)

return srchFlds
