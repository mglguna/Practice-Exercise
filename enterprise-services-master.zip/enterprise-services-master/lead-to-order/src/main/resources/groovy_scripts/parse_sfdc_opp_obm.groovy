import com.sforce.outbound.opportunity.OpportunityNotification;
import com.sforce.outbound.opportunity.Opportunity;
import java.util.LinkedList;

envelope = new XmlSlurper().parseText(payload);

flowVars['sfdcSessId'] = envelope.Body.notifications.SessionId.text()

List<Map<String,String>> oppsInOBMList = new ArrayList<HashMap<String,String>>()
println "Opps Notifications from OBM size is: " + envelope.Body.notifications.Notification.size()

if(envelope.Body.notifications!=null && 
	envelope.Body.notifications.Notification!=null) {
	for (Object notif in envelope.Body.notifications.Notification) {
		Map<String,String> notifDetailsMap = new HashMap<String,String>()
		notifDetailsMap.put('oppId', notif.sObject.Id.text())
		notifDetailsMap.put('oppIsCPQOrder', notif.sObject.isCPQ__c.text())
		
		oppsInOBMList.add(notifDetailsMap)
	}
}
println "oppsInOBMList is: " + oppsInOBMList
return oppsInOBMList