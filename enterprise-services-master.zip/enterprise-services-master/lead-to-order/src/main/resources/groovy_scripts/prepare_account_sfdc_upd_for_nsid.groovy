java.util.HashMap sfdcUpdateDataMap = new java.util.HashMap()

java.util.HashMap crossRefsMap = new java.util.HashMap()
crossRefsMap.put('crmId',flowVars['ACCOUNT_ID'])
crossRefsMap.put('netSuiteId', flowVars['nsAccountId'])

sfdcUpdateDataMap.put('crossReferences', crossRefsMap)

return sfdcUpdateDataMap