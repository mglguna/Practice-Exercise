import java.util.HashMap

HashMap<String,Object> soFieldsToLookup = new HashMap<String,Object>()
flowVars['soPayloadBkp'] = payload

soFieldsToLookup.put('salesRepEmail', payload.get('salesRepEmail'))
soFieldsToLookup.put('addressList', payload.get('addressList'))

soFieldsToLookup.put('orderType', payload.get('orderType'))
soFieldsToLookup.put('opportunityType', payload.get('opportunityType'))
soFieldsToLookup.put('termsToApply', payload.get('termsToApply'))
soFieldsToLookup.put('paymentType', payload.get('paymentType'))
soFieldsToLookup.put('termsConditionsType', payload.get('termsConditionsType'))
soFieldsToLookup.put('billingType', payload.get('billingType'))
soFieldsToLookup.put('buyingVehicleType', payload.get('buyingVehicleType'))
soFieldsToLookup.put('proposalAdhocBundle', payload.get('proposalAdhocBundle'))

return soFieldsToLookup