objectTypeVal=flowVars['objectType']
crmIdVal=flowVars['crmId']

if (objectTypeVal.contains('Contact')){
payload.put('Contact__c',crmIdVal)
}

if (objectTypeVal.contains('Lead')){
payload.put('Lead__c',crmIdVal)
}

return payload