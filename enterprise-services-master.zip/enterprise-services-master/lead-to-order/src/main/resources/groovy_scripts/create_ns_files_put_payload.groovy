import java.util.*
import sun.misc.BASE64Decoder

List<Map<String,String>> fileDataMapList = new ArrayList<HashMap<String,String>>()
Map<String,Object> payloadMap = new HashMap<String,Object>()

for(Object documentData in payload){
	if(documentData.get('Id')!=null && documentData.get('id')!='') {
		Map<String,String> fileDataMap = new HashMap<String,String>()
		fileDataMap.put('fileName',documentData.get('Name'))
		
		BASE64Decoder decoder = new BASE64Decoder();
		dataToWrite = decoder.decodeBuffer(documentData.get('Body'));
		fileDataMap.put('fileContent',dataToWrite)
		fileDataMap.put('folderInternalId',nsfodlerintid)
		
		fileDataMapList.add(fileDataMap)
	}
}

payloadMap.put('filesList',fileDataMapList)
return payloadMap