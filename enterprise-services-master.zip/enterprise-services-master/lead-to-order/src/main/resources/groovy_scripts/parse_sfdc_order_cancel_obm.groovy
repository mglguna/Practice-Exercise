import java.util.*;

envelope = new XmlSlurper().parseText(payload);

List<Map<String,String>> subscrPaymentsInOBMList = new ArrayList<HashMap<String,String>>()
println "Subscription Notifications from OBM size is: " + envelope.Body.notifications.Notification.size()

if(envelope.Body.notifications!=null && 
	envelope.Body.notifications.Notification!=null) {
	for (Object notif in envelope.Body.notifications.Notification) {
		Map<String,String> notifDetailsMap = new HashMap<String,String>()
		notifDetailsMap.put('sfdcSubscripId', notif.sObject.Last_Subscription_Payment__c.text())
		notifDetailsMap.put('cashSaleNetSuiteId', notif.sObject.Last_NS_Cash_Sales_Id__c.text())
		notifDetailsMap.put('orderCancelDate', notif.sObject.Actual_Cancellation_Date__c.text()) 
		subscrPaymentsInOBMList.add(notifDetailsMap)
	}
}
println "subscrPaymentsInOBMList is: " + subscrPaymentsInOBMList
return subscrPaymentsInOBMList