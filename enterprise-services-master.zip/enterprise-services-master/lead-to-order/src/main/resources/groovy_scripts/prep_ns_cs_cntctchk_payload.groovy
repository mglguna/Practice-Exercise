import java.util.HashMap
flowVars['cashSalePayloadBkp']=payload
if(payload.get('orderContactRoles') !=null) {
	HashMap<String, Object> oppContactRoles = new HashMap<String, Object>() 
	oppContactRoles.put('opportunityContactRoles', payload.get('orderContactRoles'))
	return oppContactRoles
}