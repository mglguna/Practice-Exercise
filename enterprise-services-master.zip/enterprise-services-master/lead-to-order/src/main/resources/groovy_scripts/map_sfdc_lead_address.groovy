
leadInputData = flowVars['leadInputMap']
if (leadInputData !=null && 
	leadInputData.get('addressList') !=null && 
	leadInputData.get('addressList').get('address') != null) {
	
	for (Object addressData in leadInputData.get('addressList').get('address')) {
		
			payload.put('Street', addressData.get('address1'));
			payload.put('City', addressData.get('city'));
			payload.put('State', addressData.get('state'));
			payload.put('PostalCode', addressData.get('zip'));
			payload.put('Country', addressData.get('country'));
		
		
	}
}

return payload
	