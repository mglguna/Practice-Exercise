resultList=sessionVars['resultMap']
actualName=sessionVars['DPLName']

boolean matchFound=false

for (result in resultList){
	
		matchFound = true
		
	
	
}

return matchFound
