
import org.mule.module.apikit.exception.BadRequestException

bkpPayload = flowVars['soPayloadBkp']

if(bkpPayload.get('salesRepEmail')!=null && bkpPayload.get('salesRepEmail')!=''){
	if(payload.get('salesRepEmail')!=null && payload.get('salesRepEmail')!=''){
		bkpPayload.put('salesRepEmail', payload.get('salesRepEmail'))
	} else {
		sessionVars['dataValidationError'] = true
		throw new BadRequestException('[SFDC Field: Owner.Email]: Could not find instance in netsuite value lookup: '+bkpPayload.get('salesRepEmail')+' {Source:Employee {Key Field:email}}');
	}
}

for (Object channelAccountRec in payload.get('channelAccounts')) {
	if(channelAccountRec.get('id')!=null && (channelAccountRec.get('netSuiteId')==null || channelAccountRec.get('netSuiteId')=='')) {		
		sessionVars['dataValidationError'] = true
		if(('Reseller').equalsIgnoreCase(channelAccountRec.get('accountType'))){
			throw new BadRequestException('[SFDC Field:Partner Account (Reseller)]: Could not find an Account in NS corresponding to SFDC value:'+channelAccountRec.get('id'));
		} else if(('Distributor').equalsIgnoreCase(channelAccountRec.get('accountType'))){
			throw new BadRequestException('[SFDC Field:Distributor]: Could not find an Account in NS corresponding to SFDC value:'+channelAccountRec.get('id'));
		}
	}
}

int indexVal=0
for (Object addressRec in payload.get('addressList').get('address')) {
	if(!(('SoldTo').equalsIgnoreCase(addressRec.get('type')))){
		Object origAddressRec = bkpPayload.get('addressList').get('address').get(indexVal)
		if(!(addressRec.get('country')!=null && addressRec.get('country')!='')) {		
			sessionVars['dataValidationError'] = true
			if(('BillTo').equalsIgnoreCase(addressRec.get('type'))){
				throw new BadRequestException('[SFDC Field:Order/BillAddress/BillCountry]: Could not find an internal NS value corresponding to SFDC value:'+origAddressRec.get('country'));
			} else if(('ShipTo').equalsIgnoreCase(addressRec.get('type'))){
				throw new BadRequestException('[SFDC Field:Order/ShipAddress/ShipCountry]: Could not find an internal NS value corresponding to SFDC value:'+origAddressRec.get('country'));
			}
		}
		
		if(nsStateDropDownCountries.contains(addressRec.get('country')) && (origAddressRec.get('state')!=null && origAddressRec.get('state')!='') ) {
			if(!(addressRec.get('state')!=null && addressRec.get('state')!='')) {
				sessionVars['dataValidationError'] = true
				if(('BillTo').equalsIgnoreCase(addressRec.get('type'))){
					throw new BadRequestException('[SFDC Field:Order/BillAddress/BillState]: Could not find an internal NS value corresponding to SFDC value:'+origAddressRec.get('state'));
				} else if(('ShipTo').equalsIgnoreCase(addressRec.get('type'))){
					throw new BadRequestException('[SFDC Field:Order/ShipAddress/ShipState]: Could not find an internal NS value corresponding to SFDC value:'+origAddressRec.get('state'));
				}			
			}		
		} else {
			addressRec.put('state', origAddressRec.get('state'))
		}
		indexVal = indexVal+1;
	}
}

bkpPayload.put('addressList', payload.get('addressList'))

bkpPayload.put('billToTierIntId', payload.get('billToTierIntId'))
bkpPayload.put('orderType', payload.get('orderType'))
bkpPayload.put('opportunityType', payload.get('opportunityType'))
bkpPayload.put('termsToApply', payload.get('termsToApply'))
bkpPayload.put('paymentType', payload.get('paymentType'))
bkpPayload.put('termsConditionsType', payload.get('termsConditionsType'))
bkpPayload.put('billingType', payload.get('billingType'))
bkpPayload.put('buyingVehicleType', payload.get('buyingVehicleType'))
bkpPayload.put('proposalAdhocBundle', payload.get('proposalAdhocBundle'))

// ******* START: ENHC0051769 Changes *****************
println "isCPQ Value from OBM in SO flow is: " + flowVars['isCPQOrder']
java.lang.Boolean isEcommReq=false
if(flowVars['isCPQOrder']!=null && flowVars['isCPQOrder'].equals('false')){
    isEcommReq=true
}
bkpPayload.put('isEcommerceReq', isEcommReq)
// ******* END: ENHC0051769 Changes *******************


return bkpPayload
