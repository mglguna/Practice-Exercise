import java.util.*

List<Map<String,Map<String,String>>> custListsDataList = new ArrayList<Map<String,Map<String,String>>>()

if (payload!=null && payload.size() > 0) {	
	for (custListData in payload) {		
		Map<String,Map<String,String>> custFieldMap = new HashMap<String,Map<String,String>>()	
		custListRecord = custListData.getRecord()
		if (custListRecord!=null) {
			Map<String,String> custListValuesMap = new HashMap<String,String>()
			if (custListRecord.getCustomValueList()!=null && 
				custListRecord.getCustomValueList().getCustomValue()!=null) {
				for (custListValue in custListRecord.getCustomValueList().getCustomValue()){
					custListValuesMap.put(custListValue.getValue(), custListValue.getValueId())
				}
			}
			custFieldMap.put('objStoreKey',custListRecord.getScriptId())
			custFieldMap.put('objStoreValue',custListValuesMap)
		}
		custListsDataList.add(custFieldMap)		 
	}
}	

return custListsDataList