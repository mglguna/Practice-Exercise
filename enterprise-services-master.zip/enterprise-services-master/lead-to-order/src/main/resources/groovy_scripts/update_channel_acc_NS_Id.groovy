
if(payload!=null && payload.get('account')!=null){
	actualPayloadData = flowVars['channelAccSfdcPayload']
	indexPos = flowVars['counterIndex'] - 1
	actualPayloadData.get('channelAccounts').get(indexPos).put('netSuiteId',payload.get('account').get('netSuiteId'))
	flowVars['channelAccSfdcPayload'] = actualPayloadData
}
