import java.util.List
import java.util.ArrayList

List<String> fieldsToNullList = new ArrayList<String>()

if(payload.get('NetSuite_Sync__c')=='success'){
	fieldsToNullList.add('NetSuite_Sync__c')
	payload.remove('NetSuite_Sync__c')
}

if(fieldsToNullList.size() > 0){	
	payload.put('fieldsToNull', fieldsToNullList.toArray(new String[fieldsToNullList.size()]))
}

return payload