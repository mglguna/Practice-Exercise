import java.util.*

Map<String,String> custSettingDataMap = new HashMap<String,String>()

if (payload!=null) {	
	for (custSettingData in payload) {
		if(custSettingData.get('sfdc_value__c')!=null) {
			if(flowVars['sfdcCustSetType']=='country') {
				custSettingDataMap.put(custSettingData.get('sfdc_value__c').toUpperCase(), custSettingData.get('MULE_NS_API_VALUE__c'))
			}
			else if (flowVars['sfdcCustSetType']=='state') {
				custSettingDataMap.put(custSettingData.get('sfdc_value__c').toUpperCase(), custSettingData.get('netsuite_value__c'))
			}
			else {
				custSettingDataMap.put(custSettingData.get('sfdc_value__c'), custSettingData.get('netsuite_value__c'))
			}		
		}
	}
}	

return custSettingDataMap