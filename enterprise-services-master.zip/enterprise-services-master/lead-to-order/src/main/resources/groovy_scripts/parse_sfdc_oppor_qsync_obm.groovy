import java.util.*

envelope = new XmlSlurper().parseText(payload);

flowVars['sfdcSessId'] = envelope.Body.notifications.SessionId.text()

List<Map<String,Object>> oppursInOBMList = new ArrayList<HashMap<String,Object>>()
println "Oppors Notifications from OBM size is: " + envelope.Body.notifications.Notification.size()

if(envelope.Body.notifications!=null && 
	envelope.Body.notifications.Notification!=null) {
	for (Object notif in envelope.Body.notifications.Notification) {
		List<String> sfdcAccountsList = new ArrayList<String>()
		Map<String,Object> notifDetailsMap = new HashMap<String,Object>()
		notifDetailsMap.put('oppId', notif.sObject.Id.text())
		notifDetailsMap.put('oppAccId', notif.sObject.AccountId.text())
		notifDetailsMap.put('oppTimestamp', notif.sObject.LastModifiedDate.text())
		
		sfdcAccountsList.add(notif.sObject.AccountId.text())
		def distributorAccountId = notif.sObject.Distributor__c.text()
		if(distributorAccountId!=null && distributorAccountId!=''){
			sfdcAccountsList.add(distributorAccountId)
		}		
		def resellerAccountId = notif.sObject.Partner_Account_Name__c.text()
		if(resellerAccountId!=null && resellerAccountId!=''){
			sfdcAccountsList.add(resellerAccountId)
		}
		notifDetailsMap.put('oppSfdcAccountsList', sfdcAccountsList)
		
		oppursInOBMList.add(notifDetailsMap)
	}
}

println "oppursInOBMList is: " + oppursInOBMList
return oppursInOBMList