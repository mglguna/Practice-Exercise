
java.util.HashMap sfdcUpdateDataMap = new java.util.HashMap()

java.util.HashMap crossRefsMap = new java.util.HashMap()
crossRefsMap.put('crmId',flowVars['crmId'])
crossRefsMap.put('netSuiteId', flowVars['nsContactId'])

sfdcUpdateDataMap.put('crossReferences', crossRefsMap)

return sfdcUpdateDataMap