import org.mule.module.apikit.exception.BadRequestException

def isErrorMsgExists(errorMsgString) {
return (errorMsgString == '')?errorMsgString:errorMsgString + ', ';
}

if(payload.get('Addresses') !=null ) {
	def errorMsg = ''
	for (Object address in payload.get('Addresses')) {
		if( address.get('AddressCode') != '2') {
		println 'inside if'
			if( (address.get('Line1')== null || address.get('Line1')=='') &&
				(address.get('City')== null || address.get('City')=='') &&
				(address.get('Region')== null || address.get('Region')=='') &&
				(address.get('PostalCode')== null || address.get('PostalCode')=='')) {
					errorMsg = no_inputs
				} 
			else if( (address.get('City')== null || address.get('City')=='') &&
				(address.get('Region')== null || address.get('Region')=='') &&
				(address.get('PostalCode')== null || address.get('PostalCode')=='')) {
					errorMsg = input_street
				}	
			else if( (address.get('Line1')== null || address.get('Line1')=='') &&
				(address.get('Region')== null || address.get('Region')=='') &&
				(address.get('PostalCode')== null || address.get('PostalCode')=='')) {
					errorMsg = input_city
				}
			else if( (address.get('Line1')== null || address.get('Line1')=='') &&
				(address.get('City')== null || address.get('City')=='') &&
				(address.get('PostalCode')== null || address.get('PostalCode')=='')) {
					errorMsg = input_state
				}
			else if( (address.get('Line1')== null || address.get('Line1')=='') &&
				(address.get('City')== null || address.get('City')=='') &&
				(address.get('Region')== null || address.get('Region')=='')) {
					errorMsg = input_zip
				}
			else if( (address.get('Line1')== null || address.get('Line1')=='') &&
				(address.get('PostalCode')== null || address.get('PostalCode')=='')) {
					errorMsg = input_city_state
				}
			else if( (address.get('City')== null || address.get('City')=='') &&
				(address.get('PostalCode')== null || address.get('PostalCode')=='')) {
					errorMsg = input_street_state
				}
			else if( (address.get('Line1')== null || address.get('Line1')=='') &&
				(address.get('Region')== null || address.get('Region')=='')) {
					errorMsg = input_city_zip
				}	
			}				
		}
	
	if(errorMsg != '')			
		throw new BadRequestException(errorMsg);
	}
return payload
