
messageMap=[:];
messageMap['statusCode']='STS-404-ERROR'
messageMap['systemErrorMessage']=summary
messageMap['statusMessage']=source

return messageMap;