
// This file is created as part of fix for CPQ-80

import org.mule.module.apikit.exception.BadRequestException

sessionVars['dataValidationError'] = false

if(payload.get('addressbookList') !=null && 
	payload.get('addressbookList').get('addressbook') != null) {	
	for (Object addressData in payload.get('addressbookList').get('addressbook')) {
		if(addressData.get('country')==null || addressData.get('country')==''){
			sessionVars['dataValidationError'] = true
			throw new BadRequestException('[SFDC Field:MailingAddress/Country]: Could not find an internal NS value corresponding to SFDC value:'+flowVars['MailingAddrCountry']);
		}
		
		if(flowVars['MailingAddrState']!=null && flowVars['MailingAddrState']!='') {
			if(nsStateDropDownCountries.contains(addressData.get('country')) && (addressData.get('state')==null || addressData.get('state')=='')){
				sessionVars['dataValidationError'] = true
				throw new BadRequestException('[SFDC Field:MailingAddress/State]: Could not find an internal NS value corresponding to SFDC value:'+flowVars['MailingAddrState']);
			}		
		}
	}
}

return payload
