
contactInputData = flowVars['contactInputMap']
if (contactInputData !=null && 
	contactInputData.get('addressList') !=null && 
	contactInputData.get('addressList').get('address') != null) {
	
	for (Object addressData in contactInputData.get('addressList').get('address')) {
		if(addressData.get('type')!=null && addressData.get('type').equalsIgnoreCase('mailing')){
			payload.put('MailingStreet', addressData.get('street'));
			payload.put('MailingCity', addressData.get('city'));
			payload.put('MailingState', addressData.get('state'));
			payload.put('MailingPostalCode', addressData.get('zip'));
			payload.put('MailingCountry', addressData.get('country'));
			
		} else {
			payload.put('OtherStreet', addressData.get('street'));
			payload.put('OtherCity', addressData.get('city'));
			payload.put('OtherState', addressData.get('state'));
			payload.put('OtherPostalCode', addressData.get('zip'));
			payload.put('OtherCountry', addressData.get('country'));
		}
	}
}

return payload
	