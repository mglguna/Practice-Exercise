
payload.put('isBillAndShipAddressSame',false)

def isBillAddrEmpty = false
def isShipAddrEmpty = false
def isBillAndShipAddrSame = false

if(payload.get('BillingStreet')==null &&
		payload.get('BillingCity')==null &&
		payload.get('BillingState')==null &&
		payload.get('BillingPostalCode')==null &&
		payload.get('BillingCountry')==null){
		isBillAddrEmpty = true
}

if(payload.get('ShippingStreet')==null &&
		payload.get('ShippingCity')==null &&
		payload.get('ShippingState')==null &&
		payload.get('ShippingPostalCode')==null &&
		payload.get('ShippingCountry')==null){
		isShipAddrEmpty = true
}

if( ( (payload.get('BillingStreet')==null && payload.get('ShippingStreet')==null) || (payload.get('BillingStreet')!=null && payload.get('BillingStreet').equalsIgnoreCase(payload.get('ShippingStreet'))) ) &&
	( (payload.get('BillingCity')==null && payload.get('ShippingCity')==null) || (payload.get('BillingCity')!=null && payload.get('BillingCity').equalsIgnoreCase(payload.get('ShippingCity'))) ) &&
	( (payload.get('BillingState')==null && payload.get('ShippingState')==null) || (payload.get('BillingState')!=null && payload.get('BillingState').equalsIgnoreCase(payload.get('ShippingState'))) ) &&
	( (payload.get('BillingPostalCode')==null && payload.get('ShippingPostalCode')==null) || (payload.get('BillingPostalCode')!=null && payload.get('BillingPostalCode').equalsIgnoreCase(payload.get('ShippingPostalCode'))) ) &&
	( (payload.get('BillingCountry')==null && payload.get('ShippingCountry')==null) || (payload.get('BillingCountry')!=null && payload.get('BillingCountry').equalsIgnoreCase(payload.get('ShippingCountry'))) ) ){
		isBillAndShipAddrSame = true
}

if(isBillAddrEmpty || isShipAddrEmpty || isBillAndShipAddrSame){
	payload.put('isBillAndShipAddressSame',true)
}

payload.put('isBillAddrEmpty', isBillAddrEmpty)
payload.put('isShipAddrEmpty', isShipAddrEmpty)

println "isBillAddrEmpty  is: " + isBillAddrEmpty
println "isShipAddrEmpty  is: " + isShipAddrEmpty
println "isBillAndShipAddrSame  is: " + isBillAndShipAddrSame
	
return payload