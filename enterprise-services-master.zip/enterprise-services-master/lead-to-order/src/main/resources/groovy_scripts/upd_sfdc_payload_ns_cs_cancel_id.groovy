

if (payload.get('crossReferences') != null && 
		payload.get('crossReferences').get('netSuiteId') != null && payload.get('crossReferences').get('netSuiteId') != '' ) {
	    flowVars['isNSCSIdExists'] = new Boolean(true)
		flowVars['sfdcReqMap'].put('cashSaleNetSuiteId',payload.get('crossReferences').get('netSuiteId'))    
}	
return flowVars['isNSCSIdExists']
		
		
