
if (payload.get('crossReferences') != null && 
		payload.get('crossReferences').get('netSuiteId') != null) {
	
	flowVars['isNSCSIdExists'] = new Boolean(true)
		
	if(flowVars['sfdcRestRespMap'].get('cashSale') == null) {
		flowVars['sfdcRestRespMap'].put('cashSale', new java.util.HashMap())
	}
	flowVars['sfdcRestRespMap'].get('cashSale').put('netSuiteId', payload.get('crossReferences').get('netSuiteId'))	
}	

return flowVars['sfdcRestRespMap']