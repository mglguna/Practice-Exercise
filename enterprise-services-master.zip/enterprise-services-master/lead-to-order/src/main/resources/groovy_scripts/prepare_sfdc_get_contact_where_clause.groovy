String where_clause=''
boolean isFirst = true
emailVal=flowVars['email']
idVal=flowVars['crmId']

if (emailVal != null && emailVal !=''){
	where_clause += "email = " + "'" + emailVal +"'"
	isFirst = false
}	

if (idVal != null && idVal != ''){
	if (!isFirst){
		where_clause += " AND "		
	} else {
		isFirst = false
	}
	where_clause += "Id = "+"'"+idVal+"'"
}

return where_clause