import java.util.*

Map<String,Object> payloadMap = new HashMap<String,Object>()
payloadMap.put('soInternalId', payload.getInternalId())
if(flowVars['soPayloadBkp']!=null){
	payloadMap.put('attachmentsList', flowVars['soPayloadBkp'].get('attachmentsList'))
}

return payloadMap