
if (payload.get('crossReferences') != null && 
		payload.get('crossReferences').get('netSuiteId') != null) {
	
	flowVars['isNSSOIdExists'] = new Boolean(true)
		
	if(flowVars['sfdcRestRespMap'].get('salesOrder') == null) {
		flowVars['sfdcRestRespMap'].put('salesOrder', new java.util.HashMap())
	}
	flowVars['sfdcRestRespMap'].get('salesOrder').put('netSuiteId', payload.get('crossReferences').get('netSuiteId'))	
}	

return flowVars['sfdcRestRespMap']