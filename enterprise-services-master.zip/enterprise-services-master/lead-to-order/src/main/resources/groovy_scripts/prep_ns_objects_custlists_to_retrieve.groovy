import com.netsuite.webservices.platform.core_2014_1.CustomRecordRef
import com.netsuite.webservices.platform.core_2014_1.RecordRef
import com.netsuite.webservices.platform.core_2014_1.types.RecordType
import com.netsuite.webservices.platform.core_2014_1.CustomizationRef
import java.util.ArrayList

List<CustomizationRef> customListsRef = new ArrayList<CustomizationRef>()

CustomizationRef opportunityTypeRef = new CustomizationRef()
opportunityTypeRef.setScriptId("customlist_opportunity_type")
opportunityTypeRef.setType(RecordType.valueOf('CUSTOM_LIST'))
customListsRef.add(opportunityTypeRef)

CustomizationRef paymentTypeRef = new CustomizationRef()
paymentTypeRef.setScriptId("customlistmab_payment_type_list")
paymentTypeRef.setType(RecordType.valueOf('CUSTOM_LIST'))
customListsRef.add(paymentTypeRef)

CustomizationRef channelSalesTiersRef = new CustomizationRef()
channelSalesTiersRef.setScriptId("customlist_channel_sales_tiers")
channelSalesTiersRef.setType(RecordType.valueOf('CUSTOM_LIST'))
customListsRef.add(channelSalesTiersRef)

CustomizationRef orderTypeRef = new CustomizationRef()
orderTypeRef.setScriptId("customlist_order_type")
orderTypeRef.setType(RecordType.valueOf('CUSTOM_LIST'))
customListsRef.add(orderTypeRef)

CustomizationRef billingTypeRef = new CustomizationRef()
billingTypeRef.setScriptId("customlist_spk_billingtype")
billingTypeRef.setType(RecordType.valueOf('CUSTOM_LIST'))
customListsRef.add(billingTypeRef)

CustomizationRef buyingVehicleTypeRef = new CustomizationRef()
buyingVehicleTypeRef.setScriptId("customlist_spk_buyingvehicletype")
buyingVehicleTypeRef.setType(RecordType.valueOf('CUSTOM_LIST'))
customListsRef.add(buyingVehicleTypeRef)

CustomizationRef proposalAdhocBundleRef = new CustomizationRef()
proposalAdhocBundleRef.setScriptId("customlist_spk_proposaladhocbundle")
proposalAdhocBundleRef.setType(RecordType.valueOf('CUSTOM_LIST'))
customListsRef.add(proposalAdhocBundleRef)

return customListsRef