import java.util.HashMap

HashMap<String,Object> csFieldsToLookup = new HashMap<String,Object>()
flowVars['csPayloadBkp'] = payload

csFieldsToLookup.put('addressList', payload.get('addressList'))
csFieldsToLookup.put('orderType', payload.get('orderType'))
csFieldsToLookup.put('orderBillToType', payload.get('orderBillToType'))

return csFieldsToLookup