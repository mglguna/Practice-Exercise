flowVars['sfdcReqMap']=payload
flowVars['sfdcSubscripId'] = payload.get('sfdcSubscripId')
println "Subscription Payment Id from OBM is: " + flowVars['sfdcSubscripId']
return flowVars['sfdcSubscripId']