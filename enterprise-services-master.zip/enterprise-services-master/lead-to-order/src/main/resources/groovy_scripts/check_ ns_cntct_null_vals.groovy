import java.util.List
import java.util.Map
import java.util.ArrayList
import java.util.HashMap

List<String> nullFieldNameList

if(payload.get('nullFieldList')!=null) {
	nullFieldNameList = payload.get('nullFieldList')
	payload.remove('nullFieldList')
} else {
	nullFieldNameList = new ArrayList<String>()
}

if(payload.get('firstName')==null){
	nullFieldNameList.add('firstname')
}

/*if(payload.get('comments')==null){
	nullFieldNameList.add('comments')
}*/

if(payload.get('fax')==null){
	nullFieldNameList.add('fax')
}

if(payload.get('mobilePhone')==null){
	nullFieldNameList.add('mobilePhone')
}

if(payload.get('phone')==null){
	nullFieldNameList.add('phone')
}

if(payload.get('altEmail')==null){
	nullFieldNameList.add('altemail')
}

if(nullFieldNameList.size()>0){
	Map<String,List<String>> nullFieldListMap = new HashMap<String,List<String>>()
	nullFieldListMap.put('name',nullFieldNameList)
	payload.put('nullFieldList',nullFieldListMap) 
}

return payload