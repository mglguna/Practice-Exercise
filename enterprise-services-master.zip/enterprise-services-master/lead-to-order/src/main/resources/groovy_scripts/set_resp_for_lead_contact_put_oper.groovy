
import java.util.HashMap

HashMap<String,String> putResponseMap = new HashMap<String,String>()

String objectId = ''
String targetSysError = '';
boolean isSuccess = false;
campaignRes=flowVars['campaignResult']
noteRes=flowVars['noteResult']
outputMsg = 'Object created/updated successfully.'
objectId = payload.getId()
isSuccess = payload.getSuccess()

if (payload.getErrors().size() > 0 ){
	targetSysError = payload.getErrors().getAt(0)
}	

if (campaignRes !=null && campaignRes != '' ){
	outputMsg = outputMsg + ' ' + campaignRes;
}
	
if (noteRes !=null && noteRes != '' ){
	outputMsg = outputMsg + ' ' + noteRes;
}


if(isSuccess){
	putResponseMap.put('statusCode','STS-200-SUCCESS')
	putResponseMap.put('objectId',objectId)
	putResponseMap.put('objectType',targetObjectType)
	putResponseMap.put('statusMessage',outputMsg)
	message.setProperty('http.status',200)
} else {
	putResponseMap.put('statusCode','STS-400-BAD_REQUEST')
	if(targetSysError!=null && targetSysError!=''){
		putResponseMap.put('systemErrorMessage',targetSysError)
	}	
	putResponseMap.put('statusMessage','Object create/update failed')
	message.setProperty('http.status',400)
}

return putResponseMap