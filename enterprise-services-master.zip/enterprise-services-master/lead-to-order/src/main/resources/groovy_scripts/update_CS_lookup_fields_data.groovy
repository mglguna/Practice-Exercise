
import org.mule.module.apikit.exception.BadRequestException

bkpPayload = flowVars['csPayloadBkp']

int indexVal=0
for (Object addressRec in payload.get('addressList').get('address')) {
	Object origAddressRec = bkpPayload.get('addressList').get('address').get(indexVal)
	if(!(addressRec.get('country')!=null && addressRec.get('country')!='')) {		
		sessionVars['dataValidationError'] = true
		if(('BillTo').equalsIgnoreCase(addressRec.get('type'))){
			throw new BadRequestException('[SFDC Field:Order/BillAddress/BillCountry]: Could not find an internal NS value corresponding to SFDC value:'+origAddressRec.get('country'));
		} else if(('ShipTo').equalsIgnoreCase(addressRec.get('type'))){
			throw new BadRequestException('[SFDC Field:Order/ShipAddress/ShipCountry]: Could not find an internal NS value corresponding to SFDC value:'+origAddressRec.get('country'));
		}
	}
	
	if(nsStateDropDownCountries.contains(addressRec.get('country')) && (origAddressRec.get('state')!=null && origAddressRec.get('state')!='') ) {
		if(!(addressRec.get('state')!=null && addressRec.get('state')!='')) {
			sessionVars['dataValidationError'] = true
			if(('BillTo').equalsIgnoreCase(addressRec.get('type'))){
				throw new BadRequestException('[SFDC Field:Order/BillAddress/BillState]: Could not find an internal NS value corresponding to SFDC value:'+origAddressRec.get('state'));
			} else if(('ShipTo').equalsIgnoreCase(addressRec.get('type'))){
				throw new BadRequestException('[SFDC Field:Order/ShipAddress/ShipState]: Could not find an internal NS value corresponding to SFDC value:'+origAddressRec.get('state'));
			}		
		}		
	} else {
		addressRec.put('state', origAddressRec.get('state'))
	}
	indexVal = indexVal+1;
}

bkpPayload.put('addressList', payload.get('addressList'))
bkpPayload.put('orderType', payload.get('orderType'))
bkpPayload.put('orderBillToType', payload.get('orderBillToType'))

return bkpPayload
