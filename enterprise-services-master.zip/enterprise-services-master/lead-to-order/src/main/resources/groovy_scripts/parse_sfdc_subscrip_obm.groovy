import java.util.*;

envelope = new XmlSlurper().parseText(payload);

flowVars['sfdcSessId'] = envelope.Body.notifications.SessionId.text()

List<Map<String,String>> subscrPaymentsInOBMList = new ArrayList<HashMap<String,String>>()
println "Subscription Notifications from OBM size is: " + envelope.Body.notifications.Notification.size()

if(envelope.Body.notifications!=null && 
	envelope.Body.notifications.Notification!=null) {
	for (Object notif in envelope.Body.notifications.Notification) {
		Map<String,String> notifDetailsMap = new HashMap<String,String>()
		notifDetailsMap.put('subscrPayId', notif.sObject.Id.text())
		
		subscrPaymentsInOBMList.add(notifDetailsMap)
	}
}
println "subscrPaymentsInOBMList is: " + subscrPaymentsInOBMList
return subscrPaymentsInOBMList