	if(payload.get('Addresses') !=null) {
		for (Object addressData in payload.get('Addresses')) {
			if(addressData.get('AddressCode')!=null && (addressData.get('AddressCode').equals('01') || addressData.get('AddressCode').equals('1')) ){
				if(addressData.get('PostalCode')!=null && addressData.get('PostalCode')!=''){
					postalCode=addressData.get('PostalCode')
					if(postalCode.length()==10){
						addressData.put('PostalCode', postalCode.substring(0, 5));
						addressData.put('GeoCode', postalCode.substring(6, 10));	
					}else{
						addressData.put('PostalCode', postalCode);
					}
				}	
				payload.put('shipFrom', addressData);
			} else if(addressData.get('AddressCode')!=null && ( addressData.get('AddressCode').equals('02') || addressData.get('AddressCode').equals('2')) ){
				if(addressData.get('PostalCode')!=null && addressData.get('PostalCode')!=''){
					postalCode=addressData.get('PostalCode')
					if(postalCode.length()==10){
						addressData.put('PostalCode', postalCode.substring(0, 5));
						addressData.put('GeoCode', postalCode.substring(6, 10));	
					}else{
						addressData.put('PostalCode', postalCode);
					}
				}
				payload.put('shipTo', addressData);	
			}
		}
	}	
	if(payload.get('Lines') !=null) {
		for (Object line in payload.get('Lines')) {
			HashMap<String, Object> BaseBundleFlagMap = new HashMap<String, Object>()
			HashMap<String, Object> BaseBundleCodeMap = new HashMap<String, Object>()
			List  bundleFlagList = new ArrayList()
			List  basebundleCodeList = new ArrayList()
			BaseBundleFlagMap.put('BundleFlag' ,line.get('BundleFlag'))
			BaseBundleCodeMap.put('BaseBundleCode' ,line.get('BaseBundleCode'))
			bundleFlagList.add(BaseBundleFlagMap)
			basebundleCodeList.add(BaseBundleCodeMap)
			line.put('BaseBundleFlagValue', bundleFlagList);
			line.put('BaseBundleCodeValue', basebundleCodeList);
		}
		
	}
	
return payload