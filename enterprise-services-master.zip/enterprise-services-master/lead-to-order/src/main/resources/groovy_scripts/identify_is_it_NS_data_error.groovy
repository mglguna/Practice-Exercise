
if(sessionVars['dataValidationError']==null || (sessionVars['dataValidationError']!=null && !sessionVars['dataValidationError'])){
	if(exception!=null && 
		exception.getCauseException()!=null && 
		exception.getCauseException().getMessage()!=null &&
		exception.getCauseException().getMessage().contains(errorstrfornsdataerror)) {
		sessionVars['dataValidationError'] = true
	}
}
