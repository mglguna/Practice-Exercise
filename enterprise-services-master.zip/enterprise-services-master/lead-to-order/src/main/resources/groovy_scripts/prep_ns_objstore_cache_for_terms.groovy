import java.util.*

if (payload!=null && payload.size()>0) {
	Map<String,String> termsDataMap = new HashMap<String,String>()	
	for (termsData in payload) {	
		termsDataMap.put(termsData.get('name'),termsData.get('internalId'))
	}
	return termsDataMap
} else {
	return null
}