flowVars['sfdcOppId'] = payload.get('oppId')
flowVars['sfdcAccId'] = payload.get('oppAccId')
flowVars['sfdcOppTimestamp'] = payload.get('oppTimestamp')
flowVars['sfdcAccountIdsList'] = payload.get('oppSfdcAccountsList')

println "Opp Id from Opp Qsync OBM is: " + flowVars['sfdcOppId']
println "Account Id from Opp Qsync OBM is: " + flowVars['sfdcAccId']
println "Accounts List from Opp Qsync OBM is: " + flowVars['sfdcAccountIdsList']
println "Opp QSync Timestamp from OBM is: " + flowVars['sfdcOppTimestamp']

return flowVars['sfdcOppId']