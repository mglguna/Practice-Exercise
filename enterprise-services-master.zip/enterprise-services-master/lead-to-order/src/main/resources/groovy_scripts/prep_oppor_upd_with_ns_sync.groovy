java.util.HashMap sfdcUpdateDataMap = new java.util.HashMap()

java.util.HashMap crossRefsMap = new java.util.HashMap()
crossRefsMap.put('crmId',flowVars['sfdcOppId'])

sfdcUpdateDataMap.put('crossReferences', crossRefsMap)

if(exception!=null && exception.getCauseException()!=null){
	sfdcUpdateDataMap.put('netSuiteSyncText', flowVars['opporErrorMsg'])
}

if(isSOOBMProcess!=null && isSOOBMProcess=='true'){
	sfdcUpdateDataMap.put('sendToNetSuiteFlag', false)
}

return sfdcUpdateDataMap