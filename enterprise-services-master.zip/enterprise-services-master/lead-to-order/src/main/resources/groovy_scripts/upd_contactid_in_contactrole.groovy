
contactroledata = payload
contactRoles = flowVars['contactRoles']
currentIndex = flowVars['index']-1
contactRoles[currentIndex].put('netSuiteId',flowVars['nsContactId'])
flowVars['contactRoles'] = contactRoles
return contactroledata