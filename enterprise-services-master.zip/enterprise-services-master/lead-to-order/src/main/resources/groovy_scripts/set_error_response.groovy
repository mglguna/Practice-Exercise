
import java.util.HashMap

HashMap<String,String> errorResponseMap = new HashMap<String,String>()

errorResponseMap.put('statusCode',statusCodeVal)
if(exception.getCauseException().getMessage().contains('Shipping')) {
errorResponseMap.put('systemErrorMessage',exception.getCauseException().getMessage())
}
else {
errorResponseMap.put('systemErrorMessage',exception.getCauseException().toString())
}
errorResponseMap.put('statusMessage',statusMsgVal)
return errorResponseMap