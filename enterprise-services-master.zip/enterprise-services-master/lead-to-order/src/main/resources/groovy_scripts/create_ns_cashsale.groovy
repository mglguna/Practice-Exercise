import com.netsuite.webservices.platform.core_2014_1.*
import com.netsuite.webservices.transactions.sales_2014_1.*
import com.netsuite.webservices.transactions.sales_2014_1.types.*
import com.netsuite.webservices.platform.common_2014_1.BillAddress
import com.netsuite.webservices.platform.common_2014_1.ShipAddress
import 	com.netsuite.webservices.platform.common_2014_1.types.Country

import javax.xml.datatype.XMLGregorianCalendar
import javax.xml.datatype.DatatypeFactory
import java.util.*
import java.text.SimpleDateFormat

import org.mule.construct.Flow
import org.mule.DefaultMuleEvent
import org.mule.DefaultMuleMessage
import org.mule.api.MuleEvent
import org.mule.api.MuleMessage
import org.mule.MessageExchangePattern


sfdcData = payload
HashMap<String, Object> cashSaleMap = new HashMap<String, Object>()
List<CustomFieldRef> customFieldRefs = new ArrayList<CustomFieldRef>()
SimpleDateFormat licenseDatesFormat= new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ")
SimpleDateFormat cancelDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS")
cancelDateFormat.setTimeZone(TimeZone.getTimeZone("PST"))

// CustomForm
if(sfdcData.get('cashSaleNetSuiteId')==null || sfdcData.get('cashSaleNetSuiteId')=='') {
	RecordRef customFormObj = new RecordRef()
	customFormObj.setInternalId("106") // Cash Sale [SWE] (Save As)
	cashSaleMap.put('customForm',customFormObj)
}

// Order Type 
if(sfdcData.get('orderType')!=null && sfdcData.get('orderType')!='') {
	ListOrRecordRef orderTypeObj = new ListOrRecordRef()
	orderTypeObj.setInternalId(sfdcData.get('orderType'))
	SelectCustomFieldRef orderTypeSel = new SelectCustomFieldRef()
	orderTypeSel.setValue(orderTypeObj)
	orderTypeSel.setScriptId("custbody_order_type")
	customFieldRefs.add(orderTypeSel)
}

// Bill To Tier
if(sfdcData.get('orderBillToType')!=null && sfdcData.get('orderBillToType')!='') {
	ListOrRecordRef ordTypeBillToTierObj = new ListOrRecordRef()
	ordTypeBillToTierObj.setInternalId(sfdcData.get('orderBillToType'))
	SelectCustomFieldRef ordTypeBillToTierSel = new SelectCustomFieldRef()
	ordTypeBillToTierSel.setValue(ordTypeBillToTierObj)
	ordTypeBillToTierSel.setScriptId("custbody_bill_to_tier")
	customFieldRefs.add(ordTypeBillToTierSel)
}
	
// Entity/Account	
if(sfdcData.get('account')!=null && sfdcData.get('account').get('netSuiteId')!=null 
	&& sfdcData.get('account').get('netSuiteId')!='') {
	RecordRef entityRef= new RecordRef()
	entityRef.setInternalId(sfdcData.get('account').get('netSuiteId'))
	cashSaleMap.put('entity',entityRef)
}
	
// salesDistrict
if(sfdcData.get('salesDistrict')!=null && sfdcData.get('salesDistrict')!='') {
	StringCustomFieldRef custsalesdistrict = new StringCustomFieldRef()
	custsalesdistrict.setValue(sfdcData.get('salesDistrict'))
	custsalesdistrict.setScriptId('custbody_sales_district')
	customFieldRefs.add(custsalesdistrict)
}
	
// salesTheatre	
if(sfdcData.get('salesTheatre')!=null && sfdcData.get('salesTheatre')!='') {
	StringCustomFieldRef custsalestheater = new StringCustomFieldRef()
	custsalestheater.setValue(sfdcData.get('salesTheatre'))
	custsalestheater.setScriptId('custbody_sales_theater')
	customFieldRefs.add(custsalestheater)
}


// Start Date - 
GregorianCalendar gc1 = new GregorianCalendar()
if(sfdcData.get('subscriptionStartDate')!=null && sfdcData.get('subscriptionStartDate')!='') {
	Date subStartDate = licenseDatesFormat.parse(sfdcData.get('subscriptionStartDate'))
	gc1.setTimeInMillis(subStartDate.getTime())
	XMLGregorianCalendar xgc1 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc1)
	cashSaleMap.put('startDate',xgc1)
}

// End Date 
if(sfdcData.get('subscriptionEndDate')!=null && sfdcData.get('subscriptionEndDate')!='') {
	GregorianCalendar gc5 = new GregorianCalendar()
	Date subEndDate = licenseDatesFormat.parse(sfdcData.get('subscriptionEndDate'))
	gc5.setTimeInMillis(subEndDate.getTime())
	XMLGregorianCalendar xgc5 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc5)
	cashSaleMap.put('endDate',xgc5)
}
	
	
// End User
if(sfdcData.get('account')!=null && sfdcData.get('account').get('netSuiteId')!=null){
	ListOrRecordRef endUserCustObj = new ListOrRecordRef()
	endUserCustObj.setInternalId(sfdcData.get('account').get('netSuiteId'))
	SelectCustomFieldRef endUserCustSel = new SelectCustomFieldRef()
	endUserCustSel.setValue(endUserCustObj)
	endUserCustSel.setScriptId("custbody_end_user")
	customFieldRefs.add(endUserCustSel)
}


// Payment Type 
if(sfdcData.get('cashSaleNetSuiteId')==null || sfdcData.get('cashSaleNetSuiteId')=='') {
	ListOrRecordRef paymentTypeObj = new ListOrRecordRef()
	paymentTypeObj.setInternalId("6") // Credit Card
	SelectCustomFieldRef paymentTypeSel = new SelectCustomFieldRef()
	paymentTypeSel.setValue(paymentTypeObj)
	paymentTypeSel.setScriptId("custbodymab_payment_type")
	customFieldRefs.add(paymentTypeSel)
}

// Fulfillment Case Synch to "true" 
if(sfdcData.get('cashSaleNetSuiteId')==null || sfdcData.get('cashSaleNetSuiteId')=='') {
	BooleanCustomFieldRef fulfillCaseSynchObj = new BooleanCustomFieldRef()
	fulfillCaseSynchObj.setValue(true)
	fulfillCaseSynchObj.setScriptId("custbody_fulfillment_case_synch")
	customFieldRefs.add(fulfillCaseSynchObj)
}
	
//Addresses
if(sfdcData.get('addressList')!=null &&
	sfdcData.get('addressList').get('address') !=null) {
	// Iterate over each address 	
	for (Object addressRec in sfdcData.get('addressList').get('address')) {
		// Bill Address
		if(addressRec.get('type')!=null && addressRec.get('type').equalsIgnoreCase('BillTo')){
			BillAddress billAddr = new BillAddress()
			billAddr.setBillAttention(addressRec.get('attention'))
			billAddr.setBillAddressee(addressRec.get('addressee'))
			billAddr.setBillAddr1(addressRec.get('address1'))
			billAddr.setBillAddr2(addressRec.get('address2'))
			billAddr.setBillCity(addressRec.get('city'))
			billAddr.setBillState(addressRec.get('state'))
			billAddr.setBillZip(addressRec.get('zip'))
			billAddr.setBillCountry(Country.valueOf(addressRec.get('country')))
			cashSaleMap.put('transactionBillAddress', billAddr)
		}
		
		// Ship Address
		if(addressRec.get('type')!=null && addressRec.get('type').equalsIgnoreCase('ShipTo')){
			ShipAddress shipAddr = new ShipAddress()
			shipAddr.setShipAttention(addressRec.get('attention'))
			shipAddr.setShipAddressee(addressRec.get('addressee'))
			shipAddr.setShipAddr1(addressRec.get('address1'))
			shipAddr.setShipAddr2(addressRec.get('address2'))
			shipAddr.setShipCity(addressRec.get('city'))
			shipAddr.setShipState(addressRec.get('state'))
			shipAddr.setShipZip(addressRec.get('zip'))
			shipAddr.setShipCountry(Country.valueOf(addressRec.get('country')))
			cashSaleMap.put('transactionShipAddress', shipAddr)
		}		
	}
}		

// OrderID	
if(sfdcData.get('orderId')!=null && sfdcData.get('orderId')!='') {
	StringCustomFieldRef celigoSyncId = new StringCustomFieldRef()
	celigoSyncId.setValue(sfdcData.get('orderId'))
	celigoSyncId.setScriptId('custbody_celigo_ns_sfdc_sync_id')
	customFieldRefs.add(celigoSyncId)
}
	
// OrderNumber	
if(sfdcData.get('orderNumber')!=null && sfdcData.get('orderNumber')!='') {	
	StringCustomFieldRef spkOrderNumber = new StringCustomFieldRef()
	spkOrderNumber.setValue(sfdcData.get('orderNumber'))
	spkOrderNumber.setScriptId('custbody_spk_sfdc_order_no')
	customFieldRefs.add(spkOrderNumber)
}
	
//SubscriptionId
if(sfdcData.get('sfdcSubscriptionId')!=null && sfdcData.get('sfdcSubscriptionId')!='') {	
	StringCustomFieldRef spkSubscriptionId = new StringCustomFieldRef()
	spkSubscriptionId.setValue(sfdcData.get('sfdcSubscriptionId'))
	spkSubscriptionId.setScriptId('custbody_spk_sfdc_subscription_id')
	customFieldRefs.add(spkSubscriptionId)
}
	
// Sales Notes
if(sfdcData.get('salesNotes')!=null && sfdcData.get('salesNotes')!='') {
	StringCustomFieldRef salesNotesObj = new StringCustomFieldRef()
	salesNotesObj.setValue(sfdcData.get('salesNotes'))
	salesNotesObj.setScriptId('custbody_sales_notes')
	customFieldRefs.add(salesNotesObj)
}	

// Payment Method: Harcoded to Stripe Payment
if(sfdcData.get('cashSaleNetSuiteId')==null || sfdcData.get('cashSaleNetSuiteId')=='') {
	RecordRef paymentMethodObj = new RecordRef()
	paymentMethodObj.setInternalId("9")
	cashSaleMap.put('paymentMethod',paymentMethodObj)
}

// Payment Card Details
if(sfdcData.get('paymentCardDetails')!=null) {
	def paymentCardDet = sfdcData.get('paymentCardDetails')
	if(paymentCardDet.get('ccNumber4digit')!=null && paymentCardDet.get('ccNumber4digit')!='') {
		StringCustomFieldRef ccNumber4digitRef = new StringCustomFieldRef()
		ccNumber4digitRef.setValue(paymentCardDet.get('ccNumber4digit'))
		ccNumber4digitRef.setScriptId('custbody_spk_cc_last_four_digit')
		customFieldRefs.add(ccNumber4digitRef)
	}
	if(paymentCardDet.get('cardHolderName')!=null && paymentCardDet.get('cardHolderName')!='') {
		StringCustomFieldRef cardHolderNameRef = new StringCustomFieldRef()
		cardHolderNameRef.setValue(paymentCardDet.get('cardHolderName'))
		cardHolderNameRef.setScriptId('custbody_spk_cc_name')
		customFieldRefs.add(cardHolderNameRef)
	}
	if(paymentCardDet.get('cardExpiryDate')!=null && paymentCardDet.get('cardExpiryDate')!='') {
		StringCustomFieldRef cardExpiryDateRef = new StringCustomFieldRef()
		cardExpiryDateRef.setValue(paymentCardDet.get('cardExpiryDate'))
		cardExpiryDateRef.setScriptId('custbody_spk_cc_expire_date')
		customFieldRefs.add(cardExpiryDateRef)
	}
	if(paymentCardDet.get('cardBillingAddrStreet')!=null && paymentCardDet.get('cardBillingAddrStreet')!='') {
		StringCustomFieldRef cardBillingAddrStreetRef = new StringCustomFieldRef()
		cardBillingAddrStreetRef.setValue(paymentCardDet.get('cardBillingAddrStreet'))
		cardBillingAddrStreetRef.setScriptId('custbodyspk_cc_address')
		customFieldRefs.add(cardBillingAddrStreetRef)
	}
	if(paymentCardDet.get('cardBillingAddrZip')!=null && paymentCardDet.get('cardBillingAddrZip')!='') {
		StringCustomFieldRef cardBillingAddrZipRef = new StringCustomFieldRef()
		cardBillingAddrZipRef.setValue(paymentCardDet.get('cardBillingAddrZip'))
		cardBillingAddrZipRef.setScriptId('custbody_spk_cc_zip_code')
		customFieldRefs.add(cardBillingAddrZipRef)
	}	
}

// Stripe Charge Id
if(sfdcData.get('stripeChargeId')!=null && sfdcData.get('stripeChargeId')!='') {
	StringCustomFieldRef stripeChgId = new StringCustomFieldRef()
	stripeChgId.setValue(sfdcData.get('stripeChargeId'))
	stripeChgId.setScriptId('custbody_spk_stripe_chg_id')
	customFieldRefs.add(stripeChgId)
}
// Stripe Customer Id
if(sfdcData.get('stripeCustomerId')!=null && sfdcData.get('stripeCustomerId')!='') {
	StringCustomFieldRef stripeCustId = new StringCustomFieldRef()
	stripeCustId.setValue(sfdcData.get('stripeCustomerId'))
	stripeCustId.setScriptId('custbody_spk_stripe_cust_id')
	customFieldRefs.add(stripeCustId)
}
// Stripe Subscription Id
if(sfdcData.get('stripeSubscriptionId')!=null && sfdcData.get('stripeSubscriptionId')!='') {
	StringCustomFieldRef stripeSubscrId = new StringCustomFieldRef()
	stripeSubscrId.setValue(sfdcData.get('stripeSubscriptionId'))
	stripeSubscrId.setScriptId('custbody_spk_stripe_subscription_id')
	customFieldRefs.add(stripeSubscrId)
}
// Stripe Plan Id
if(sfdcData.get('stripePlanId')!=null && sfdcData.get('stripePlanId')!='') {
	StringCustomFieldRef stripePlnId = new StringCustomFieldRef()
	stripePlnId.setValue(sfdcData.get('stripePlanId'))
	stripePlnId.setScriptId('custbody_spk_stripe_plan_id')
	customFieldRefs.add(stripePlnId)
}
// Shipping Contact
if(sfdcData.get('shipContactId')!=null && sfdcData.get('shipContactId')!='') {
	StringCustomFieldRef shipContactIdObj = new StringCustomFieldRef()
	shipContactIdObj.setValue(sfdcData.get('shipContactId'))
	shipContactIdObj.setScriptId('custbody_celigo_ship_contact')
	customFieldRefs.add(shipContactIdObj)
}
// Web Sales Total Tax
if(sfdcData.get('totalTax')!=null && sfdcData.get('totalTax')!='') {
	DoubleCustomFieldRef webSalesTotalTax = new DoubleCustomFieldRef()
	webSalesTotalTax.setValue(Double.parseDouble(sfdcData.get('totalTax')))
	webSalesTotalTax.setScriptId('custbody_spk_web_sale_total_tax')
	customFieldRefs.add(webSalesTotalTax)
}

// ======================== START: Changes for Order Cancellation Requirement ===========================
// Cash Sale internal id
if(sfdcData.get('cashSaleNetSuiteId')!=null && sfdcData.get('cashSaleNetSuiteId')!='') {
	cashSaleMap.put('internalId',sfdcData.get('cashSaleNetSuiteId'))
}

// Order Cancel Date
if(sfdcData.get('orderCancelDate')!=null && sfdcData.get('orderCancelDate')!='') {
	GregorianCalendar cancelDategc = new GregorianCalendar()
	Date subCancelDate = cancelDateFormat.parse(sfdcData.get('orderCancelDate'))
	cancelDategc.setTimeInMillis(subCancelDate.getTime())
	XMLGregorianCalendar cancelDatexgc = DatatypeFactory.newInstance().newXMLGregorianCalendar(cancelDategc)
	DateCustomFieldRef cashSaleCancellationDate  = new DateCustomFieldRef()
	cashSaleCancellationDate.setValue(cancelDatexgc)
	cashSaleCancellationDate.setScriptId("custbody_spk_cancellation_date")
	customFieldRefs.add(cashSaleCancellationDate)
}

// Set Cancellation to "true" if cancel data is in request 
if(sfdcData.get('orderCancelDate')!=null && sfdcData.get('orderCancelDate')!='') {
	BooleanCustomFieldRef cashSaleCancelFlag  = new BooleanCustomFieldRef()
	cashSaleCancelFlag.setValue(true)
	cashSaleCancelFlag.setScriptId("custbody_spk_cancellation_flag")
	customFieldRefs.add(cashSaleCancelFlag)
}
// ======================== END: Changes for Order Cancellation Requirement =============================

//  ********************************************** CS Items: START **********************************************

CashSaleItemList cashSaleItemList = new CashSaleItemList() 
List<CashSaleItem> cashSaleItems = new ArrayList<CashSaleItem>()
boolean isLicHdrDetailsSet = false
// Iterate over each Product and create Item for CS 	
for (Object orderProd in sfdcData.get('orderProducts')) {
	String itemNSId = orderProd.get('pricebookEntry').get('product').get('netSuiteId')
	println "ItemNSId is: " + itemNSId
	if(itemNSId != null && itemNSId != ''){
		List<CustomFieldRef> itemCustFieldRefs = new ArrayList<CustomFieldRef>()	
		CashSaleItem  cashSaleItem = new CashSaleItem()
		// Item NS Id
		RecordRef itemObj = new RecordRef()
		itemObj.setInternalId(orderProd.get('pricebookEntry').product.netSuiteId)
		cashSaleItem.setItem(itemObj)
		
		// Quantity
		cashSaleItem.setQuantity(new Double(orderProd.get('quantity')))
		
		// Price Level 
		RecordRef priceLevelObj = new RecordRef()
		priceLevelObj.setInternalId("-1") // Custom
		cashSaleItem.setPrice(priceLevelObj)

		//Rate
		cashSaleItem.setRate(orderProd.get('salesPrice'))
		
		// List Rate
		StringCustomFieldRef listRate = new StringCustomFieldRef()
		listRate.setValue(orderProd.get('salesPrice'))
		listRate.setScriptId('custcol_list_rate')
		itemCustFieldRefs.add(listRate)

		// SFDC Discount %
		if(orderProd.get('discountPercent')!=null && orderProd.get('discountPercent')!='') {
			StringCustomFieldRef sfdcDiscPercent = new StringCustomFieldRef()
			sfdcDiscPercent.setValue(orderProd.get('discountPercent'))
			sfdcDiscPercent.setScriptId('custcol_salesforce_discount')
			itemCustFieldRefs.add(sfdcDiscPercent)
		}
		
		// Web Sales Item Tax Amount
		if(orderProd.get('taxAmount')!=null && orderProd.get('taxAmount')!='') {
			DoubleCustomFieldRef webSalesTotalTax = new DoubleCustomFieldRef()
			webSalesTotalTax.setValue(Double.parseDouble(orderProd.get('taxAmount')))
			webSalesTotalTax.setScriptId('custcol_spk_web_sale_item_tax')
			itemCustFieldRefs.add(webSalesTotalTax)
		}
		
		// Web Sales Item Tax Rate
		if(orderProd.get('taxRate')!=null && orderProd.get('taxRate')!='') {
			StringCustomFieldRef webSalesItemTaxRate = new StringCustomFieldRef()
			webSalesItemTaxRate.setValue(orderProd.get('taxRate'))
			webSalesItemTaxRate.setScriptId('custcol_spk_ws_item_tax_rate')
			itemCustFieldRefs.add(webSalesItemTaxRate)
		}
		
		// Order Line Item Id
		StringCustomFieldRef orderLineItemId = new StringCustomFieldRef()
		orderLineItemId.setValue(orderProd.get('id'))
		orderLineItemId.setScriptId('custcol_sfdcopplineid')
		itemCustFieldRefs.add(orderLineItemId)
		
		// peakDailyVol
		if(orderProd.get('peakDailyVol')!=null && orderProd.get('peakDailyVol')!='') {
			DoubleCustomFieldRef peakDailyVolId = new DoubleCustomFieldRef()
			peakDailyVolId.setValue(orderProd.get('peakDailyVol'))
			peakDailyVolId.setScriptId('custcol_peak_daily_vol_gb')
			itemCustFieldRefs.add(peakDailyVolId)
		}
		
		orderProdLicData = orderProd.get('licenseDetails')
		
		// License Start Date
		if (orderProdLicData!=null && orderProdLicData.get('licenseStartDate') != null) {
			Date sfdcLicenseStartDate = licenseDatesFormat.parse(orderProdLicData.get('licenseStartDate'))
			GregorianCalendar gc4 = new GregorianCalendar()
			gc4.setTime(sfdcLicenseStartDate)
			
			// set to Pacific time zone
      		//gc4.setTimeZone(TimeZone.getTimeZone("America/Los_Angeles"));
      		
			XMLGregorianCalendar xgc4 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc4)
	    	DateCustomFieldRef nsLicenseStartDate = new DateCustomFieldRef()
	        nsLicenseStartDate.setValue(xgc4)
	        nsLicenseStartDate.setScriptId('custcol_license_start_date')
	        itemCustFieldRefs.add(nsLicenseStartDate)
	        println 'NS License Start Date: ' + nsLicenseStartDate.getValue()
	     }
	     
		// License End Date
		if (orderProdLicData!=null && orderProdLicData.get('licenseEndDate') != null) {
			Date sfdcLicenseEndDate = licenseDatesFormat.parse(orderProdLicData.get('licenseEndDate'))
			GregorianCalendar gc5 = new GregorianCalendar()
			gc5.setTime(sfdcLicenseEndDate)
			// set to Pacific time zone
      		//gc5.setTimeZone(TimeZone.getTimeZone("America/Los_Angeles"));
      		XMLGregorianCalendar xgc5 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc5)		
	    	DateCustomFieldRef nsLicenseEndDate = new DateCustomFieldRef()
	        nsLicenseEndDate.setValue(xgc5)
	        nsLicenseEndDate.setScriptId('custcol_license_end_date')
	        itemCustFieldRefs.add(nsLicenseEndDate)
	        println 'NS License End Date: ' + nsLicenseEndDate.getValue()
	     }
	     
		//  ******************************************* License details in header: START *******************************************
	     if (orderProdLicData!=null && !isLicHdrDetailsSet && orderProdLicData.get('id')!=null && orderProdLicData.get('id')!='') {
	     	// License Delivery Status to "Completed"
			ListOrRecordRef licenseDelObj = new ListOrRecordRef()
			licenseDelObj.setInternalId("1") // Completed
			//licenseDelObj.setName("Completed")
			SelectCustomFieldRef licenseDelSel = new SelectCustomFieldRef()
			licenseDelSel.setValue(licenseDelObj)
			licenseDelSel.setScriptId("custbody_license_delivery_status")
			customFieldRefs.add(licenseDelSel)
			
			// License Delivery Date - Set subscriptionStartDate if it is present in message, otherwise set current date
			GregorianCalendar gc3 = new GregorianCalendar()
			if(sfdcData.get('subscriptionStartDate')!=null && sfdcData.get('subscriptionStartDate')!='') {
				Date delStartDate = licenseDatesFormat.parse(sfdcData.get('subscriptionStartDate'))
				gc3.setTimeInMillis(delStartDate.getTime())
			} else {
				gc3.setTimeInMillis((new Date()).getTime())
			}
			XMLGregorianCalendar xgc3 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc3)
			DateCustomFieldRef coTermDateObj = new DateCustomFieldRef()
			coTermDateObj.setScriptId('custbody_license_delivery_date')
			coTermDateObj.setValue(xgc3)
			customFieldRefs.add(coTermDateObj)
						
			// License GUID
			if(orderProdLicData.get('guid')!=null && orderProdLicData.get('guid')!=''){
				StringCustomFieldRef licenseGuid = new StringCustomFieldRef()
				licenseGuid.setValue(orderProdLicData.get('guid'))
				licenseGuid.setScriptId('custbody_guid')
				customFieldRefs.add(licenseGuid)
			}
			
			// License CRM Id
			if(orderProdLicData.get('id')!=null && orderProdLicData.get('id')!=''){
				StringCustomFieldRef licenseCRMid = new StringCustomFieldRef()
				licenseCRMid.setValue(orderProdLicData.get('id'))
				licenseCRMid.setScriptId('custbody_crm_license_id')
				customFieldRefs.add(licenseCRMid)
			}
			
			// License Delivery Email
			if(orderProdLicData.get('licenseDeliveryEmail')!=null && orderProdLicData.get('licenseDeliveryEmail')!=''){
				StringCustomFieldRef licenseDelEmail = new StringCustomFieldRef()
				licenseDelEmail.setValue(orderProdLicData.get('licenseDeliveryEmail'))
				licenseDelEmail.setScriptId('custbody_license_delivery_email')
				customFieldRefs.add(licenseDelEmail)
			}
			isLicHdrDetailsSet = true	     
	     }
		//  ******************************************** License details in header: END ********************************************	     
	     
	      if (!itemCustFieldRefs.isEmpty()) {
			CustomFieldList itemCFields = new CustomFieldList()
			itemCFields.setCustomField(itemCustFieldRefs)
			cashSaleItem.setCustomFieldList(itemCFields)
		}
		cashSaleItems.add(cashSaleItem)
	}
}
cashSaleItemList.setItem(cashSaleItems)
cashSaleMap.put('itemList',cashSaleItemList)

// ******* START: BIZ-335 Changes *********
// To Be E-mailed
if(sfdcData.get('toBeEmailedAddress')!=null && sfdcData.get('toBeEmailedAddress')!='') {
	cashSaleMap.put('email',sfdcData.get('toBeEmailedAddress'))
}
// ******* END: BIZ-335 Changes *********

// ******* START: BIZ-641 Changes *********
// Old Cash Sale Id
if(sfdcData.get('oldCashSaleId')!=null && sfdcData.get('oldCashSaleId')!='') {
	StringCustomFieldRef oldCashSaleIdObj = new StringCustomFieldRef()
	oldCashSaleIdObj.setValue(sfdcData.get('oldCashSaleId'))
	oldCashSaleIdObj.setScriptId('custbody_spk_old_cashsale_id')
	customFieldRefs.add(oldCashSaleIdObj)
}
// ******* END: BIZ-641 Changes *********

// Setting custom fields
CustomFieldList cFields = new CustomFieldList()
cFields.setCustomField(customFieldRefs)
cashSaleMap.put('customFieldList',cFields)

return cashSaleMap
