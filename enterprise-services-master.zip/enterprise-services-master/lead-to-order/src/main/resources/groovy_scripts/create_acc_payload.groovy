
java.util.HashMap accPayloadMap = new java.util.HashMap()
java.util.HashMap accObjMap = new java.util.HashMap()

accObjMap.put('id', flowVars['sfdcAccId'])
accPayloadMap.put('account', accObjMap)

return accPayloadMap
