
import java.util.*
import com.netsuite.webservices.platform.core_2014_1.RecordRef

List<Map<String, Object>> fileRecords = new ArrayList<HashMap<String, Object>>()

if(payload!=null){
	for (Object fileRecData in payload.get('filesList')) {	
		Map<String, Object> fileRecordMap = new HashMap<String, Object>()
		
		fileRecordMap.put('name',fileRecData.get('fileName'))
		fileRecordMap.put('content',fileRecData.get('fileContent'))
		
		RecordRef fodlerRef = new RecordRef()
		fodlerRef.setInternalId(fileRecData.get('folderInternalId'))		
		fileRecordMap.put('folder',fodlerRef)
		
		fileRecords.add(fileRecordMap)
	}
}

return fileRecords
