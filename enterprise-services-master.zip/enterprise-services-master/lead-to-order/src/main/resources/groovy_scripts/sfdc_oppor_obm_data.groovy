flowVars['sfdcOppId'] = payload.get('oppId')
flowVars['isCPQOrder'] = payload.get('oppIsCPQOrder')

println "Opportunity Id from OBM is: " + flowVars['sfdcOppId']
println "isCPQ Value from OBM is: " + flowVars['isCPQOrder']

errorLogDetailsMap = sessionVars['errorLogDetMap']
if(flowVars['isCPQOrder']!=null && flowVars['isCPQOrder'].equals('true')){
	errorLogDetailsMap.put('functionalModule',cpqFuncModuleVal)
} else {
	errorLogDetailsMap.put('functionalModule',eCommFuncModuleVal)
}
sessionVars['errorLogDetMap'] = errorLogDetailsMap

return flowVars['sfdcOppId']