import java.util.*

envelope = new XmlSlurper().parseText(payload);

flowVars['sfdcSessId'] = envelope.Body.notifications.SessionId.text()

List<Map<String,String>> accountsInOBMList = new ArrayList<HashMap<String,String>>()
println "Account Notifications from OBM size is: " + envelope.Body.notifications.Notification.size()

if(envelope.Body.notifications!=null && 
	envelope.Body.notifications.Notification!=null) {
	for (Object notif in envelope.Body.notifications.Notification) {
		Map<String,String> notifDetailsMap = new HashMap<String,String>()
		notifDetailsMap.put('accId', notif.sObject.Id.text())
		notifDetailsMap.put('accTimeStamp', notif.sObject.LastModifiedDate.text())
		
		accountsInOBMList.add(notifDetailsMap)
	}
}
println "accountsInOBMList is: " + accountsInOBMList
return accountsInOBMList