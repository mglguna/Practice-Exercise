import com.sforce.outbound.opportunity.OpportunityNotification;
import com.sforce.outbound.opportunity.Opportunity;
import java.util.LinkedList;

envelope = new XmlSlurper().parseText(payload);

flowVars['sfdcSessId'] = envelope.Body.notifications.SessionId.text()

if(envelope.Body.notifications!=null && 
	envelope.Body.notifications.Notification!=null) {
	flowVars['sfdcOppId'] = envelope.Body.notifications.Notification[0].sObject.Id.text()
}

println "Opportunity Id from OBM is: " + flowVars['sfdcOppId']

return flowVars['sfdcOppId']